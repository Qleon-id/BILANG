import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../models/reminder.dart';
import '../models/user_settings.dart';
import '../repositories/reminder_repository.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;

    tz.initializeTimeZones();
    try {
      final timezone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(timezone.identifier));
    } catch (_) {
      // Keep the timezone package default if the device timezone cannot be read.
    }

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings);

    final androidPlugin = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(
      const AndroidNotificationChannel(
        'bilang_reminders',
        'Titipan BILANG',
        description: 'Pengingat untuk Titipan yang kamu simpan di BILANG.',
        importance: Importance.high,
      ),
    );

    _initialized = true;
  }

  Future<void> scheduleReminder(
    Reminder reminder,
    UserSettings settings,
  ) async {
    await initialize();
    if (!settings.notificationsEnabled) return;
    if (reminder.status != ReminderStatus.active &&
        reminder.status != ReminderStatus.snoozed) {
      return;
    }

    final scheduled = reminder.scheduledAt;
    if (scheduled.isBefore(DateTime.now())) return;
    if (_isQuietTime(scheduled, settings) &&
        !(reminder.priority == ReminderPriority.important &&
            settings.importantReminderDuringQuietHours)) {
      return;
    }

    final id = _notificationId(reminder.id);
    await _plugin.cancel(id);

    final body = _body(reminder, settings);
    final androidDetails = AndroidNotificationDetails(
      'bilang_reminders',
      'Titipan BILANG',
      channelDescription: 'Pengingat untuk Titipan yang kamu simpan di BILANG.',
      importance: Importance.high,
      priority: Priority.high,
      playSound: settings.soundEnabled,
      enableVibration: settings.vibrationEnabled,
      visibility: settings.notificationPreview
          ? NotificationVisibility.public
          : NotificationVisibility.private,
    );

    final match = switch (reminder.recurrence) {
      ReminderRecurrence.none => null,
      ReminderRecurrence.daily => DateTimeComponents.time,
      ReminderRecurrence.weekly => DateTimeComponents.dayOfWeekAndTime,
      // flutter_local_notifications 7.0.0 does not provide monthly
      // DateTimeComponents; monthly occurrences are handled by the
      // reminder layer as one-shot notifications for this milestone.
      ReminderRecurrence.monthly => null,
      ReminderRecurrence.custom => null,
    };

    final scheduledDate = tz.TZDateTime.from(scheduled, tz.local);
    await _plugin.zonedSchedule(
      id,
      'BILANG',
      body,
      scheduledDate,
      NotificationDetails(android: androidDetails),
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: match,
      payload: reminder.id,
    );
  }

  Future<void> cancelReminder(String reminderId) async {
    await initialize();
    await _plugin.cancel(_notificationId(reminderId));
  }

  Future<void> rescheduleAll(
    ReminderRepository repository,
    UserSettings settings,
  ) async {
    await initialize();
    final reminders = await repository.getActiveReminders();
    for (final reminder in reminders) {
      await scheduleReminder(reminder, settings);
    }
  }

  String _body(Reminder reminder, UserSettings settings) {
    if (!settings.notificationPreview) return 'Kamu punya satu titipan.';

    return switch (settings.notificationStyle) {
      NotificationStyle.natural => 'Hei, kamu tadi nitip sesuatu. 👀\n${reminder.title}',
      NotificationStyle.short => '${reminder.title} — ${_time(reminder.scheduledAt)}',
      NotificationStyle.casual => 'Eh, jangan lupa ${reminder.title} 👀',
    };
  }

  String _time(DateTime value) =>
      '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';

  bool _isQuietTime(DateTime value, UserSettings settings) {
    if (!settings.quietHoursEnabled) return false;
    final minute = value.hour * 60 + value.minute;
    final start = _parseMinute(settings.quietStart);
    final end = _parseMinute(settings.quietEnd);
    if (start == null || end == null || start == end) return false;
    if (start < end) return minute >= start && minute < end;
    return minute >= start || minute < end;
  }

  int? _parseMinute(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour > 23 || minute > 59) return null;
    return hour * 60 + minute;
  }

  int _notificationId(String value) => value.hashCode & 0x7fffffff;
}
