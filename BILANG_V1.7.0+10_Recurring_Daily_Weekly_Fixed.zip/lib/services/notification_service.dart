import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../models/reminder.dart';
import '../models/user_settings.dart';
import '../repositories/reminder_repository.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  bool? _notificationsGranted;
  bool _batteryOptimizationPrompted = false;

  // New channel intentionally avoids the old alarm-style channel configuration.
  static const String _channelId = 'bilang_reminders_v5';
  static const int _customHorizonDays = 45;

  Future<void> initialize() async {
    if (_initialized) return;

    tz.initializeTimeZones();
    try {
      final timezone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(timezone.identifier));
    } catch (_) {}

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings: settings);

    final androidPlugin = _androidPlugin;
    await androidPlugin?.createNotificationChannel(
      const AndroidNotificationChannel(
        _channelId,
        'Titipan BILANG',
        description: 'Pengingat untuk Titipan yang kamu simpan di BILANG.',
        importance: Importance.max,
        audioAttributesUsage: AudioAttributesUsage.notification,
      ),
    );

    _initialized = true;
  }

  AndroidFlutterLocalNotificationsPlugin? get _androidPlugin =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  Future<bool> requestNotificationPermission() async {
    await initialize();
    final granted =
        await _androidPlugin?.requestNotificationsPermission() ?? true;
    _notificationsGranted = granted;
    return granted;
  }

  Future<bool> notificationsEnabledOnDevice() async {
    await initialize();
    final enabled = await _androidPlugin?.areNotificationsEnabled() ?? true;
    _notificationsGranted = enabled;
    return enabled;
  }

  /// Notification scheduling deliberately uses inexactAllowWhileIdle.
  /// This does not require Android's special "Alarms & reminders" access.
  Future<bool> ensureAndroidPermissions() async {
    final notifications =
        _notificationsGranted ?? await requestNotificationPermission();
    if (!notifications) return false;

    // Battery optimization is a reliability aid only. It is unrelated to the
    // Alarms & reminders special access and scheduling still works if denied.
    if (!_batteryOptimizationPrompted) {
      _batteryOptimizationPrompted = true;
      try {
        final status = await Permission.ignoreBatteryOptimizations.status;
        if (!status.isGranted) {
          await Permission.ignoreBatteryOptimizations.request();
        }
      } catch (_) {}
    }
    return true;
  }

  Future<void> scheduleReminder(
    Reminder reminder,
    UserSettings settings,
  ) async {
    await initialize();
    if (!settings.notificationsEnabled) return;
    if (reminder.status != ReminderStatus.active &&
        reminder.status != ReminderStatus.snoozed) {
      return;
    }

    if (!await ensureAndroidPermissions()) return;
    if (!await notificationsEnabledOnDevice()) return;

    await _cancelAllIdsForReminder(reminder.id);

    final schedulingReminder = _normalizeRecurringDate(reminder);
    final times = _recurrenceTimes(schedulingReminder);
    final now = DateTime.now();

    for (var index = 0; index < times.length; index++) {
      final scheduled = times[index];
      if (scheduled.isBefore(now)) continue;
      if (_isQuietTime(scheduled, settings) &&
          !(reminder.priority == ReminderPriority.important &&
              settings.importantReminderDuringQuietHours)) {
        continue;
      }

      final id = _notificationId(reminder.id, index);
      await _scheduleInexact(
        id: id,
        reminder: schedulingReminder,
        scheduled: scheduled,
        settings: settings,
      );
    }

    // Verify the schedule. Some OEMs can reject an individual alarm silently;
    // retrying the same notification as inexact is safe and does not require
    // the Alarms & reminders special access.
    final pending = await _plugin.pendingNotificationRequests();
    final pendingIds = pending.map((request) => request.id).toSet();
    for (var index = 0; index < times.length; index++) {
      final scheduled = times[index];
      if (scheduled.isBefore(DateTime.now())) continue;
      if (_isQuietTime(scheduled, settings) &&
          !(reminder.priority == ReminderPriority.important &&
              settings.importantReminderDuringQuietHours)) {
        continue;
      }
      final id = _notificationId(reminder.id, index);
      if (!pendingIds.contains(id)) {
        await _scheduleInexact(
          id: id,
          reminder: schedulingReminder,
          scheduled: scheduled,
          settings: settings,
        );
      }
    }
  }

  Future<void> _scheduleInexact({
    required int id,
    required Reminder reminder,
    required DateTime scheduled,
    required UserSettings settings,
  }) async {
    final androidDetails = AndroidNotificationDetails(
      _channelId,
      'Titipan BILANG',
      channelDescription: 'Pengingat untuk Titipan yang kamu simpan di BILANG.',
      importance: Importance.max,
      priority: Priority.max,
      category: AndroidNotificationCategory.reminder,
      audioAttributesUsage: AudioAttributesUsage.notification,
      playSound: settings.soundEnabled,
      enableVibration: settings.vibrationEnabled,
      visibility: settings.notificationPreview
          ? NotificationVisibility.public
          : NotificationVisibility.private,
    );

    final match = switch (reminder.recurrence) {
      ReminderRecurrence.none => null,
      ReminderRecurrence.daily => DateTimeComponents.time,
      ReminderRecurrence.weekly => DateTimeComponents.dayOfWeekAndTime,
      ReminderRecurrence.monthly => DateTimeComponents.dayOfMonthAndTime,
      ReminderRecurrence.custom => null,
    };

    await _plugin.zonedSchedule(
      id: id,
      title: 'BILANG',
      body: _body(reminder, settings),
      scheduledDate: tz.TZDateTime.from(scheduled, tz.local),
      notificationDetails: NotificationDetails(android: androidDetails),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: match,
      payload: reminder.id,
    );
  }

  Reminder _normalizeRecurringDate(Reminder reminder) {
    final now = DateTime.now();
    if (reminder.recurrence == ReminderRecurrence.none) return reminder;

    var next = reminder.scheduledAt;
    final intervalDays = reminder.recurrenceIntervalDays;
    final hasWindow =
        reminder.recurrenceIntervalMinutes != null &&
        reminder.recurrenceEndMinute != null;

    bool hasFutureTimeToday() {
      if (!hasWindow) return next.isAfter(now);
      final startMinute = next.hour * 60 + next.minute;
      final endMinute = reminder.recurrenceEndMinute!;
      final nowMinute = now.hour * 60 + now.minute;
      if (endMinute < startMinute) return next.isAfter(now);
      return _sameCalendarDay(next, now) && nowMinute < endMinute;
    }

    if (reminder.recurrence == ReminderRecurrence.daily) {
      if (!hasFutureTimeToday()) {
        next = DateTime(next.year, next.month, next.day).add(const Duration(days: 1));
        next = DateTime(next.year, next.month, next.day, reminder.scheduledAt.hour, reminder.scheduledAt.minute);
      }
    } else if (reminder.recurrence == ReminderRecurrence.weekly) {
      while (!hasFutureTimeToday()) {
        next = next.add(const Duration(days: 7));
      }
    } else if (reminder.recurrence == ReminderRecurrence.monthly) {
      while (!next.isAfter(now)) {
        next = DateTime(next.year, next.month + 1, next.day, next.hour, next.minute);
      }
    } else if (reminder.recurrence == ReminderRecurrence.custom &&
        intervalDays != null &&
        intervalDays > 0) {
      while (!hasFutureTimeToday()) {
        next = next.add(Duration(days: intervalDays));
      }
    }

    if (next == reminder.scheduledAt) return reminder;
    return reminder.copyWith(scheduledAt: next);
  }

  bool _sameCalendarDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  List<DateTime> _recurrenceTimes(Reminder reminder) {
    final intervalMinutes = reminder.recurrenceIntervalMinutes;
    final endMinute = reminder.recurrenceEndMinute;

    // A one-card hourly window, e.g. 05:00–12:00, is represented by one
    // Reminder. Only the notification schedule contains the individual times.
    if (intervalMinutes == null || endMinute == null || intervalMinutes <= 0) {
      if (reminder.recurrence != ReminderRecurrence.custom ||
          reminder.recurrenceIntervalDays == null ||
          reminder.recurrenceIntervalDays! <= 0) {
        return [reminder.scheduledAt];
      }
    }

    if (reminder.recurrence == ReminderRecurrence.custom &&
        reminder.recurrenceIntervalDays != null &&
        reminder.recurrenceIntervalDays! > 0) {
      final intervalDays = reminder.recurrenceIntervalDays!;
      final result = <DateTime>[];
      final timesInDay = _timesInDay(reminder, intervalMinutes, endMinute);
      var day = DateTime(
        reminder.scheduledAt.year,
        reminder.scheduledAt.month,
        reminder.scheduledAt.day,
      );
      final horizon = day.add(const Duration(days: _customHorizonDays));
      while (!day.isAfter(horizon)) {
        for (final time in timesInDay) {
          result.add(DateTime(day.year, day.month, day.day, time.hour, time.minute));
        }
        day = day.add(Duration(days: intervalDays));
      }
      return result;
    }

    return _timesInDay(reminder, intervalMinutes, endMinute);
  }

  List<DateTime> _timesInDay(
    Reminder reminder,
    int? intervalMinutes,
    int? endMinute,
  ) {
    if (intervalMinutes == null || endMinute == null || intervalMinutes <= 0) {
      return [reminder.scheduledAt];
    }

    final startMinute = reminder.scheduledAt.hour * 60 + reminder.scheduledAt.minute;
    if (endMinute < startMinute) return [reminder.scheduledAt];

    final result = <DateTime>[];
    for (var minute = startMinute; minute <= endMinute; minute += intervalMinutes) {
      result.add(DateTime(
        reminder.scheduledAt.year,
        reminder.scheduledAt.month,
        reminder.scheduledAt.day,
        minute ~/ 60,
        minute % 60,
      ));
    }
    return result;
  }

  Future<void> cancelReminder(String reminderId) async {
    await initialize();
    await _cancelAllIdsForReminder(reminderId);
  }

  Future<void> _cancelAllIdsForReminder(String reminderId) async {
    await _plugin.cancel(id: reminderId.hashCode & 0x7fffffff);
    // Leave a little room for the custom every-N-days schedule.
    for (var index = 0; index < 512; index++) {
      await _plugin.cancel(id: _notificationId(reminderId, index));
    }
  }

  Future<void> rescheduleAll(
    ReminderRepository repository,
    UserSettings settings,
  ) async {
    await initialize();
    if (!settings.notificationsEnabled) return;
    final reminders = await repository.getActiveReminders();
    if (reminders.isEmpty) return;

    if (!await ensureAndroidPermissions()) return;
    for (final reminder in reminders) {
      await scheduleReminder(reminder, settings);
    }
  }

  String _body(Reminder reminder, UserSettings settings) {
    if (!settings.notificationPreview) return 'Kamu punya satu titipan.';

    return switch (settings.notificationStyle) {
      NotificationStyle.natural =>
        'Hei, kamu tadi nitip sesuatu. 👀\n${reminder.title}',
      NotificationStyle.short =>
        '${reminder.title} — ${_time(reminder.scheduledAt)}',
      NotificationStyle.casual => 'Eh, jangan lupa ${reminder.title} 👀',
    };
  }

  String _time(DateTime value) =>
      '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';

  bool _isQuietTime(DateTime value, UserSettings settings) {
    if (!settings.quietHoursEnabled) return false;
    final minute = value.hour * 60 + value.minute;
    final start = _parseMinute(settings.quietStart);
    final end = _parseMinute(settings.quietEnd);
    if (start == null || end == null || start == end) return false;
    if (start < end) return minute >= start && minute < end;
    return minute >= start || minute < end;
  }

  int? _parseMinute(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour > 23 || minute > 59) return null;
    return hour * 60 + minute;
  }

  int _notificationId(String value, [int occurrence = 0]) {
    var hash = 0x811c9dc5;
    final input = '$value#$occurrence';
    for (final codeUnit in input.codeUnits) {
      hash ^= codeUnit;
      hash = (hash * 0x01000193) & 0x7fffffff;
    }
    return hash == 0 ? 1 : hash;
  }
}
