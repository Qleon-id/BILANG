import 'package:flutter/material.dart';
import '../../models/memory.dart';
import '../../repositories/memory_repository.dart';

class IngatanScreen extends StatefulWidget {
  final MemoryRepository repository;
  const IngatanScreen({super.key, required this.repository});

  @override
  State<IngatanScreen> createState() => _IngatanScreenState();
}

class _IngatanScreenState extends State<IngatanScreen> {
  final searchController = TextEditingController();
  List<Memory> memories = const [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
    searchController.addListener(_search);
  }

  @override
  void dispose() {
    searchController.removeListener(_search);
    searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    final result = await widget.repository.getMemories();
    if (!mounted) return;
    setState(() {
      memories = result.where((m) => !m.isArchived).toList();
      loading = false;
    });
  }

  Future<void> _search() async {
    final query = searchController.text.trim();
    final result = query.isEmpty
        ? await widget.repository.getMemories()
        : await widget.repository.searchMemories(query);
    if (!mounted) return;
    setState(() => memories = result.where((m) => !m.isArchived).toList());
  }

  Future<void> _delete(Memory memory) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Lupakan ingatan ini?'),
        content: Text(memory.content),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Lupakan')),
        ],
      ),
    );
    if (confirmed == true) {
      await widget.repository.deleteMemory(memory.id);
      await _load();
    }
  }

  Future<void> _edit(Memory memory) async {
    final titleController = TextEditingController(text: memory.title);
    final contentController = TextEditingController(text: memory.content);
    final result = await showDialog<_MemoryEditResult>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Ubah ingatan'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: titleController, decoration: const InputDecoration(labelText: 'Judul')),
            const SizedBox(height: 12),
            TextField(controller: contentController, maxLines: 4, decoration: const InputDecoration(labelText: 'Isi')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Batal')),
          FilledButton(
            onPressed: () => Navigator.pop(
              dialogContext,
              _MemoryEditResult(titleController.text, contentController.text),
            ),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
    titleController.dispose();
    contentController.dispose();
    if (result == null || result.content.trim().isEmpty) return;
    if (_looksSensitive(result.content)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Aku nggak menyimpan kredensial atau kode keamanan. 🔐')),
        );
      }
      return;
    }
    await widget.repository.updateMemory(memory.copyWith(
      title: result.title.trim().isEmpty ? memory.title : result.title.trim(),
      content: result.content.trim(),
      updatedAt: DateTime.now(),
    ));
    await _load();
  }

  bool _looksSensitive(String value) => RegExp(
        r'\b(password|kata sandi|passwd|passcode|pin|otp|kode otp|cvv|cvc|security code|api key|apikey|secret key|private key|recovery code|kode pemulihan|credential|kredensial)\b',
        caseSensitive: false,
      ).hasMatch(value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 22, 22, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Ingatan', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text('Hal-hal yang pernah kamu titipkan kepadaku.', style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 18),
          TextField(
            controller: searchController,
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: 'Cari ingatan...',
              suffixIcon: searchController.text.isNotEmpty
                  ? IconButton(icon: const Icon(Icons.clear), onPressed: searchController.clear)
                  : null,
            ),
          ),
          const SizedBox(height: 18),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : memories.isEmpty
                    ? _empty(context)
                    : RefreshIndicator(
                        onRefresh: _load,
                        child: ListView.separated(
                          physics: const AlwaysScrollableScrollPhysics(),
                          itemCount: memories.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 10),
                          itemBuilder: (_, index) => _memoryCard(context, memories[index]),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _empty(BuildContext context) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.psychology_alt_outlined, size: 56, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 14),
            Text('Belum ada ingatan.', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('Kamu bisa bilang sesuatu yang ingin aku simpan.', textAlign: TextAlign.center),
          ],
        ),
      );

  Widget _memoryCard(BuildContext context, Memory memory) => Dismissible(
        key: ValueKey(memory.id),
        direction: DismissDirection.endToStart,
        confirmDismiss: (_) async {
          await _delete(memory);
          return false;
        },
        background: Container(
          alignment: Alignment.centerRight,
          padding: const EdgeInsets.only(right: 20),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.errorContainer,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Icon(Icons.delete_outline, color: Theme.of(context).colorScheme.onErrorContainer),
        ),
        child: Card(
          margin: EdgeInsets.zero,
          child: ListTile(
            contentPadding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
            title: Text(
              '${memory.title} • ${memory.content}',
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text('BILANG menangkap informasi ini untukmu.'),
            ),
            isThreeLine: memory.content.length > 55,
            trailing: PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'edit') _edit(memory);
                if (value == 'delete') _delete(memory);
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'edit', child: Text('Ubah')),
                PopupMenuItem(value: 'delete', child: Text('Lupakan')),
              ],
            ),
          ),
        ),
      );
}

class _MemoryEditResult {
  final String title;
  final String content;
  const _MemoryEditResult(this.title, this.content);
}
