import 'package:flutter/material.dart';

import '../../models/reminder.dart';
import '../../repositories/reminder_repository.dart';
import '../../services/reminder_service.dart';
import '../../services/notification_service.dart';
import '../../models/user_settings.dart';

class TitipanScreen extends StatefulWidget {
  final ReminderRepository repository;
  final UserSettings settings;

  const TitipanScreen({
    super.key,
    required this.repository,
    required this.settings,
  });

  @override
  State<TitipanScreen> createState() => _TitipanScreenState();
}

class _TitipanScreenState extends State<TitipanScreen> {
  late final ReminderService service = ReminderService(
    widget.repository,
    settings: widget.settings,
    notificationService: NotificationService(),
  );
  List<Reminder> reminders = [];
  int filter = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await widget.repository.getReminders();
    if (!mounted) return;
    setState(() => reminders = data);
  }

  List<Reminder> get _visibleReminders {
    final now = DateTime.now();
    final list = reminders
        .where(
          (r) =>
              r.status != ReminderStatus.dismissed &&
              r.status != ReminderStatus.completed,
        )
        .toList()
      ..sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));

    if (filter == 1) {
      return list.where((r) => _occursOnDay(r, now)).toList();
    }

    if (filter == 2) {
      final tomorrow = DateTime(now.year, now.month, now.day + 1);
      return list
          .where((r) => r.recurrence == ReminderRecurrence.daily ||
              r.recurrence == ReminderRecurrence.custom ||
              (r.recurrence == ReminderRecurrence.weekly &&
                  r.scheduledAt.weekday >= DateTime.monday) ||
              !r.scheduledAt.isBefore(tomorrow))
          .toList();
    }

    return list;
  }

  List<_ReminderGroup> get visibleGroups {
    final list = _visibleReminders;
    if (list.isEmpty) return const [];

    final result = <_ReminderGroup>[];
    final groupedByParent = <String, _ReminderGroup>{};
    final standalone = <Reminder>[];

    for (final reminder in list) {
      final parent = reminder.parentReminderId;
      if (parent == null || parent.isEmpty) {
        standalone.add(reminder);
        continue;
      }

      final key = 'parent:$parent';
      final group = groupedByParent.putIfAbsent(
        key,
        () => _ReminderGroup(key: key, items: []),
      );
      group.items.add(reminder);
    }

    result.addAll(groupedByParent.values);
    result.addAll(_groupLegacyHourlySeries(standalone));
    result.sort((a, b) => a.start.compareTo(b.start));
    return result;
  }

  /// V1.5.0+2 stored each period occurrence as its own reminder. Group old
  /// data too, so users do not suddenly see four identical cards after the
  /// UI changes in this version.
  List<_ReminderGroup> _groupLegacyHourlySeries(List<Reminder> input) {
    final sorted = [...input]..sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));
    final groups = <_ReminderGroup>[];
    var current = <Reminder>[];

    void flush() {
      if (current.isNotEmpty) {
        groups.add(
          _ReminderGroup(
            key: 'legacy:${current.first.id}',
            items: [...current],
          ),
        );
        current = [];
      }
    }

    for (final reminder in sorted) {
      if (current.isEmpty) {
        current.add(reminder);
        continue;
      }

      final previous = current.last;
      final hourly =
          reminder.scheduledAt.difference(previous.scheduledAt).inMinutes == 60;
      final sameTitle = reminder.title.trim().toLowerCase() ==
          previous.title.trim().toLowerCase();
      final sameDate = _sameDay(reminder.scheduledAt, previous.scheduledAt);

      if (hourly && sameTitle && sameDate) {
        current.add(reminder);
      } else {
        flush();
        current.add(reminder);
      }
    }
    flush();
    return groups;
  }

  Future<void> _add() async {
    final title = TextEditingController();
    DateTime date = DateTime.now();
    TimeOfDay time = TimeOfDay.now();
    ReminderRecurrence recurrence = ReminderRecurrence.none;

    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialog) {
            return AlertDialog(
              title: const Text('Titip sesuatu'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: title,
                      autofocus: true,
                      decoration: const InputDecoration(
                        labelText: 'Apa yang perlu diingat?',
                      ),
                    ),
                    const SizedBox(height: 14),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Tanggal'),
                      subtitle: Text('${date.day}/${date.month}/${date.year}'),
                      trailing: const Icon(Icons.calendar_today_outlined),
                      onTap: () async {
                        final selected = await showDatePicker(
                          context: context,
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(
                            const Duration(days: 3650),
                          ),
                          initialDate: date,
                        );
                        if (selected != null) {
                          setDialog(() => date = selected);
                        }
                      },
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Jam'),
                      subtitle: Text(time.format(context)),
                      trailing: const Icon(Icons.schedule_outlined),
                      onTap: () async {
                        final selected = await showTimePicker(
                          context: context,
                          initialTime: time,
                        );
                        if (selected != null) {
                          setDialog(() => time = selected);
                        }
                      },
                    ),
                    DropdownButtonFormField<ReminderRecurrence>(
                      initialValue: recurrence,
                      decoration: const InputDecoration(labelText: 'Ulangi'),
                      items: ReminderRecurrence.values
                          .map(
                            (r) => DropdownMenuItem<ReminderRecurrence>(
                              value: r,
                              child: Text(_recurrenceLabel(r)),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        setDialog(
                          () => recurrence = value ?? ReminderRecurrence.none,
                        );
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Batal'),
                ),
                FilledButton(
                  onPressed: () {
                    Navigator.pop(context, title.text.trim().isNotEmpty);
                  },
                  child: const Text('Titipkan'),
                ),
              ],
            );
          },
        );
      },
    );

    if (result == true) {
      final scheduled = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
      await service.create(
        title: title.text,
        scheduledAt: scheduled,
        recurrence: recurrence,
      );
      await _load();
    }

    title.dispose();
  }

  static String _recurrenceLabel(ReminderRecurrence recurrence) {
    return switch (recurrence) {
      ReminderRecurrence.none => 'Tidak diulang',
      ReminderRecurrence.daily => 'Setiap hari',
      ReminderRecurrence.weekly => 'Setiap minggu',
      ReminderRecurrence.monthly => 'Setiap bulan',
      ReminderRecurrence.custom => 'Custom',
    };
  }

  static bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  bool _occursOnDay(Reminder reminder, DateTime day) {
    if (reminder.recurrence == ReminderRecurrence.daily) return true;
    if (reminder.recurrence == ReminderRecurrence.weekly) {
      return reminder.scheduledAt.weekday == day.weekday;
    }
    if (reminder.recurrence == ReminderRecurrence.custom) {
      final interval = reminder.recurrenceIntervalDays;
      if (interval == null || interval <= 0) return false;
      final anchor = DateTime(
        reminder.scheduledAt.year,
        reminder.scheduledAt.month,
        reminder.scheduledAt.day,
      );
      final target = DateTime(day.year, day.month, day.day);
      if (target.isBefore(anchor)) return false;
      return target.difference(anchor).inDays % interval == 0;
    }
    return _sameDay(reminder.scheduledAt, day);
  }

  String _dateLabel(_ReminderGroup group) {
    final start = group.start;
    if (group.items.length == 1) {
      final reminder = group.items.first;
      final endMinute = reminder.recurrenceEndMinute;
      final interval = reminder.recurrenceIntervalMinutes;
      if (reminder.recurrence == ReminderRecurrence.weekly) {
        if (endMinute != null && interval != null) {
          final endTime = '${(endMinute ~/ 60).toString().padLeft(2, '0')}.${(endMinute % 60).toString().padLeft(2, '0')}';
          return 'Setiap ${_weekdayLabel(start.weekday)} • ${_time(start)} - $endTime • tiap ${interval == 60 ? 'jam' : '$interval menit'}';
        }
        return 'Setiap ${_weekdayLabel(start.weekday)} • ${_time(start)}';
      }
      if (reminder.recurrence == ReminderRecurrence.daily) {
        if (endMinute != null && interval != null) {
          final endTime = '${(endMinute ~/ 60).toString().padLeft(2, '0')}.${(endMinute % 60).toString().padLeft(2, '0')}';
          return 'Setiap hari • ${_time(start)} - $endTime • tiap ${interval == 60 ? 'jam' : '$interval menit'}';
        }
        return 'Setiap hari • ${_time(start)}';
      }
      if (reminder.recurrence == ReminderRecurrence.custom) {
        final days = reminder.recurrenceIntervalDays;
        final label = days == 1 ? 'Setiap hari' : 'Setiap ${days ?? 0} hari';
        if (endMinute != null && interval != null) {
          final endTime = '${(endMinute ~/ 60).toString().padLeft(2, '0')}.${(endMinute % 60).toString().padLeft(2, '0')}';
          return '$label • ${_time(start)} - $endTime • tiap ${interval == 60 ? 'jam' : '$interval menit'}';
        }
        return '$label • ${_time(start)}';
      }
      if (endMinute != null && interval != null) {
        final endTime = '${(endMinute ~/ 60).toString().padLeft(2, '0')}.${(endMinute % 60).toString().padLeft(2, '0')}';
        return '${start.day}/${start.month}/${start.year} • ${_time(start)} - $endTime • tiap ${interval == 60 ? 'jam' : '$interval menit'}';
      }
    }

    final now = DateTime.now();
    final date = _sameDay(start, now)
        ? 'Hari ini'
        : '${start.day}/${start.month}/${start.year}';
    final startTime = _time(start);
    if (group.items.length == 1 || start == group.end) {
      return '$date • $startTime';
    }
    return '$date • $startTime - ${_time(group.end)}';
  }

  String _weekdayLabel(int weekday) => const {
        DateTime.monday: 'Senin',
        DateTime.tuesday: 'Selasa',
        DateTime.wednesday: 'Rabu',
        DateTime.thursday: 'Kamis',
        DateTime.friday: 'Jumat',
        DateTime.saturday: 'Sabtu',
        DateTime.sunday: 'Minggu',
      }[weekday] ?? 'Hari';

  String _time(DateTime value) =>
      '${value.hour.toString().padLeft(2, '0')}.${value.minute.toString().padLeft(2, '0')}';

  Future<void> _completeGroup(_ReminderGroup group) async {
    for (final reminder in group.items) {
      await service.complete(reminder.id);
    }
    await _load();
  }

  Future<void> _deleteGroup(_ReminderGroup group) async {
    for (final reminder in group.items) {
      await service.delete(reminder.id);
    }
    await _load();
  }

  Future<void> _snoozeNext(_ReminderGroup group) async {
    final now = DateTime.now();
    final next = group.items
        .where((r) => !r.scheduledAt.isBefore(now))
        .toList()
      ..sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));
    if (next.isEmpty) return;
    await service.snooze(
      next.first.id,
      DateTime.now().add(const Duration(minutes: 15)),
    );
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final currentVisible = visibleGroups;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Titipan',
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Yang sedang aku ingat untukmu.',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: _add,
                    icon: const Icon(Icons.add_rounded),
                    tooltip: 'Titipkan',
                  ),
                ],
              ),
              const SizedBox(height: 18),
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('Semua')),
                  ButtonSegment(value: 1, label: Text('Hari ini')),
                  ButtonSegment(value: 2, label: Text('Mendatang')),
                ],
                selected: {filter},
                onSelectionChanged: (selection) {
                  setState(() => filter = selection.first);
                },
              ),
              const SizedBox(height: 18),
              Expanded(
                child: currentVisible.isEmpty
                    ? _empty(context)
                    : ListView.separated(
                        itemCount: currentVisible.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 10),
                        itemBuilder: (context, index) =>
                            _card(context, currentVisible[index]),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _empty(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.schedule_outlined,
            size: 56,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 14),
          Text(
            'Belum ada titipan.',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          const Text(
            'Kalau ada yang takut kamu lupa, bilang aja.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _add,
            icon: const Icon(Icons.add),
            label: const Text('Titipkan sekarang'),
          ),
        ],
      ),
    );
  }

  Widget _card(BuildContext context, _ReminderGroup group) {
    final now = DateTime.now();
    final overdue = group.items.any(
      (r) =>
          r.recurrence == ReminderRecurrence.none &&
          r.scheduledAt.isBefore(now) &&
          r.status == ReminderStatus.active,
    );
    final multiple = group.items.length > 1;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Theme.of(context)
                  .colorScheme
                  .primary
                  .withValues(alpha: .15),
              shape: BoxShape.circle,
            ),
            child: Icon(
              overdue ? Icons.warning_amber_rounded : Icons.schedule_rounded,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  group.title,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  _dateLabel(group),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                if (multiple && group.items.every((r) => r.recurrence != ReminderRecurrence.weekly)) ...[
                  const SizedBox(height: 4),
                  Text(
                    'Diingatkan setiap jam',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
                if (overdue) ...[
                  const SizedBox(height: 4),
                  const Text(
                    'Hmm... 👀 Ini tadi mau kamu kerjakan.',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ],
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (value) async {
              if (value == 'done') {
                await _completeGroup(group);
              } else if (value == 'snooze') {
                await _snoozeNext(group);
              } else if (value == 'delete') {
                await _deleteGroup(group);
              }
            },
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'done',
                child: Text(multiple ? 'Selesai semua' : 'Selesai'),
              ),
              const PopupMenuItem(
                value: 'snooze',
                child: Text('Nanti aja • 15 menit'),
              ),
              PopupMenuItem(
                value: 'delete',
                child: Text(multiple ? 'Lupakan semua' : 'Lupakan'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ReminderGroup {
  final String key;
  final List<Reminder> items;

  _ReminderGroup({required this.key, required this.items}) {
    items.sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));
  }

  String get title => items.first.title;
  DateTime get start => items.first.scheduledAt;
  DateTime get end => items.last.scheduledAt;
}
