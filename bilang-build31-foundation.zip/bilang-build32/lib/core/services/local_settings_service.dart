import 'package:shared_preferences/shared_preferences.dart';

class LocalSettingsService {
  static const _onboardingKey = 'onboarding_completed';
  static const _characterKey = 'selected_character';

  Future<bool> isOnboardingCompleted() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_onboardingKey) ?? false;
  }

  Future<void> completeOnboarding() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_onboardingKey, true);
  }

  Future<String> getSelectedCharacter() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_characterKey) ?? 'bear';
  }

  Future<void> setSelectedCharacter(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_characterKey, id);
  }
}
