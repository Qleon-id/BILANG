import 'package:flutter/material.dart';

import 'features/onboarding/onboarding.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BilangApp());
}

class BilangApp extends StatelessWidget {
  const BilangApp({super.key});

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFFF5C542);
    const background = Color(0xFFFFFDF7);

    return MaterialApp(
      title: 'BILANG',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: primary,
          brightness: Brightness.light,
        ).copyWith(
          primary: primary,
          onPrimary: Colors.white,
          surface: Colors.white,
          onSurface: const Color(0xFF171717),
        ),
        inputDecorationTheme: const InputDecorationTheme(
          contentPadding: EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        ),
      ),
      home: const BilangOpeningScreen(),
    );
  }
}
