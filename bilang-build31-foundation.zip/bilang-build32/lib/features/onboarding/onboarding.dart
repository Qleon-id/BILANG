import 'package:flutter/material.dart';

import '../characters/character.dart';
import '../../core/services/local_settings_service.dart';
import '../app_shell/app_shell.dart';

class BilangOpeningScreen extends StatefulWidget {
  const BilangOpeningScreen({super.key});

  @override
  State<BilangOpeningScreen> createState() => _BilangOpeningScreenState();
}

class _BilangOpeningScreenState extends State<BilangOpeningScreen> {
  @override
  void initState() {
    super.initState();
    Future<void>.delayed(const Duration(milliseconds: 1100), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const BilangEntryGate()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(
      backgroundColor: primary,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 112,
              height: 112,
              decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
              child: Icon(Icons.chat_bubble_rounded, size: 56, color: Color(0xFFF5C542)),
            ),
            const SizedBox(height: 22),
            const Text(
              'BILANG',
              style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 1.2),
            ),
            const SizedBox(height: 8),
            const Text(
              'Kamu bilang. BILANG yang ingat.',
              style: TextStyle(color: Colors.white, fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}

class BilangEntryGate extends StatefulWidget {
  const BilangEntryGate({super.key});

  @override
  State<BilangEntryGate> createState() => _BilangEntryGateState();
}

class _BilangEntryGateState extends State<BilangEntryGate> {
  final settings = LocalSettingsService();
  bool? completed;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final value = await settings.isOnboardingCompleted();
    if (mounted) setState(() => completed = value);
  }

  @override
  Widget build(BuildContext context) {
    if (completed == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return completed! ? _ExistingUserEntry(settings: settings) : BilangOnboarding(settings: settings);
  }
}

class _ExistingUserEntry extends StatefulWidget {
  const _ExistingUserEntry({required this.settings});
  final LocalSettingsService settings;

  @override
  State<_ExistingUserEntry> createState() => _ExistingUserEntryState();
}

class _ExistingUserEntryState extends State<_ExistingUserEntry> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: widget.settings.getSelectedCharacter(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        return BilangAppShell(selectedCharacterId: snapshot.data!);
      },
    );
  }
}

class BilangOnboarding extends StatefulWidget {
  const BilangOnboarding({super.key, required this.settings});
  final LocalSettingsService settings;

  @override
  State<BilangOnboarding> createState() => _BilangOnboardingState();
}

class _BilangOnboardingState extends State<BilangOnboarding> {
  int page = 0;
  String selected = 'bear';

  Future<void> _finish() async {
    await widget.settings.setSelectedCharacter(selected);
    await widget.settings.completeOnboarding();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => BilangAppShell(selectedCharacterId: selected)),
      (route) => false,
    );
  }

  void _next() {
    if (page < 3) {
      setState(() => page++);
    } else {
      _finish();
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _IntroPage(onNext: _next),
      _CharacterPage(selected: selected, onSelected: (id) => setState(() => selected = id), onNext: _next),
      _PermissionPage(
        icon: Icons.mic_none_rounded,
        title: 'Biar kamu cukup bilang',
        body: 'BILANG bisa mendengarkan ucapanmu untuk menangkap apa yang ingin kamu titipkan. Izin mikrofon akan digunakan saat kamu menekan tombol BILANG.',
        button: 'Lanjut',
        onNext: _next,
      ),
      _PermissionPage(
        icon: Icons.notifications_none_rounded,
        title: 'Biar BILANG bisa mengingatkan',
        body: 'Notifikasi dipakai untuk mengingatkan titipanmu. Kamu tetap bisa memakai BILANG meski izin notifikasi tidak diberikan.',
        button: 'Mulai pakai BILANG',
        onNext: _next,
      ),
    ];

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 12),
            Row(
              children: [
                const SizedBox(width: 20),
                Text('BILANG', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900)),
                const Spacer(),
                Text('${page + 1}/4', style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(width: 20),
              ],
            ),
            Expanded(child: AnimatedSwitcher(duration: const Duration(milliseconds: 280), child: pages[page])),
          ],
        ),
      ),
    );
  }
}

class _IntroPage extends StatelessWidget {
  const _IntroPage({required this.onNext});
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) => _OnboardingFrame(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const CircleAvatar(
          radius: 62,
          backgroundColor: Color(0xFFFFE9A8),
          child: Icon(Icons.chat_bubble_rounded, size: 58, color: Color(0xFF171717)),
        ),
        const SizedBox(height: 30),
        Text('Kamu bilang.', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900)),
        Text('BILANG yang ingat.', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 14),
        const Text('Hal kecil yang takut kamu lupa, tinggal bilang aja. BILANG yang bantu ingat.', textAlign: TextAlign.center),
        const SizedBox(height: 34),
        FilledButton(onPressed: onNext, child: const Text('Lanjut')),
      ],
    ),
  );
}

class _CharacterPage extends StatelessWidget {
  const _CharacterPage({required this.selected, required this.onSelected, required this.onNext});
  final String selected;
  final ValueChanged<String> onSelected;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) => _OnboardingFrame(
    child: Column(
      children: [
        const SizedBox(height: 24),
        Text('Pilih temanmu', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('Teman ini yang akan menemani kamu mengingat.', textAlign: TextAlign.center),
        const SizedBox(height: 22),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            itemCount: bilangCharacters.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: .95,
            ),
            itemBuilder: (context, index) {
              final c = bilangCharacters[index];
              final isSelected = c.id == selected;
              return InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => onSelected(c.id),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isSelected ? Theme.of(context).colorScheme.primary.withValues(alpha: .10) : Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isSelected ? Theme.of(context).colorScheme.primary : const Color(0xFFEAE6DC),
                      width: isSelected ? 2 : 1,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      BilangCharacterAvatar(character: c, size: 74, selected: isSelected),
                      const SizedBox(height: 8),
                      Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 3),
                      Text(c.personality, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        FilledButton(onPressed: onNext, child: const Text('Pilih teman ini')),
        const SizedBox(height: 14),
      ],
    ),
  );
}

class _PermissionPage extends StatelessWidget {
  const _PermissionPage({
    required this.icon,
    required this.title,
    required this.body,
    required this.button,
    required this.onNext,
  });

  final IconData icon;
  final String title;
  final String body;
  final String button;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) => _OnboardingFrame(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CircleAvatar(
          radius: 54,
          backgroundColor: Theme.of(context).colorScheme.primary.withValues(alpha: .14),
          child: Icon(icon, size: 48),
        ),
        const SizedBox(height: 28),
        Text(title, textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Text(body, textAlign: TextAlign.center),
        const SizedBox(height: 30),
        FilledButton(onPressed: onNext, child: Text(button)),
      ],
    ),
  );
}

class _OnboardingFrame extends StatelessWidget {
  const _OnboardingFrame({required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
    child: child,
  );
}
