import 'package:flutter/material.dart';

class BilangAppShell extends StatefulWidget {
  const BilangAppShell({
    super.key,
    required this.selectedCharacterId,
  });

  final String selectedCharacterId;

  @override
  State<BilangAppShell> createState() => _BilangAppShellState();
}

class _BilangAppShellState extends State<BilangAppShell> {
  int index = 0;

  static const pages = <Widget>[
    _HomePage(),
    _PlaceholderPage(title: 'Titipan', subtitle: 'Yang sedang aku ingat untukmu.'),
    _PlaceholderPage(title: 'Ingatan', subtitle: 'Hal-hal yang pernah kamu titipkan kepadaku.'),
    _PlaceholderPage(title: 'Aku', subtitle: 'Atur teman, tema, pengingat, dan privasi.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.inbox_outlined), selectedIcon: Icon(Icons.inbox), label: 'Titipan'),
          NavigationDestination(icon: Icon(Icons.psychology_outlined), selectedIcon: Icon(Icons.psychology), label: 'Ingatan'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Aku'),
        ],
      ),
    );
  }
}

class _HomePage extends StatelessWidget {
  const _HomePage();

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 28),
        children: [
          Row(
            children: [
              const Text('BILANG', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              const Spacer(),
              IconButton(onPressed: () {}, icon: const Icon(Icons.settings_outlined), tooltip: 'Pengaturan'),
            ],
          ),
          const SizedBox(height: 34),
          const Center(
            child: CircleAvatar(
              radius: 54,
              backgroundColor: Color(0xFFFFE9A8),
              child: Text('B', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w800)),
            ),
          ),
          const SizedBox(height: 28),
          Text(
            'Selamat pagi 👋',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Text(
            'Ada yang mau kamu titipkan?',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
          const SizedBox(height: 28),
          Center(
            child: Container(
              width: 128,
              height: 128,
              decoration: BoxDecoration(
                color: primary,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: primary.withValues(alpha: .28),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: const Icon(Icons.mic_none_rounded, size: 54, color: Colors.white),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Tekan dan bilang aja', textAlign: TextAlign.center),
          const SizedBox(height: 6),
          const Text('atau ketik aja...', textAlign: TextAlign.center),
          const SizedBox(height: 26),
          TextField(
            decoration: InputDecoration(
              hintText: 'Besok jam 7 ingetin gue...',
              suffixIcon: IconButton(onPressed: () {}, icon: const Icon(Icons.arrow_forward_rounded)),
              filled: true,
              fillColor: Theme.of(context).colorScheme.surface,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 28),
          Row(
            children: [
              Text('Titipan hari ini', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
              const Spacer(),
              TextButton(onPressed: () {}, child: const Text('Lihat semua')),
            ],
          ),
          const SizedBox(height: 8),
          const _ReminderPreview(title: 'Belum ada titipan', subtitle: 'Kepalamu boleh istirahat dulu. 😌'),
        ],
      ),
    );
  }
}

class _ReminderPreview extends StatelessWidget {
  const _ReminderPreview({required this.title, required this.subtitle});
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFEAE6DC)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(subtitle, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ],
      ),
    );
  }
}

class _PlaceholderPage extends StatelessWidget {
  const _PlaceholderPage({required this.title, required this.subtitle});
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(title, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Text(subtitle, textAlign: TextAlign.center),
              const SizedBox(height: 20),
              const Text('BUILD 32 — App Shell aktif.'),
            ],
          ),
        ),
      ),
    );
  }
}
