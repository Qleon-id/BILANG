# BILANG

**Kamu bilang. BILANG yang ingat.**

## BUILD 32 — App Shell + Opening + Onboarding

This build adds the first real BILANG app flow on top of the BUILD 31 foundation:

- Opening screen on every launch
- First-install onboarding
- Character selection with 8 companion choices
- Persistent onboarding completion
- Persistent selected character
- Microphone permission explanation screen
- Notification permission explanation screen
- Bottom navigation shell
- Home screen foundation
- Titipan / Ingatan / Aku placeholder pages for the app shell
- Warm yellow BILANG visual foundation

### Current limitation

The permission pages in BUILD 32 are **explanation/flow screens only**. Actual Android/iOS runtime permission requests will be integrated in the dedicated voice/notification implementation stages.

Character illustrations in this foundation use a lightweight custom-painted placeholder style. The final original character asset set and all character states will be integrated in the Character System stage.

BUILD 32 is an implementation milestone, not the complete BILANG V1.0.
