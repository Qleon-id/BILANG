import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../models/reminder.dart';
import '../models/user_settings.dart';
import '../repositories/reminder_repository.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  bool? _notificationsGranted;
  bool? _exactAlarmGranted;
  bool _exactPermissionPrompted = false;

  static const String _channelId = 'bilang_reminders_v3';

  Future<void> initialize() async {
    if (_initialized) return;

    tz.initializeTimeZones();
    try {
      final timezone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(timezone.identifier));
    } catch (_) {}

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings: settings);

    final androidPlugin = _androidPlugin;
    await androidPlugin?.createNotificationChannel(
      const AndroidNotificationChannel(
        _channelId,
        'Titipan BILANG',
        description: 'Pengingat untuk Titipan yang kamu simpan di BILANG.',
        importance: Importance.high,
      ),
    );

    _initialized = true;
  }

  AndroidFlutterLocalNotificationsPlugin? get _androidPlugin =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  Future<bool> requestNotificationPermission() async {
    await initialize();
    final granted =
        await _androidPlugin?.requestNotificationsPermission() ?? true;
    _notificationsGranted = granted;
    return granted;
  }

  Future<bool> notificationsEnabledOnDevice() async {
    await initialize();
    final enabled = await _androidPlugin?.areNotificationsEnabled() ?? true;
    _notificationsGranted = enabled;
    return enabled;
  }

  Future<bool> exactAlarmsEnabledOnDevice() async {
    await initialize();
    final enabled = await _androidPlugin?.canScheduleExactNotifications() ?? true;
    _exactAlarmGranted = enabled;
    return enabled;
  }

  Future<bool> requestExactAlarmPermission() async {
    await initialize();
    if (_exactPermissionPrompted) {
      return exactAlarmsEnabledOnDevice();
    }
    _exactPermissionPrompted = true;
    final granted = await _androidPlugin?.requestExactAlarmsPermission();
    _exactAlarmGranted = granted ?? await exactAlarmsEnabledOnDevice();
    return _exactAlarmGranted ?? false;
  }

  /// BILANG prefers exact alarms for user-requested reminders. If the user
  /// declines the Android special access, we gracefully fall back to inexact
  /// scheduling rather than silently dropping the reminder.
  Future<bool> ensureAndroidPermissions() async {
    final notifications =
        _notificationsGranted ?? await requestNotificationPermission();
    return notifications;
  }

  Future<void> scheduleReminder(
    Reminder reminder,
    UserSettings settings,
  ) async {
    await initialize();
    if (!settings.notificationsEnabled) return;
    if (reminder.status != ReminderStatus.active &&
        reminder.status != ReminderStatus.snoozed) {
      return;
    }

    final scheduled = reminder.scheduledAt;
    if (scheduled.isBefore(DateTime.now())) return;
    if (_isQuietTime(scheduled, settings) &&
        !(reminder.priority == ReminderPriority.important &&
            settings.importantReminderDuringQuietHours)) {
      return;
    }

    final permissionsGranted = await ensureAndroidPermissions();
    if (!permissionsGranted) return;

    // On Android 13+, permission can be revoked after onboarding. Do not
    // silently schedule into a disabled notification channel/app state.
    if (!await notificationsEnabledOnDevice()) return;

    // BILANG reminders are user-requested time-sensitive actions. Use exact
    // alarms when Android grants the special access; otherwise fall back to
    // an inexact alarm instead of failing silently.
    var exact = await exactAlarmsEnabledOnDevice();
    if (!exact) {
      exact = await requestExactAlarmPermission();
      // When Android returns from the special-access screen, re-check the
      // actual state before choosing the schedule mode.
      await Future<void>.delayed(const Duration(milliseconds: 250));
      exact = await exactAlarmsEnabledOnDevice();
    }

    final id = _notificationId(reminder.id);
    await _plugin.cancel(id: id);

    final body = _body(reminder, settings);
    final androidDetails = AndroidNotificationDetails(
      _channelId,
      'Titipan BILANG',
      channelDescription: 'Pengingat untuk Titipan yang kamu simpan di BILANG.',
      importance: Importance.high,
      priority: Priority.high,
      playSound: settings.soundEnabled,
      enableVibration: settings.vibrationEnabled,
      visibility: settings.notificationPreview
          ? NotificationVisibility.public
          : NotificationVisibility.private,
    );

    final match = switch (reminder.recurrence) {
      ReminderRecurrence.none => null,
      ReminderRecurrence.daily => DateTimeComponents.time,
      ReminderRecurrence.weekly => DateTimeComponents.dayOfWeekAndTime,
      ReminderRecurrence.monthly => DateTimeComponents.dayOfMonthAndTime,
      ReminderRecurrence.custom => null,
    };

    final scheduledDate = tz.TZDateTime.from(scheduled, tz.local);
    await _plugin.zonedSchedule(
      id: id,
      title: 'BILANG',
      body: body,
      scheduledDate: scheduledDate,
      notificationDetails: NotificationDetails(android: androidDetails),
      // Prefer exact delivery when the user has granted Android's
      // "Alarms & reminders" access; otherwise use the inexact fallback.
      androidScheduleMode: exact
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: match,
      payload: reminder.id,
    );
  }

  Future<void> cancelReminder(String reminderId) async {
    await initialize();
    await _plugin.cancel(id: _notificationId(reminderId));
  }

  Future<void> rescheduleAll(
    ReminderRepository repository,
    UserSettings settings,
  ) async {
    await initialize();
    if (!settings.notificationsEnabled) return;
    final reminders = await repository.getActiveReminders();
    if (reminders.isEmpty) return;

    if (!await ensureAndroidPermissions()) return;
    for (final reminder in reminders) {
      await scheduleReminder(reminder, settings);
    }
  }

  String _body(Reminder reminder, UserSettings settings) {
    if (!settings.notificationPreview) return 'Kamu punya satu titipan.';

    return switch (settings.notificationStyle) {
      NotificationStyle.natural =>
        'Hei, kamu tadi nitip sesuatu. 👀\n${reminder.title}',
      NotificationStyle.short =>
        '${reminder.title} — ${_time(reminder.scheduledAt)}',
      NotificationStyle.casual => 'Eh, jangan lupa ${reminder.title} 👀',
    };
  }

  String _time(DateTime value) =>
      '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';

  bool _isQuietTime(DateTime value, UserSettings settings) {
    if (!settings.quietHoursEnabled) return false;
    final minute = value.hour * 60 + value.minute;
    final start = _parseMinute(settings.quietStart);
    final end = _parseMinute(settings.quietEnd);
    if (start == null || end == null || start == end) return false;
    if (start < end) return minute >= start && minute < end;
    return minute >= start || minute < end;
  }

  int? _parseMinute(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour > 23 || minute > 59) return null;
    return hour * 60 + minute;
  }

  int _notificationId(String value) => value.hashCode & 0x7fffffff;
}
