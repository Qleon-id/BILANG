import '../models/reminder.dart';
import '../repositories/reminder_repository.dart';

class ReminderService {
  final ReminderRepository repository;
  ReminderService(this.repository);

  Future<Reminder> create({required String title, required DateTime scheduledAt, ReminderRecurrence recurrence = ReminderRecurrence.none, ReminderPriority priority = ReminderPriority.normal, ReminderSource source = ReminderSource.manual}) async {
    final now = DateTime.now();
    final reminder = Reminder(id: now.microsecondsSinceEpoch.toString(), title: title.trim(), scheduledAt: scheduledAt, timezone: DateTime.now().timeZoneName, createdAt: now, updatedAt: now, recurrence: recurrence, priority: priority, source: source);
    return repository.createReminder(reminder);
  }

  Future<void> complete(String id) => repository.completeReminder(id);
  Future<void> delete(String id) => repository.deleteReminder(id);
  Future<void> snooze(String id, DateTime until) => repository.snoozeReminder(id, until);
}
