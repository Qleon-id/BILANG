import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/reminder.dart';
import 'reminder_repository.dart';

class SharedPreferencesReminderRepository implements ReminderRepository {
  static const _key = 'bilang.reminders.v1';
  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  Future<List<Reminder>> _read() async {
    final prefs = await _prefs;
    final raw = prefs.getStringList(_key) ?? const [];
    return raw.map((item) => Reminder.fromJson(jsonDecode(item) as Map<String, dynamic>)).toList();
  }

  Future<void> _write(List<Reminder> reminders) async {
    final prefs = await _prefs;
    await prefs.setStringList(_key, reminders.map((r) => jsonEncode(r.toJson())).toList());
  }

  @override Future<Reminder> createReminder(Reminder reminder) async { final list = await _read(); list.add(reminder); await _write(list); return reminder; }
  @override Future<List<Reminder>> getReminders() async { final list = await _read(); list.sort((a,b)=>a.scheduledAt.compareTo(b.scheduledAt)); return list; }
  @override Future<Reminder?> getReminderById(String id) async { for (final r in await _read()) { if (r.id == id) return r; } return null; }
  @override Future<void> updateReminder(Reminder reminder) async { final list=await _read(); final i=list.indexWhere((r)=>r.id==reminder.id); if(i<0) return; list[i]=reminder; await _write(list); }
  @override Future<void> completeReminder(String id) async { final r=await getReminderById(id); if(r==null) return; await updateReminder(r.copyWith(status: ReminderStatus.completed)); }
  @override Future<void> deleteReminder(String id) async { final list=await _read(); list.removeWhere((r)=>r.id==id); await _write(list); }
  @override Future<List<Reminder>> searchReminders(String query) async { final q=query.trim().toLowerCase(); return (await _read()).where((r)=>r.title.toLowerCase().contains(q)).toList(); }
  @override Future<List<Reminder>> getActiveReminders() async => (await _read()).where((r)=>r.status==ReminderStatus.active || r.status==ReminderStatus.snoozed).toList();
  @override Future<List<Reminder>> getUpcomingReminders() async { final now=DateTime.now(); return (await _read()).where((r)=>r.status==ReminderStatus.active && r.scheduledAt.isAfter(now)).toList(); }
  @override Future<List<Reminder>> getOverdueReminders() async { final now=DateTime.now(); return (await _read()).where((r)=>r.status==ReminderStatus.active && r.scheduledAt.isBefore(now)).toList(); }
  @override Future<void> snoozeReminder(String id, DateTime until) async { final r=await getReminderById(id); if(r==null) return; await updateReminder(r.copyWith(scheduledAt: until, status: ReminderStatus.snoozed)); }
  @override Future<void> dismissReminder(String id) async { final r=await getReminderById(id); if(r==null) return; await updateReminder(r.copyWith(status: ReminderStatus.dismissed)); }
}
