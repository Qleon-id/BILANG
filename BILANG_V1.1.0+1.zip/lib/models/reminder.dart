enum ReminderStatus { active, triggered, completed, snoozed, dismissed }
enum ReminderRecurrence { none, daily, weekly, monthly, custom }
enum ReminderSource { voice, text, manual }
enum ReminderPriority { normal, important }

class Reminder {
  final String id;
  final String title;
  final DateTime scheduledAt;
  final String timezone;
  final DateTime createdAt;
  final DateTime updatedAt;
  final ReminderStatus status;
  final ReminderRecurrence recurrence;
  final ReminderPriority priority;
  final Duration? reminderLeadTime;
  final ReminderSource source;
  final String? parentReminderId;
  final String? occurrenceId;

  const Reminder({
    required this.id,
    required this.title,
    required this.scheduledAt,
    required this.timezone,
    required this.createdAt,
    required this.updatedAt,
    this.status = ReminderStatus.active,
    this.recurrence = ReminderRecurrence.none,
    this.priority = ReminderPriority.normal,
    this.reminderLeadTime,
    this.source = ReminderSource.manual,
    this.parentReminderId,
    this.occurrenceId,
  });

  Reminder copyWith({
    String? title,
    DateTime? scheduledAt,
    String? timezone,
    DateTime? updatedAt,
    ReminderStatus? status,
    ReminderRecurrence? recurrence,
    ReminderPriority? priority,
    Duration? reminderLeadTime,
    ReminderSource? source,
    String? parentReminderId,
    String? occurrenceId,
  }) => Reminder(
    id: id,
    title: title ?? this.title,
    scheduledAt: scheduledAt ?? this.scheduledAt,
    timezone: timezone ?? this.timezone,
    createdAt: createdAt,
    updatedAt: updatedAt ?? DateTime.now(),
    status: status ?? this.status,
    recurrence: recurrence ?? this.recurrence,
    priority: priority ?? this.priority,
    reminderLeadTime: reminderLeadTime ?? this.reminderLeadTime,
    source: source ?? this.source,
    parentReminderId: parentReminderId ?? this.parentReminderId,
    occurrenceId: occurrenceId ?? this.occurrenceId,
  );

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'scheduledAt': scheduledAt.toIso8601String(),
    'timezone': timezone, 'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(), 'status': status.name,
    'recurrence': recurrence.name, 'priority': priority.name,
    'reminderLeadTime': reminderLeadTime?.inMinutes, 'source': source.name,
    'parentReminderId': parentReminderId, 'occurrenceId': occurrenceId,
  };

  factory Reminder.fromJson(Map<String, dynamic> json) => Reminder(
    id: json['id'] as String,
    title: json['title'] as String,
    scheduledAt: DateTime.parse(json['scheduledAt'] as String),
    timezone: json['timezone'] as String? ?? 'local',
    createdAt: DateTime.parse(json['createdAt'] as String),
    updatedAt: DateTime.parse(json['updatedAt'] as String),
    status: ReminderStatus.values.byName(json['status'] as String? ?? 'active'),
    recurrence: ReminderRecurrence.values.byName(json['recurrence'] as String? ?? 'none'),
    priority: ReminderPriority.values.byName(json['priority'] as String? ?? 'normal'),
    reminderLeadTime: (json['reminderLeadTime'] as num?) == null ? null : Duration(minutes: (json['reminderLeadTime'] as num).toInt()),
    source: ReminderSource.values.byName(json['source'] as String? ?? 'manual'),
    parentReminderId: json['parentReminderId'] as String?,
    occurrenceId: json['occurrenceId'] as String?,
  );
}
