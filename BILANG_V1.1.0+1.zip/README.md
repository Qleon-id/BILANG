# BILANG V1.1.0 — Reminder Engine

**Tagline:** Kamu bilang. BILANG yang ingat.

V1.1 turns the reminder foundation into a usable local reminder system.

## Scope
- Persistent local reminder storage with SharedPreferences.
- Create reminders manually from Titipan.
- Date and time selection.
- Reminder recurrence field: none/daily/weekly/monthly/custom (definition is stored; scheduling/occurrences are later).
- Complete, snooze 15 minutes, and forget reminders.
- All/Hari ini/Mendatang filtering.
- Home shows today's active reminders.
- Reminder model serialization and service layer.

## Deliberately not in V1.1
- Natural-language parsing (V1.2).
- Voice recognition (V1.3).
- OS notification scheduling (V1.4).
- Full recurring occurrence engine and reboot/timezone reconciliation are staged for later refinement.
- Android launcher icon replacement remains deferred.

## Android Build
BILANG is Android-only for this development track. The existing GitHub Actions workflow remains the build path.
