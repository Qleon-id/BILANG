import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:bilang/core/theme/bilang_theme.dart';

void main() {
  test('all accent themes can create light and dark themes', () {
    for (final definition in bilangThemes) {
      final light = buildBilangTheme(definition.id, brightness: Brightness.light);
      final dark = buildBilangTheme(definition.id, brightness: Brightness.dark);
      expect(light.brightness, Brightness.light);
      expect(dark.brightness, Brightness.dark);
      expect(light.colorScheme.primary, definition.primary);
      expect(dark.colorScheme.primary, definition.primary);
    }
  });
}
