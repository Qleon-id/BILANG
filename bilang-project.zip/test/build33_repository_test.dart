import 'package:flutter_test/flutter_test.dart';
import 'package:bilang/data/models/memory.dart';
import 'package:bilang/data/models/reminder.dart';

void main() {
  test('Reminder round-trips through map', () {
    final original = Reminder(
      id: 'r1',
      title: 'Bawa charger',
      scheduledAt: DateTime(2026, 9, 23, 7),
    );
    final restored = Reminder.fromMap(original.toMap());
    expect(restored.id, original.id);
    expect(restored.title, original.title);
    expect(restored.scheduledAt, original.scheduledAt);
    expect(restored.status, ReminderStatus.active);
  });

  test('Memory round-trips through map', () {
    final original = Memory(
      id: 'm1',
      title: 'Nomor loker',
      content: '27',
      type: MemoryType.fact,
      category: MemoryCategory.study,
    );
    final restored = Memory.fromMap(original.toMap());
    expect(restored.id, original.id);
    expect(restored.title, original.title);
    expect(restored.content, original.content);
    expect(restored.type, MemoryType.fact);
    expect(restored.category, MemoryCategory.study);
  });
}
