import 'package:flutter_test/flutter_test.dart';
import 'package:bilang/features/characters/character.dart';

void main() {
  test('BILANG has eight default companions', () {
    expect(bilangCharacters.length, 8);
    expect(characterById('cat').name, 'Cat');
    expect(characterById('unknown').id, 'bear');
  });
}
