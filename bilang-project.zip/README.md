# BILANG — BUILD 34

BUILD 34 menambahkan sistem tema personalisasi BILANG.

- 15 pilihan warna tema.
- Tema tersimpan secara lokal.
- Tema dapat diganti dari Aku > Tema.
- Warna tema diterapkan ke Material UI dan opening screen.
- Data titipan, ingatan, dan karakter dari BUILD 33 tetap dipertahankan.

Catatan: build Flutter nyata tetap perlu dijalankan pada lingkungan Flutter.


## BUILD 35 — Aku & Personalization

Build 35 makes the Aku settings area functional and persistent. It adds local settings for reminders, notification preview, sound/vibration, quiet hours, contextual memory, language, response style, privacy data clearing, and About BILANG. Theme selection remains persistent.

This build does not yet implement the real Android notification engine, speech-to-text, or full BILANG natural-language engine.
