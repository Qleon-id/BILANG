# BILANG — BUILD 41

## Voice & Speech foundation

BUILD 38 adds the voice input layer for BILANG: listening state, speech-to-text service, Indonesian locale default, transcript stream, stop/cancel handling, and friendly error/unavailable UI. Voice is an input source only; audio is not stored as memory by default.

### Flow
HOME → LISTENING → Speech-to-Text → PROCESSING → BILANG Engine → confirmation/clarification.

### Notes
- Requires microphone permission at runtime.
- `speech_to_text` is used for speech recognition.
- The app still needs platform-specific permission configuration and a real Flutter build/test before release.
- No TTS is included in V1.


## BUILD 39 — Integration & Real-World Edge Cases

This build connects the core BILANG systems at the service layer and adds safer real-world reconciliation:
- short-lived conversational context with 10-minute expiry
- text input -> NLU result -> explicit confirmation -> execution
- reminder create/reschedule/complete/delete execution with notification resync
- memory create/read/update/delete execution
- sensitive-memory guard for password/PIN/OTP/CVV-like content
- best-effort notification reconciliation whenever the app resumes
- integration tests for context expiry and missing-time clarification

Important: Flutter platform builds/tests still require a local Flutter SDK and platform configuration. This ZIP is a source snapshot and has not been claimed as a verified Android/iOS build.


## BUILD 40 — Testing, Polish & V1 Readiness

BUILD 40 focuses on hardening the systems already built instead of adding a large new feature set.

### Included
- Defensive data-integrity checks for reminder and memory records.
- Delete-all-data flow now also cancels all scheduled local notifications.
- About version updated to 1.0.0+10.
- Regression test coverage for duplicate/empty records and valid memory data.
- Existing onboarding, themes, characters, local persistence, NLU, voice, notifications, and integration layers are retained.

### V1 readiness checklist
- [x] Local reminder/memory persistence foundation
- [x] Theme and character persistence
- [x] Notification scheduling foundation
- [x] Natural-language engine foundation
- [x] Voice input foundation
- [x] Integration/context foundation
- [x] Sensitive-content guard foundation
- [x] Data-reset notification cleanup
- [ ] Real Android device build/test
- [ ] Real iOS build/test
- [ ] Permission behavior verification on physical devices
- [ ] Notification behavior verification after reboot/timezone changes
- [ ] Accessibility and large-text pass

Flutter SDK was not available in the generation environment, so no claim is made that the Flutter application has been compiled here.


## BUILD 41 — Accessibility, Dark Mode & UX Hardening

BUILD 41 adds user-facing display-mode controls and accessibility-oriented hardening.
- Light / Dark / System appearance modes are persisted.
- Dark theme surfaces and text contrast are provided for all 15 accent themes.
- Display mode is available under Aku.
- Existing theme selection remains independent from display mode.
- No reminder or memory data is changed by appearance settings.

Flutter platform builds still require a local Flutter SDK and physical-device verification.


## Android test repair

Build 41 Android test fixes: corrected App Shell syntax, updated flutter_timezone 5.1.0 API usage to `TimezoneInfo.identifier`, and the Android CI workflow removes the generated Flutter sample widget test.
