import 'package:flutter/material.dart';

class BilangThemeDefinition {
  const BilangThemeDefinition({required this.id, required this.name, required this.primary});
  final String id;
  final String name;
  final Color primary;
}

const bilangThemes = <BilangThemeDefinition>[
  BilangThemeDefinition(id: 'yellow', name: 'Kuning', primary: Color(0xFFF5C542)),
  BilangThemeDefinition(id: 'red', name: 'Merah', primary: Color(0xFFE45858)),
  BilangThemeDefinition(id: 'orange', name: 'Orange', primary: Color(0xFFF28C28)),
  BilangThemeDefinition(id: 'blue', name: 'Biru', primary: Color(0xFF4E7CF6)),
  BilangThemeDefinition(id: 'lightBlue', name: 'Biru Muda', primary: Color(0xFF55B8E8)),
  BilangThemeDefinition(id: 'darkGreen', name: 'Hijau Tua', primary: Color(0xFF3E7D57)),
  BilangThemeDefinition(id: 'lightGreen', name: 'Hijau Muda', primary: Color(0xFF72B66A)),
  BilangThemeDefinition(id: 'sage', name: 'Sage', primary: Color(0xFF8FA88A)),
  BilangThemeDefinition(id: 'navy', name: 'Biru Dongker', primary: Color(0xFF304A72)),
  BilangThemeDefinition(id: 'purple', name: 'Ungu', primary: Color(0xFF8067C9)),
  BilangThemeDefinition(id: 'pink', name: 'Pink', primary: Color(0xFFD86B9A)),
  BilangThemeDefinition(id: 'brown', name: 'Cokelat', primary: Color(0xFF956B4B)),
  BilangThemeDefinition(id: 'milkBrown', name: 'Cokelat Susu', primary: Color(0xFFB78C6A)),
  BilangThemeDefinition(id: 'gray', name: 'Abu-abu', primary: Color(0xFF777777)),
  BilangThemeDefinition(id: 'charcoal', name: 'Charcoal', primary: Color(0xFF3B3B3B)),
];

BilangThemeDefinition bilangThemeById(String id) =>
    bilangThemes.firstWhere((theme) => theme.id == id, orElse: () => bilangThemes.first);

ThemeData buildBilangTheme(String id) {
  final definition = bilangThemeById(id);
  return ThemeData(
    useMaterial3: true,
    scaffoldBackgroundColor: const Color(0xFFFFFDF7),
    colorScheme: ColorScheme.fromSeed(
      seedColor: definition.primary,
      brightness: Brightness.light,
    ).copyWith(
      primary: definition.primary,
      onPrimary: Colors.white,
      surface: Colors.white,
      onSurface: const Color(0xFF171717),
    ),
    inputDecorationTheme: const InputDecorationTheme(
      contentPadding: EdgeInsets.symmetric(horizontal: 18, vertical: 16),
    ),
  );
}
