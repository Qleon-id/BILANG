import 'package:shared_preferences/shared_preferences.dart';

class LocalSettingsService {
  static const _onboardingKey = 'onboarding_completed';
  static const _characterKey = 'selected_character';
  static const _themeKey = 'selected_theme';
  static const _themeModeKey = 'app_theme_mode';
  static const _notificationsKey = 'notifications_enabled';
  static const _previewKey = 'notification_preview';
  static const _soundKey = 'sound_enabled';
  static const _vibrationKey = 'vibration_enabled';
  static const _quietKey = 'quiet_hours_enabled';
  static const _quietStartKey = 'quiet_start';
  static const _quietEndKey = 'quiet_end';
  static const _importantQuietKey = 'important_reminder_during_quiet_hours';
  static const _contextualMemoryKey = 'contextual_memory_enabled';
  static const _languageKey = 'language';
  static const _responseStyleKey = 'response_style';

  Future<SharedPreferences> get _prefs => SharedPreferences.getInstance();

  Future<bool> isOnboardingCompleted() async => (await _prefs).getBool(_onboardingKey) ?? false;
  Future<void> completeOnboarding() async => (await _prefs).setBool(_onboardingKey, true);

  Future<String> getSelectedCharacter() async => (await _prefs).getString(_characterKey) ?? 'bear';
  Future<void> setSelectedCharacter(String id) async => (await _prefs).setString(_characterKey, id);

  Future<String> getSelectedTheme() async => (await _prefs).getString(_themeKey) ?? 'yellow';
  Future<void> setSelectedTheme(String id) async => (await _prefs).setString(_themeKey, id);

  Future<String> getAppThemeMode() async => (await _prefs).getString(_themeModeKey) ?? 'system';
  Future<void> setAppThemeMode(String value) async => (await _prefs).setString(_themeModeKey, value);

  Future<bool> getNotificationsEnabled() async => (await _prefs).getBool(_notificationsKey) ?? true;
  Future<void> setNotificationsEnabled(bool value) async => (await _prefs).setBool(_notificationsKey, value);

  Future<bool> getNotificationPreview() async => (await _prefs).getBool(_previewKey) ?? true;
  Future<void> setNotificationPreview(bool value) async => (await _prefs).setBool(_previewKey, value);

  Future<bool> getSoundEnabled() async => (await _prefs).getBool(_soundKey) ?? true;
  Future<void> setSoundEnabled(bool value) async => (await _prefs).setBool(_soundKey, value);

  Future<bool> getVibrationEnabled() async => (await _prefs).getBool(_vibrationKey) ?? true;
  Future<void> setVibrationEnabled(bool value) async => (await _prefs).setBool(_vibrationKey, value);

  Future<bool> getQuietHoursEnabled() async => (await _prefs).getBool(_quietKey) ?? true;
  Future<void> setQuietHoursEnabled(bool value) async => (await _prefs).setBool(_quietKey, value);

  Future<String> getQuietStart() async => (await _prefs).getString(_quietStartKey) ?? '22:00';
  Future<void> setQuietStart(String value) async => (await _prefs).setString(_quietStartKey, value);

  Future<String> getQuietEnd() async => (await _prefs).getString(_quietEndKey) ?? '06:00';
  Future<void> setQuietEnd(String value) async => (await _prefs).setString(_quietEndKey, value);

  Future<bool> getImportantReminderDuringQuietHours() async => (await _prefs).getBool(_importantQuietKey) ?? false;
  Future<void> setImportantReminderDuringQuietHours(bool value) async => (await _prefs).setBool(_importantQuietKey, value);

  Future<bool> getContextualMemoryEnabled() async => (await _prefs).getBool(_contextualMemoryKey) ?? true;
  Future<void> setContextualMemoryEnabled(bool value) async => (await _prefs).setBool(_contextualMemoryKey, value);

  Future<String> getLanguage() async => (await _prefs).getString(_languageKey) ?? 'id';
  Future<void> setLanguage(String value) async => (await _prefs).setString(_languageKey, value);

  Future<String> getResponseStyle() async => (await _prefs).getString(_responseStyleKey) ?? 'casual';
  Future<void> setResponseStyle(String value) async => (await _prefs).setString(_responseStyleKey, value);

  Future<void> resetSettings() async {
    final prefs = await _prefs;
    for (final key in [
      _onboardingKey, _characterKey, _themeKey, _themeModeKey, _notificationsKey,
      _previewKey, _soundKey, _vibrationKey, _quietKey, _quietStartKey, _quietEndKey,
      _importantQuietKey, _contextualMemoryKey, _languageKey, _responseStyleKey,
    ]) {
      await prefs.remove(key);
    }
  }
}
