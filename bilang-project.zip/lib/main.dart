import 'package:flutter/material.dart';

import 'core/services/local_settings_service.dart';
import 'core/theme/bilang_theme.dart';
import 'core/services/app_lifecycle_reconciler.dart';
import 'features/onboarding/onboarding.dart';
import 'features/notifications/notification_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BilangApp());
}

class BilangApp extends StatefulWidget {
  const BilangApp({super.key});

  @override
  State<BilangApp> createState() => _BilangAppState();
}

class _BilangAppState extends State<BilangApp> {
  String selectedTheme = 'yellow';
  final AppLifecycleReconciler _lifecycleReconciler = AppLifecycleReconciler();

  @override
  void initState() {
    super.initState();
    _lifecycleReconciler.attach();
    _loadTheme();
    NotificationService.instance.initialize().then((_) => NotificationService.instance.rescheduleAll());
  }


  @override
  void dispose() {
    _lifecycleReconciler.dispose();
    super.dispose();
  }

  Future<void> _loadTheme() async {
    final theme = await LocalSettingsService().getSelectedTheme();
    if (mounted) setState(() => selectedTheme = theme);
  }

  void _setTheme(String id) {
    setState(() => selectedTheme = id);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BILANG',
      debugShowCheckedModeBanner: false,
      theme: buildBilangTheme(selectedTheme),
      home: BilangOpeningScreen(onThemeChanged: _setTheme),
    );
  }
}
