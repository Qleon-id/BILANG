import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/memory.dart';

class MemoryRepository {
  static const _key = 'bilang_memories_v1';

  Future<List<Memory>> getMemories() async {
    final prefs = await SharedPreferences.getInstance();
    final values = prefs.getStringList(_key) ?? <String>[];
    final memories = <Memory>[];
    for (final value in values) {
      try {
        memories.add(Memory.fromJson(value));
      } catch (_) {}
    }
    return memories;
  }

  Future<void> save(Memory memory) async {
    final memories = await getMemories();
    final index = memories.indexWhere((item) => item.id == memory.id);
    if (index >= 0) {
      memories[index] = memory;
    } else {
      memories.insert(0, memory);
    }
    await _write(memories);
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  Future<void> delete(String id) async {
    final memories = await getMemories();
    memories.removeWhere((item) => item.id == id);
    await _write(memories);
  }

  Future<void> _write(List<Memory> memories) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_key, memories.map((item) => jsonEncode(item.toMap())).toList());
  }
}
