import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/reminder.dart';

class ReminderRepository {
  static const _key = 'bilang_reminders_v1';

  Future<List<Reminder>> getReminders() async {
    final prefs = await SharedPreferences.getInstance();
    final values = prefs.getStringList(_key) ?? <String>[];
    final reminders = <Reminder>[];
    for (final value in values) {
      try {
        reminders.add(Reminder.fromJson(value));
      } catch (_) {}
    }
    reminders.sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));
    return reminders;
  }

  Future<void> save(Reminder reminder) async {
    final reminders = await getReminders();
    final index = reminders.indexWhere((item) => item.id == reminder.id);
    if (index >= 0) {
      reminders[index] = reminder;
    } else {
      reminders.add(reminder);
    }
    await _write(reminders);
  }

  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  Future<void> delete(String id) async {
    final reminders = await getReminders();
    reminders.removeWhere((item) => item.id == id);
    await _write(reminders);
  }

  Future<void> clearCompleted() async {
    final reminders = await getReminders();
    reminders.removeWhere((item) => item.status == ReminderStatus.completed);
    await _write(reminders);
  }

  Future<void> _write(List<Reminder> reminders) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(_key, reminders.map((item) => jsonEncode(item.toMap())).toList());
  }
}
