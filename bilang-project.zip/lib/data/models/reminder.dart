import 'dart:convert';

enum ReminderStatus { active, triggered, completed, snoozed, dismissed }

class Reminder {
  const Reminder({
    required this.id,
    required this.title,
    required this.scheduledAt,
    this.status = ReminderStatus.active,
  });

  final String id;
  final String title;
  final DateTime scheduledAt;
  final ReminderStatus status;

  Reminder copyWith({String? title, DateTime? scheduledAt, ReminderStatus? status}) {
    return Reminder(
      id: id,
      title: title ?? this.title,
      scheduledAt: scheduledAt ?? this.scheduledAt,
      status: status ?? this.status,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'scheduledAt': scheduledAt.toIso8601String(),
        'status': status.name,
      };

  factory Reminder.fromMap(Map<String, dynamic> map) => Reminder(
        id: map['id'] as String,
        title: map['title'] as String,
        scheduledAt: DateTime.parse(map['scheduledAt'] as String),
        status: ReminderStatus.values.firstWhere(
          (value) => value.name == map['status'],
          orElse: () => ReminderStatus.active,
        ),
      );

  String toJson() => jsonEncode(toMap());
  factory Reminder.fromJson(String value) => Reminder.fromMap(jsonDecode(value) as Map<String, dynamic>);
}
