import 'dart:convert';

enum MemoryType { fact, preference, context, note }
enum MemoryCategory { personal, home, study, work, finance, other }

class Memory {
  const Memory({
    required this.id,
    required this.title,
    required this.content,
    required this.type,
    required this.category,
  });

  final String id;
  final String title;
  final String content;
  final MemoryType type;
  final MemoryCategory category;

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'content': content,
        'type': type.name,
        'category': category.name,
      };

  factory Memory.fromMap(Map<String, dynamic> map) => Memory(
        id: map['id'] as String,
        title: map['title'] as String,
        content: map['content'] as String,
        type: MemoryType.values.firstWhere(
          (value) => value.name == map['type'],
          orElse: () => MemoryType.note,
        ),
        category: MemoryCategory.values.firstWhere(
          (value) => value.name == map['category'],
          orElse: () => MemoryCategory.other,
        ),
      );

  String toJson() => jsonEncode(toMap());
  factory Memory.fromJson(String value) => Memory.fromMap(jsonDecode(value) as Map<String, dynamic>);
}
