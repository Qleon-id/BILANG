import '../models/bilang_result.dart';
import '../parsers/date_parser.dart';
import '../parsers/language_normalizer.dart';
import '../parsers/recurrence_parser.dart';
import '../parsers/time_parser.dart';

class BilangEngine {
  const BilangEngine();

  BilangResult processInput(String input, {DateTime? now}) {
    final original = input.trim();
    final text = LanguageNormalizer.normalize(original);
    final current = now ?? DateTime.now();

    if (text.isEmpty) {
      return const BilangResult(
        intent: BilangIntent.unknown,
        confidence: BilangConfidence.low,
        clarification: 'Coba bilang atau ketik apa yang ingin kamu titipkan.',
      );
    }

    if (_isCancel(text)) {
      return const BilangResult(intent: BilangIntent.cancel, confidence: BilangConfidence.high);
    }

    final memory = _memoryResult(original, text);
    if (memory != null) return memory;

    final update = _updateResult(original, text, current);
    if (update != null) return update;

    final reminder = _reminderResult(original, text, current);
    if (reminder != null) return reminder;

    return const BilangResult(
      intent: BilangIntent.unknown,
      confidence: BilangConfidence.low,
      clarification: 'Aku belum yakin menangkap maksudmu. Coba bilang sekali lagi.',
    );
  }

  bool _isCancel(String text) =>
      text == 'batal' || text == 'cancel' || text == 'nggak jadi' || text == 'tidak jadi';

  BilangResult? _memoryResult(String original, String text) {
    final asks = text.contains('berapa') || text.contains('apa') || text.contains('mana');
    final loker = text.contains('nomor loker') || text.contains('loker');
    if (asks && loker) {
      return const BilangResult(
        intent: BilangIntent.readMemory,
        confidence: BilangConfidence.high,
        content: 'nomor loker',
        title: 'Nomor loker',
        targetQuery: 'nomor loker',
      );
    }

    // Handle explicit updates before the generic fact-creation branch,
    // so "Nomor loker gue sekarang 35" updates the existing memory
    // instead of creating a second memory.
    if (text.contains('sekarang') && text.contains('nomor loker')) {
      final value = _memoryValue(original, 'nomor loker');
      if (value.isNotEmpty) {
        return BilangResult(
          intent: BilangIntent.updateMemory,
          confidence: BilangConfidence.high,
          title: 'Nomor loker',
          content: value,
          targetQuery: 'nomor loker',
        );
      }
    }

    if (_containsAny(text, ['nomor ', 'ukuran ', 'alamat ', 'wifi ', 'wi-fi ']) &&
        !_containsAny(text, ['ingat', 'ingetin'])) {
      final title = _memoryTitle(text);
      final value = _memoryValue(original, title);
      if (value.isNotEmpty) {
        final type = text.contains('suka ') || text.contains('favorit') ||
                text.contains('lebih suka') ? BilangMemoryType.preference : BilangMemoryType.fact;
        return BilangResult(
          intent: BilangIntent.createMemory,
          confidence: BilangConfidence.high,
          title: title,
          content: value,
          memoryType: type,
          confirmation: 'Simpan sebagai ingatan?',
        );
      }
    }

    if (text.contains('ingat') && !_containsAny(text, ['ingetin', 'ingatkan'])) {
      final value = original.replaceFirst(RegExp(r'^.*?\bingat\b\s*', caseSensitive: false), '').trim();
      if (value.isNotEmpty) {
        return BilangResult(
          intent: BilangIntent.createMemory,
          confidence: BilangConfidence.medium,
          title: _memoryTitle(text),
          content: value,
          memoryType: BilangMemoryType.note,
          confirmation: 'Simpan sebagai ingatan?',
        );
      }
    }

    if ((text.contains('lupakan') || text.contains('hapus')) &&
        !_containsAny(text, ['titipan', 'reminder', 'ingatkan', 'ingetin'])) {
      final query = text.replaceFirst(RegExp(r'^(lupakan|hapus)\s*'), '').trim();
      if (query.isNotEmpty) {
        return BilangResult(
          intent: BilangIntent.deleteMemory,
          confidence: BilangConfidence.high,
          targetQuery: query,
          clarification: 'Lupakan ingatan tentang "$query"?',
        );
      }
    }

    return null;
  }

  BilangResult? _updateResult(String original, String text, DateTime now) {
    if (_containsAny(text, ['jamnya jadi', 'waktunya jadi', 'jadi jam', 'ubah jam'])) {
      final time = TimeParser.parse(text);
      if (time == null) {
        return const BilangResult(
          intent: BilangIntent.rescheduleReminder,
          confidence: BilangConfidence.medium,
          clarification: 'Jam berapa jadinya?',
        );
      }
      return BilangResult(
        intent: BilangIntent.rescheduleReminder,
        confidence: BilangConfidence.high,
        time: time,
        targetQuery: 'titipan terakhir yang relevan',
        confirmation: 'Ubah waktu titipan menjadi $time?',
      );
    }

    if (_containsAny(text, ['jangan jadi', 'nggak jadi', 'tidak jadi']) &&
        _containsAny(text, ['tadi', 'yang ', 'titipan', 'charger'])) {
      final query = _extractTarget(text);
      return BilangResult(
        intent: BilangIntent.deleteReminder,
        confidence: BilangConfidence.high,
        targetQuery: query,
        confirmation: 'Lupakan titipan "$query"?',
      );
    }

    if (_containsAny(text, ['sudah', 'udah']) && _containsAny(text, ['selesai', 'beres', 'kelar'])) {
      return BilangResult(
        intent: BilangIntent.completeReminder,
        confidence: BilangConfidence.high,
        targetQuery: _extractTarget(text),
      );
    }

    if (_containsAny(text, ['lupakan', 'hapus']) &&
        _containsAny(text, ['titipan', 'ingetin', 'ingatkan'])) {
      return BilangResult(
        intent: BilangIntent.deleteReminder,
        confidence: BilangConfidence.high,
        targetQuery: _extractTarget(text),
      );
    }

    return null;
  }

  BilangResult? _reminderResult(String original, String text, DateTime now) {
    final asksReminder = _containsAny(text, ['ingetin', 'ingatkan', 'jangan lupa']);
    if (!asksReminder) return null;

    final recurrence = RecurrenceParser.parse(text);
    final time = TimeParser.parse(text);
    final dateKeyword = DateParser.parseKeyword(text);

    final content = _extractReminderContent(original, text);
    if (content.isEmpty) {
      return const BilangResult(
        intent: BilangIntent.createReminder,
        confidence: BilangConfidence.medium,
        clarification: 'Mau aku ingatkan apa?',
      );
    }

    if (time == null) {
      return BilangResult(
        intent: BilangIntent.createReminder,
        confidence: BilangConfidence.medium,
        content: content,
        recurrence: recurrence,
        clarification: _timeClarification(dateKeyword),
      );
    }

    final date = _resolveDate(dateKeyword, now);
    return BilangResult(
      intent: BilangIntent.createReminder,
      confidence: BilangConfidence.high,
      content: content,
      title: _shortTitle(content),
      date: date,
      time: time,
      recurrence: recurrence,
      confirmation: _confirmation(content, date, time, recurrence),
    );
  }

  DateTime? _resolveDate(String? keyword, DateTime now) {
    if (keyword == null || keyword == 'today') {
      return DateTime(now.year, now.month, now.day);
    }
    if (keyword == 'tomorrow') return DateTime(now.year, now.month, now.day + 1);
    if (keyword == 'day_after_tomorrow') return DateTime(now.year, now.month, now.day + 2);
    if (keyword == 'next_week') return DateTime(now.year, now.month, now.day + 7);
    if (keyword == 'next_month') return DateTime(now.year, now.month + 1, now.day);
    return null;
  }

  String _timeClarification(String? dateKeyword) {
    if (dateKeyword == 'tomorrow') return 'Jam berapa besok aku ingatkan?';
    if (dateKeyword == 'today') return 'Jam berapa hari ini aku ingatkan?';
    return 'Kapan aku ingatkan?';
  }

  String _extractReminderContent(String original, String text) {
    var content = original;
    content = content.replaceFirst(RegExp(r'\b(?:besok|lusa|hari ini|minggu depan|bulan depan)\b', caseSensitive: false), '');
    content = content.replaceFirst(RegExp(r'\bjam\s+\d{1,2}(?::|\.)\d{2}\b', caseSensitive: false), '');
    content = content.replaceFirst(RegExp(r'\bjam\s+\d{1,2}\b(?:\s+(?:pagi|siang|sore|malam))?', caseSensitive: false), '');
    content = content.replaceFirst(RegExp(r'\bsetengah\s+\d{1,2}\b', caseSensitive: false), '');
    content = content.replaceFirst(RegExp(r'\bsetiap\s+(?:hari|minggu|bulan)\b', caseSensitive: false), '');
    content = content.replaceFirst(RegExp(r'\b(?:tiap|daily|weekly|monthly)\s+(?:hari|minggu|bulan)?\b', caseSensitive: false), '');
    content = content.replaceFirst(RegExp(r'\b(?:tolong\s+)?(?:ingetin|ingatkan)\b', caseSensitive: false), '');
    content = content.replaceFirst(RegExp(r'\b(?:gue|gw|gua|saya|aku|kamu|lu|lo)\b', caseSensitive: false), '');
    content = content.replaceFirst(RegExp(r'\bjangan lupa\b', caseSensitive: false), '');
    return content.replaceAll(RegExp(r'\s+'), ' ').replaceAll(RegExp(r'^[,\s]+|[,\s]+$'), '').trim();
  }

  String _memoryTitle(String text) {
    if (text.contains('nomor loker') || text.contains('loker')) return 'Nomor loker';
    if (text.contains('ukuran sepatu')) return 'Ukuran sepatu';
    if (text.contains('wifi') || text.contains('wi-fi')) return 'Wi-Fi';
    if (text.contains('alamat')) return 'Alamat';
    return 'Ingatan baru';
  }

  String _memoryValue(String original, String title) {
    final lower = original.toLowerCase();
    final marker = lower.indexOf(title.toLowerCase());
    if (marker < 0) {
      final colon = original.indexOf(':');
      return colon >= 0 ? original.substring(colon + 1).trim() : '';
    }
    var value = original.substring(marker + title.length).trim();
    value = value.replaceFirst(RegExp(r'^(gue|saya|aku)\s*(adalah|:)?\s*', caseSensitive: false), '');
    value = value.replaceFirst(RegExp(r'^(sekarang|adalah|:)\s*', caseSensitive: false), '');
    return value.trim();
  }

  String _extractTarget(String text) {
    var value = text.replaceFirst(RegExp(r'\b(jangan jadi|nggak jadi|tidak jadi|sudah|udah|selesai|beres|kelar|lupakan|hapus)\b'), '').trim();
    value = value.replaceFirst(RegExp(r'^(yang|titipan)\s+'), '');
    return value.isEmpty ? 'titipan terakhir yang relevan' : value;
  }

  String _shortTitle(String content) {
    final words = content.split(' ');
    return words.length <= 6 ? content : '${words.take(6).join(' ')}…';
  }

  String _confirmation(String content, DateTime? date, String time, BilangRecurrence recurrence) {
    final when = date == null ? time : '${date.day}/${date.month} jam $time';
    final repeat = recurrence == BilangRecurrence.none ? '' : ' (${recurrence.name})';
    return 'Titipkan "$content" untuk $when$repeat?';
  }

  bool _containsAny(String text, List<String> values) => values.any(text.contains);
}
