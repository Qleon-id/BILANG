import 'package:flutter/material.dart';

class BilangCharacterDefinition {
  const BilangCharacterDefinition({
    required this.id,
    required this.name,
    required this.personality,
    required this.emojiFallback,
  });

  final String id;
  final String name;
  final String personality;
  final String emojiFallback;
}

const bilangCharacters = <BilangCharacterDefinition>[
  BilangCharacterDefinition(id: 'bear', name: 'Bear', personality: 'Tenang & hangat', emojiFallback: 'B'),
  BilangCharacterDefinition(id: 'cat', name: 'Cat', personality: 'Santai & playful', emojiFallback: 'C'),
  BilangCharacterDefinition(id: 'rabbit', name: 'Rabbit', personality: 'Ceria & energik', emojiFallback: 'R'),
  BilangCharacterDefinition(id: 'dog', name: 'Dog', personality: 'Setia & suportif', emojiFallback: 'D'),
  BilangCharacterDefinition(id: 'fox', name: 'Fox', personality: 'Cerdas & observan', emojiFallback: 'F'),
  BilangCharacterDefinition(id: 'panda', name: 'Panda', personality: 'Chill & lembut', emojiFallback: 'P'),
  BilangCharacterDefinition(id: 'koala', name: 'Koala', personality: 'Lembut & menenangkan', emojiFallback: 'K'),
  BilangCharacterDefinition(id: 'penguin', name: 'Penguin', personality: 'Rapi & bisa diandalkan', emojiFallback: 'P'),
];

BilangCharacterDefinition characterById(String id) {
  return bilangCharacters.firstWhere(
    (item) => item.id == id,
    orElse: () => bilangCharacters.first,
  );
}

class BilangCharacterAvatar extends StatelessWidget {
  const BilangCharacterAvatar({
    super.key,
    required this.character,
    this.size = 92,
    this.selected = false,
  });

  final BilangCharacterDefinition character;
  final double size;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.primary;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 280),
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: selected ? accent.withValues(alpha: .16) : const Color(0xFFF2EFE6),
        shape: BoxShape.circle,
        border: Border.all(
          color: selected ? accent : Colors.transparent,
          width: selected ? 3 : 0,
        ),
      ),
      child: CustomPaint(
        painter: _AnimalPainter(character.id, accent),
        child: Center(
          child: Text(
            character.emojiFallback,
            style: TextStyle(
              fontSize: size * .28,
              fontWeight: FontWeight.w800,
              color: const Color(0xFF171717),
            ),
          ),
        ),
      ),
    );
  }
}

class _AnimalPainter extends CustomPainter {
  const _AnimalPainter(this.id, this.accent);
  final String id;
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = accent.withValues(alpha: .22);
    final center = Offset(size.width / 2, size.height / 2);
    final r = size.width * .27;
    canvas.drawCircle(center.translate(0, r * .35), r, p);

    final earR = r * .48;
    final earY = center.dy - r * .55;
    if (id == 'rabbit' || id == 'koala') {
      canvas.drawOval(
        Rect.fromCenter(center: Offset(center.dx - r * .48, earY - r * .25), width: earR, height: earR * 1.55),
        p,
      );
      canvas.drawOval(
        Rect.fromCenter(center: Offset(center.dx + r * .48, earY - r * .25), width: earR, height: earR * 1.55),
        p,
      );
    } else {
      canvas.drawCircle(Offset(center.dx - r * .58, earY), earR, p);
      canvas.drawCircle(Offset(center.dx + r * .58, earY), earR, p);
    }

    final eye = Paint()..color = const Color(0xFF171717);
    canvas.drawCircle(Offset(center.dx - r * .32, center.dy + r * .12), r * .075, eye);
    canvas.drawCircle(Offset(center.dx + r * .32, center.dy + r * .12), r * .075, eye);
  }

  @override
  bool shouldRepaint(covariant _AnimalPainter oldDelegate) =>
      oldDelegate.id != id || oldDelegate.accent != accent;
}
