import 'package:flutter/material.dart';

import '../../core/services/local_settings_service.dart';
import '../../core/theme/bilang_theme.dart';
import '../../data/models/memory.dart';
import '../../data/models/reminder.dart';
import '../../data/repositories/memory_repository.dart';
import '../../data/repositories/reminder_repository.dart';
import '../characters/character.dart';

class BilangAppShell extends StatefulWidget {
  const BilangAppShell({super.key, required this.selectedCharacterId, required this.selectedThemeId, required this.onThemeChanged});

  final String selectedCharacterId;
  final String selectedThemeId;
  final ValueChanged<String> onThemeChanged;

  @override
  State<BilangAppShell> createState() => _BilangAppShellState();
}

class _BilangAppShellState extends State<BilangAppShell> {
  int index = 0;
  late String selectedCharacterId;
  late String selectedThemeId;

  @override
  void initState() {
    super.initState();
    selectedCharacterId = widget.selectedCharacterId;
    selectedThemeId = widget.selectedThemeId;
  }

  Future<void> _changeCharacter() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            const Text('Pilih temanmu', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text('Teman ini akan menemani kamu mengingat.'),
            const SizedBox(height: 18),
            ...bilangCharacters.map(
              (character) => ListTile(
                leading: BilangCharacterAvatar(character: character, size: 52, selected: character.id == selectedCharacterId),
                title: Text(character.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(character.personality),
                trailing: character.id == selectedCharacterId ? const Icon(Icons.check_circle_rounded) : null,
                onTap: () => Navigator.pop(context, character.id),
              ),
            ),
          ],
        ),
      ),
    );
    if (choice == null || choice == selectedCharacterId) return;
    await LocalSettingsService().setSelectedCharacter(choice);
    if (mounted) setState(() => selectedCharacterId = choice);
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _HomePage(selectedCharacterId: selectedCharacterId, onOpenTitipan: () => setState(() => index = 1)),
      const _TitipanPage(),
      const _IngatanPage(),
      _AkuPage(selectedCharacterId: selectedCharacterId, onChangeCharacter: _changeCharacter, selectedThemeId: selectedThemeId, onThemeChanged: (id) { setState(() => selectedThemeId = id); widget.onThemeChanged(id); }),
    ];

    return Scaffold(
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.inbox_outlined), selectedIcon: Icon(Icons.inbox), label: 'Titipan'),
          NavigationDestination(icon: Icon(Icons.psychology_outlined), selectedIcon: Icon(Icons.psychology), label: 'Ingatan'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Aku'),
        ],
      ),
    );
  }
}

class _HomePage extends StatelessWidget {
  const _HomePage({required this.selectedCharacterId, required this.onOpenTitipan});
  final String selectedCharacterId;
  final VoidCallback onOpenTitipan;

  @override
  Widget build(BuildContext context) {
    final character = characterById(selectedCharacterId);
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 28),
        children: [
          const Text('BILANG', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 30),
          Center(child: BilangCharacterAvatar(character: character, size: 108)),
          const SizedBox(height: 24),
          Text('Selamat pagi 👋', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('Ada yang mau kamu titipkan?', textAlign: TextAlign.center),
          const SizedBox(height: 26),
          Container(
            width: 128,
            height: 128,
            margin: const EdgeInsets.symmetric(horizontal: 72),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary,
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: Theme.of(context).colorScheme.primary.withValues(alpha: .28), blurRadius: 24, offset: const Offset(0, 10))],
            ),
            child: const Icon(Icons.mic_none_rounded, size: 54, color: Colors.white),
          ),
          const SizedBox(height: 16),
          const Text('Tekan dan bilang aja', textAlign: TextAlign.center),
          const SizedBox(height: 6),
          const Text('atau ketik aja...', textAlign: TextAlign.center),
          const SizedBox(height: 24),
          TextField(
            readOnly: true,
            onTap: () => _showManualNote(context),
            decoration: InputDecoration(
              hintText: 'Besok jam 7 ingetin gue...',
              suffixIcon: const Icon(Icons.arrow_forward_rounded),
              filled: true,
              fillColor: Theme.of(context).colorScheme.surface,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 26),
          Row(children: [Text('Titipan hari ini', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)), const Spacer(), TextButton(onPressed: onOpenTitipan, child: const Text('Lihat semua'))]),
          const SizedBox(height: 6),
          FutureBuilder<List<Reminder>>(
            future: ReminderRepository().getReminders(),
            builder: (context, snapshot) {
              final reminders = snapshot.data ?? const <Reminder>[];
              final today = DateTime.now();
              final todayItems = reminders.where((item) => item.status == ReminderStatus.active && item.scheduledAt.year == today.year && item.scheduledAt.month == today.month && item.scheduledAt.day == today.day).take(3).toList();
              if (todayItems.isEmpty) return const _EmptyCard(title: 'Belum ada titipan', subtitle: 'Kepalamu boleh istirahat dulu. 😌');
              return Column(children: todayItems.map((item) => _ReminderTile(reminder: item)).toList());
            },
          ),
        ],
      ),
    );
  }

  Future<void> _showManualNote(BuildContext context) async {
    final title = TextEditingController();
    final date = DateTime.now();
    final selected = await showDialog<DateTime>(
      context: context,
      builder: (context) => _AddReminderDialog(titleController: title, initialDate: date.add(const Duration(hours: 1))),
    );
    if (selected == null || title.text.trim().isEmpty) return;
    await ReminderRepository().save(Reminder(id: DateTime.now().microsecondsSinceEpoch.toString(), title: title.text.trim(), scheduledAt: selected));
  }
}

class _TitipanPage extends StatefulWidget {
  const _TitipanPage();
  @override
  State<_TitipanPage> createState() => _TitipanPageState();
}

class _TitipanPageState extends State<_TitipanPage> {
  final repository = ReminderRepository();
  Future<List<Reminder>>? future;

  @override
  void initState() { super.initState(); _refresh(); }
  void _refresh() => future = repository.getReminders();

  Future<void> _complete(Reminder reminder) async {
    await repository.save(reminder.copyWith(status: ReminderStatus.completed));
    setState(_refresh);
  }

  Future<void> _delete(Reminder reminder) async {
    await repository.delete(reminder.id);
    setState(_refresh);
  }

  Future<void> _add() async {
    final controller = TextEditingController();
    final selected = await showDialog<DateTime>(context: context, builder: (_) => _AddReminderDialog(titleController: controller, initialDate: DateTime.now().add(const Duration(hours: 1))));
    if (selected == null || controller.text.trim().isEmpty) return;
    await repository.save(Reminder(id: DateTime.now().microsecondsSinceEpoch.toString(), title: controller.text.trim(), scheduledAt: selected));
    setState(_refresh);
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(padding: EdgeInsets.fromLTRB(24, 24, 24, 4), child: Text('Titipan', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 24), child: Text('Yang sedang aku ingat untukmu.')),
            const SizedBox(height: 12),
            Expanded(
              child: FutureBuilder<List<Reminder>>(
                future: future,
                builder: (context, snapshot) {
                  if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                  final items = snapshot.data!;
                  if (items.isEmpty) return const Center(child: _EmptyCard(title: 'Belum ada titipan.', subtitle: 'Tenang, kepalamu boleh istirahat dulu. 😌'));
                  return ListView.builder(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 90),
                    itemCount: items.length,
                    itemBuilder: (_, i) {
                      final item = items[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: ListTile(
                          leading: Icon(item.status == ReminderStatus.completed ? Icons.check_circle : Icons.circle, color: Theme.of(context).colorScheme.primary),
                          title: Text(item.title, style: TextStyle(fontWeight: FontWeight.w700, decoration: item.status == ReminderStatus.completed ? TextDecoration.lineThrough : null)),
                          subtitle: Text(_formatDateTime(item.scheduledAt)),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) => value == 'done' ? _complete(item) : _delete(item),
                            itemBuilder: (_) => [
                              if (item.status != ReminderStatus.completed) const PopupMenuItem(value: 'done', child: Text('Selesai')),
                              const PopupMenuItem(value: 'delete', child: Text('Lupakan')),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ).withFloatingActionButton(FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Titipkan'));
}

class _IngatanPage extends StatefulWidget {
  const _IngatanPage();
  @override
  State<_IngatanPage> createState() => _IngatanPageState();
}

class _IngatanPageState extends State<_IngatanPage> {
  final repository = MemoryRepository();
  Future<List<Memory>>? future;
  @override
  void initState() { super.initState(); future = repository.getMemories(); }

  Future<void> _add() async {
    final title = TextEditingController();
    final content = TextEditingController();
    final saved = await showDialog<bool>(context: context, builder: (_) => _AddMemoryDialog(title: title, content: content));
    if (saved != true || title.text.trim().isEmpty || content.text.trim().isEmpty) return;
    await repository.save(Memory(id: DateTime.now().microsecondsSinceEpoch.toString(), title: title.text.trim(), content: content.text.trim(), type: MemoryType.fact, category: MemoryCategory.personal));
    setState(() => future = repository.getMemories());
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(padding: EdgeInsets.fromLTRB(24, 24, 24, 4), child: Text('Ingatan', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))),
            const Padding(padding: EdgeInsets.symmetric(horizontal: 24), child: Text('Hal-hal yang pernah kamu titipkan kepadaku.')),
            Padding(padding: const EdgeInsets.all(20), child: TextField(decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Cari ingatan...', filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none)))),
            Expanded(
              child: FutureBuilder<List<Memory>>(
                future: future,
                builder: (_, snapshot) {
                  if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                  final items = snapshot.data!;
                  if (items.isEmpty) return const Center(child: _EmptyCard(title: 'Belum ada ingatan.', subtitle: 'Kalau ada sesuatu yang ingin kamu simpan, bilang aja.'));
                  return ListView.builder(
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 90),
                    itemCount: items.length,
                    itemBuilder: (_, i) => Card(child: ListTile(leading: const Icon(Icons.lock_outline_rounded), title: Text(items[i].title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(items[i].content), trailing: IconButton(onPressed: () async { await repository.delete(items[i].id); setState(() => future = repository.getMemories()); }, icon: const Icon(Icons.more_horiz)))));
                },
              ),
            ),
          ],
        ),
      ).withFloatingActionButton(FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Simpan'));
}

class _AkuPage extends StatefulWidget {
  const _AkuPage({required this.selectedCharacterId, required this.onChangeCharacter, required this.selectedThemeId, required this.onThemeChanged});
  final String selectedCharacterId;
  final VoidCallback onChangeCharacter;
  final String selectedThemeId;
  final ValueChanged<String> onThemeChanged;

  @override
  State<_AkuPage> createState() => _AkuPageState();
}

class _AkuPageState extends State<_AkuPage> {
  final settings = LocalSettingsService();
  bool notificationsEnabled = true;
  bool notificationPreview = true;
  bool soundEnabled = true;
  bool vibrationEnabled = true;
  bool quietHoursEnabled = true;
  bool importantReminderDuringQuietHours = false;
  bool contextualMemoryEnabled = true;
  String quietStart = '22:00';
  String quietEnd = '06:00';
  String language = 'id';
  String responseStyle = 'casual';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    notificationsEnabled = await settings.getNotificationsEnabled();
    notificationPreview = await settings.getNotificationPreview();
    soundEnabled = await settings.getSoundEnabled();
    vibrationEnabled = await settings.getVibrationEnabled();
    quietHoursEnabled = await settings.getQuietHoursEnabled();
    importantReminderDuringQuietHours = await settings.getImportantReminderDuringQuietHours();
    contextualMemoryEnabled = await settings.getContextualMemoryEnabled();
    quietStart = await settings.getQuietStart();
    quietEnd = await settings.getQuietEnd();
    language = await settings.getLanguage();
    responseStyle = await settings.getResponseStyle();
    if (mounted) setState(() {});
  }

  Future<void> _showReminderSettings() async {
    var notifications = notificationsEnabled;
    var preview = notificationPreview;
    final result = await showModalBottomSheet<Map<String, bool>>(
      context: context,
      showDragHandle: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              const Text('Pengingat', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('Atur kapan BILANG boleh muncul di notifikasi.'),
              const SizedBox(height: 12),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Pengingat aktif'),
                subtitle: const Text('BILANG dapat menampilkan notifikasi titipan.'),
                value: notifications,
                onChanged: (value) => setSheetState(() => notifications = value),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Tampilkan isi titipan'),
                subtitle: const Text('Isi titipan ditampilkan pada preview notifikasi.'),
                value: preview,
                onChanged: (value) => setSheetState(() => preview = value),
              ),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: () => Navigator.pop(context, {'notifications': notifications, 'preview': preview}),
                child: const Text('Simpan'),
              ),
            ],
          ),
        ),
      ),
    );
    if (result == null) return;
    notificationsEnabled = result['notifications'] ?? notificationsEnabled;
    notificationPreview = result['preview'] ?? notificationPreview;
    await settings.setNotificationsEnabled(notificationsEnabled);
    await settings.setNotificationPreview(notificationPreview);
    if (mounted) setState(() {});
  }

  Future<void> _showSoundSettings() async {
    var sound = soundEnabled;
    var vibration = vibrationEnabled;
    final result = await showModalBottomSheet<Map<String, bool>>(
      context: context,
      showDragHandle: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              const Text('Suara & getar', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Suara'), value: sound, onChanged: (value) => setSheetState(() => sound = value)),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Getaran'), value: vibration, onChanged: (value) => setSheetState(() => vibration = value)),
              const SizedBox(height: 8),
              FilledButton(onPressed: () => Navigator.pop(context, {'sound': sound, 'vibration': vibration}), child: const Text('Simpan')),
            ],
          ),
        ),
      ),
    );
    if (result == null) return;
    soundEnabled = result['sound'] ?? soundEnabled;
    vibrationEnabled = result['vibration'] ?? vibrationEnabled;
    await settings.setSoundEnabled(soundEnabled);
    await settings.setVibrationEnabled(vibrationEnabled);
    if (mounted) setState(() {});
  }

  Future<void> _showQuietHours() async {
    var enabled = quietHoursEnabled;
    var important = importantReminderDuringQuietHours;
    var start = quietStart;
    var end = quietEnd;
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
            children: [
              const Text('Waktu tenang', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              const Text('Kurangi gangguan pada jam istirahatmu.'),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Aktif'), value: enabled, onChanged: (value) => setSheetState(() => enabled = value)),
              ListTile(contentPadding: EdgeInsets.zero, title: const Text('Mulai'), trailing: Text(start), onTap: () async {
                final parsed = _parseClock(start);
                final picked = await showTimePicker(context: context, initialTime: parsed);
                if (picked != null) setSheetState(() => start = _clockText(picked));
              }),
              ListTile(contentPadding: EdgeInsets.zero, title: const Text('Selesai'), trailing: Text(end), onTap: () async {
                final parsed = _parseClock(end);
                final picked = await showTimePicker(context: context, initialTime: parsed);
                if (picked != null) setSheetState(() => end = _clockText(picked));
              }),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Pengingat penting saat waktu tenang'), value: important, onChanged: (value) => setSheetState(() => important = value)),
              const SizedBox(height: 8),
              FilledButton(onPressed: () => Navigator.pop(context, {'enabled': enabled, 'important': important, 'start': start, 'end': end}), child: const Text('Simpan')),
            ],
          ),
        ),
      ),
    );
    if (result == null) return;
    quietHoursEnabled = result['enabled'] as bool;
    importantReminderDuringQuietHours = result['important'] as bool;
    quietStart = result['start'] as String;
    quietEnd = result['end'] as String;
    await settings.setQuietHoursEnabled(quietHoursEnabled);
    await settings.setImportantReminderDuringQuietHours(importantReminderDuringQuietHours);
    await settings.setQuietStart(quietStart);
    await settings.setQuietEnd(quietEnd);
    if (mounted) setState(() {});
  }

  Future<void> _showMemorySettings() async {
    var enabled = contextualMemoryEnabled;
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Ingatan'),
        content: StatefulBuilder(builder: (context, setState) => SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Ingatan kontekstual'),
          subtitle: const Text('BILANG boleh menggunakan ingatan yang relevan saat memahami percakapan.'),
          value: enabled,
          onChanged: (value) => setState(() => enabled = value),
        )),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, enabled), child: const Text('Simpan'))],
      ),
    );
    if (result == null) return;
    contextualMemoryEnabled = result;
    await settings.setContextualMemoryEnabled(result);
    if (mounted) setState(() {});
  }

  Future<void> _showLanguageSettings() async {
    final result = await showDialog<String>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Bahasa'),
        children: [
          SimpleDialogOption(onPressed: () => Navigator.pop(context, 'id'), child: const Text('Bahasa Indonesia')),
          SimpleDialogOption(onPressed: () => Navigator.pop(context, 'en'), child: const Text('English')),
        ],
      ),
    );
    if (result == null) return;
    language = result;
    await settings.setLanguage(result);
    if (mounted) setState(() {});
  }

  Future<void> _showResponseStyle() async {
    final result = await showDialog<String>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Cara bicara BILANG'),
        children: [
          SimpleDialogOption(onPressed: () => Navigator.pop(context, 'casual'), child: const Text('Santai')),
          SimpleDialogOption(onPressed: () => Navigator.pop(context, 'neutral'), child: const Text('Netral')),
          SimpleDialogOption(onPressed: () => Navigator.pop(context, 'short'), child: const Text('Singkat')),
        ],
      ),
    );
    if (result == null) return;
    responseStyle = result;
    await settings.setResponseStyle(result);
    if (mounted) setState(() {});
  }

  Future<void> _showPrivacy() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Privasi', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('Data titipan dan ingatan pada BUILD ini disimpan secara lokal di perangkat.'),
            const SizedBox(height: 18),
            OutlinedButton.icon(onPressed: () async {
              final confirm = await showDialog<bool>(context: context, builder: (context) => AlertDialog(title: const Text('Hapus semua data?'), content: const Text('Semua titipan dan ingatan yang tersimpan akan dihapus dari perangkat.'), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Hapus'))]));
              if (confirm != true) return;
              await ReminderRepository().clearAll();
              await MemoryRepository().clearAll();
              if (context.mounted) Navigator.pop(context);
              if (mounted) setState(() {});
            }, icon: const Icon(Icons.delete_outline_rounded), label: const Text('Hapus semua titipan & ingatan')),
          ]),
        ),
      ),
    );
  }

  void _showAbout() {
    showAboutDialog(
      context: context,
      applicationName: 'BILANG',
      applicationVersion: '1.0.0+5',
      applicationLegalese: 'Kamu bilang. BILANG yang ingat.',
      children: const [SizedBox(height: 12), Text('BILANG adalah teman pengingat personal yang membantu menyimpan titipan dan ingatan dengan cara yang sederhana.')],
    );
  }

  @override
  Widget build(BuildContext context) {
    final character = characterById(widget.selectedCharacterId);
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(24, 24, 24, 30),
        children: [
          const Text('Aku', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 22),
          Center(child: BilangCharacterAvatar(character: character, size: 112, selected: true)),
          const SizedBox(height: 12),
          Center(child: Text(character.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
          const SizedBox(height: 4),
          const Center(child: Text('Teman yang menemani kamu mengingat.')),
          const SizedBox(height: 14),
          Center(child: OutlinedButton(onPressed: widget.onChangeCharacter, child: const Text('Ganti teman'))),
          const SizedBox(height: 24),
          _SettingTile(icon: Icons.palette_outlined, title: 'Tema', subtitle: 'Saat ini: ${bilangThemeById(widget.selectedThemeId).name}', onTap: () => _showThemePicker(context)),
          _SettingTile(icon: Icons.notifications_none_rounded, title: 'Pengingat', subtitle: notificationsEnabled ? 'Aktif' : 'Nonaktif', onTap: _showReminderSettings),
          _SettingTile(icon: Icons.volume_up_outlined, title: 'Suara & getar', subtitle: '${soundEnabled ? 'Suara' : 'Tanpa suara'} • ${vibrationEnabled ? 'Getar' : 'Tanpa getar'}', onTap: _showSoundSettings),
          _SettingTile(icon: Icons.nightlight_outlined, title: 'Waktu tenang', subtitle: quietHoursEnabled ? '$quietStart–$quietEnd' : 'Nonaktif', onTap: _showQuietHours),
          _SettingTile(icon: Icons.psychology_outlined, title: 'Ingatan', subtitle: contextualMemoryEnabled ? 'Konteks aktif' : 'Konteks nonaktif', onTap: _showMemorySettings),
          _SettingTile(icon: Icons.record_voice_over_outlined, title: 'Bahasa & cara bicara', subtitle: '${language == 'id' ? 'Bahasa Indonesia' : 'English'} • ${_responseStyleLabel(responseStyle)}', onTap: () async { await _showLanguageSettings(); await _showResponseStyle(); }),
          _SettingTile(icon: Icons.lock_outline_rounded, title: 'Privasi', subtitle: 'Kelola data yang tersimpan di perangkat.', onTap: _showPrivacy),
          _SettingTile(icon: Icons.info_outline_rounded, title: 'Tentang BILANG', subtitle: 'Kamu bilang. BILANG yang ingat.', onTap: _showAbout),
        ],
      ),
    );
  }

  Future<void> _showThemePicker(BuildContext context) async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: GridView.builder(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          shrinkWrap: true,
          itemCount: bilangThemes.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: .9),
          itemBuilder: (_, i) {
            final theme = bilangThemes[i];
            final selected = theme.id == widget.selectedThemeId;
            return InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => Navigator.pop(context, theme.id),
              child: Column(children: [
                Expanded(child: Container(decoration: BoxDecoration(color: theme.primary, borderRadius: BorderRadius.circular(18), border: Border.all(color: selected ? Colors.black : Colors.transparent, width: 3)), child: selected ? const Center(child: Icon(Icons.check, color: Colors.white, size: 30)) : null)),
                const SizedBox(height: 6),
                Text(theme.name, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              ]),
            );
          },
        ),
      ),
    );
    if (choice == null || choice == widget.selectedThemeId) return;
    await settings.setSelectedTheme(choice);
    widget.onThemeChanged(choice);
    if (mounted) setState(() {});
  }
}

class _SettingTile extends StatelessWidget {
  const _SettingTile({required this.icon, required this.title, required this.subtitle, this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => ListTile(contentPadding: EdgeInsets.zero, leading: Icon(icon), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right), onTap: onTap);
}

String _responseStyleLabel(String value) => switch (value) {
  'neutral' => 'Netral',
  'short' => 'Singkat',
  _ => 'Santai',
};

TimeOfDay _parseClock(String value) {
  final parts = value.split(':');
  final hour = int.tryParse(parts.first) ?? 22;
  final minute = int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0;
  return TimeOfDay(hour: hour.clamp(0, 23).toInt(), minute: minute.clamp(0, 59).toInt());
}

String _clockText(TimeOfDay value) => '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';

class _ReminderTile extends StatelessWidget {
  const _ReminderTile({required this.reminder});
  final Reminder reminder;
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(Icons.circle, size: 12, color: Theme.of(context).colorScheme.primary), title: Text(reminder.title, style: const TextStyle(fontWeight: FontWeight.w700)), trailing: Text(_formatTime(reminder.scheduledAt))));
}

class _EmptyCard extends StatelessWidget {
  const _EmptyCard({required this.title, required this.subtitle});
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(20), margin: const EdgeInsets.symmetric(horizontal: 4), decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFEAE6DC))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 5), Text(subtitle)]));
}

class _AddReminderDialog extends StatefulWidget {
  const _AddReminderDialog({required this.titleController, required this.initialDate});
  final TextEditingController titleController;
  final DateTime initialDate;
  @override
  State<_AddReminderDialog> createState() => _AddReminderDialogState();
}
class _AddReminderDialogState extends State<_AddReminderDialog> {
  late DateTime selected;
  @override
  void initState() { super.initState(); selected = widget.initialDate; }
  Future<void> _pick() async {
    final date = await showDatePicker(context: context, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)), initialDate: selected);
    if (date == null || !mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(selected));
    if (time == null) return;
    setState(() => selected = DateTime(date.year, date.month, date.day, time.hour, time.minute));
  }
  @override
  Widget build(BuildContext context) => AlertDialog(title: const Text('Titipkan sesuatu'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: widget.titleController, autofocus: true, decoration: const InputDecoration(labelText: 'Apa yang perlu diingat?')), const SizedBox(height: 12), ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.schedule), title: Text(_formatDateTime(selected)), onTap: _pick)]), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, selected), child: const Text('Titipkan'))]);
}

class _AddMemoryDialog extends StatelessWidget {
  const _AddMemoryDialog({required this.title, required this.content});
  final TextEditingController title;
  final TextEditingController content;
  @override
  Widget build(BuildContext context) => AlertDialog(title: const Text('Simpan sebagai ingatan'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: title, decoration: const InputDecoration(labelText: 'Judul')), TextField(controller: content, decoration: const InputDecoration(labelText: 'Isi'), maxLines: 3)]), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Simpan'))]);
}

String _formatTime(DateTime value) => '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';
String _formatDateTime(DateTime value) => '${value.day.toString().padLeft(2, '0')}/${value.month.toString().padLeft(2, '0')}/${value.year} • ${_formatTime(value)}';

extension _ScaffoldExtension on Widget {
  Widget withFloatingActionButton(Widget fab) => Builder(builder: (context) => Scaffold(body: this, floatingActionButton: fab));
}
