import '../nlu/context/bilang_context.dart';
import '../nlu/engine/bilang_engine.dart';
import '../nlu/models/bilang_result.dart';
import '../../core/services/sensitive_content_guard.dart';
import '../../data/models/memory.dart';
import '../../data/models/reminder.dart';
import '../../data/repositories/memory_repository.dart';
import '../../data/repositories/reminder_repository.dart';
import '../notifications/notification_service.dart';

/// Coordinates NLU, local data and notifications without coupling the UI to
/// individual repositories. Creation is intentionally a two-step flow:
/// processInput() -> show confirmation -> executeConfirmed().
class BilangIntegrationService {
  BilangIntegrationService({
    BilangEngine engine = const BilangEngine(),
    ReminderRepository? reminders,
    MemoryRepository? memories,
    NotificationService? notifications,
    DateTime Function()? clock,
  })  : _engine = engine,
        _reminders = reminders ?? ReminderRepository(),
        _memories = memories ?? MemoryRepository(),
        _notifications = notifications ?? NotificationService.instance,
        _clock = clock ?? DateTime.now;

  final BilangEngine _engine;
  final ReminderRepository _reminders;
  final MemoryRepository _memories;
  final NotificationService _notifications;
  final DateTime Function() _clock;

  BilangContext? _context;

  BilangContext? get activeContext {
    final context = _context;
    if (context == null || context.isExpired(_clock())) {
      _context = null;
      return null;
    }
    return context;
  }

  BilangResult processText(String input) {
    final now = _clock();
    final result = _engine.processInput(input, now: now);
    _context = BilangContext(
      result: result,
      createdAt: now,
      expiresAt: now.add(const Duration(minutes: 10)),
    );
    return result;
  }

  void clearContext() => _context = null;

  Future<ExecutionResult> executeConfirmed(BilangResult result) async {
    switch (result.intent) {
      case BilangIntent.createReminder:
        return _createReminder(result);
      case BilangIntent.createMemory:
        return _createMemory(result);
      case BilangIntent.updateMemory:
        return _updateMemory(result);
      case BilangIntent.deleteMemory:
        return _deleteMemory(result);
      case BilangIntent.readMemory:
        return _readMemory(result);
      case BilangIntent.rescheduleReminder:
        return _rescheduleReminder(result);
      case BilangIntent.completeReminder:
        return _completeReminder(result);
      case BilangIntent.deleteReminder:
        return _deleteReminder(result);
      case BilangIntent.updateReminder:
        return const ExecutionResult(false, 'Ubah titipan akan tersedia setelah target titipan dipilih.');
      case BilangIntent.cancel:
        clearContext();
        return const ExecutionResult(true, 'Dibatalkan.');
      case BilangIntent.unknown:
        return const ExecutionResult(false, 'Aku belum yakin harus melakukan apa.');
    }
  }

  Future<ExecutionResult> _createReminder(BilangResult result) async {
    if (result.confidence != BilangConfidence.high || result.content == null || result.time == null) {
      return const ExecutionResult(false, 'Aku masih perlu sedikit penjelasan sebelum membuat titipan.');
    }
    final date = result.date ?? _clock();
    final time = _parseTime(result.time!);
    if (time == null) return const ExecutionResult(false, 'Jamnya belum jelas.');

    final scheduled = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    if (!scheduled.isAfter(_clock())) {
      return const ExecutionResult(false, 'Waktu itu sudah lewat. Pilih waktu yang akan datang.');
    }

    final reminder = Reminder(
      id: _newId(),
      title: result.content!.trim(),
      scheduledAt: scheduled,
      recurrence: _mapRecurrence(result.recurrence),
    );
    await _reminders.save(reminder);
    await _notifications.scheduleReminder(reminder);
    clearContext();
    return ExecutionResult(true, 'Sudah dititipkan!', reminderId: reminder.id);
  }

  Future<ExecutionResult> _createMemory(BilangResult result) async {
    final content = result.content?.trim() ?? '';
    if (content.isEmpty) return const ExecutionResult(false, 'Belum ada isi yang bisa disimpan.');
    if (SensitiveContentGuard.isSensitive(content)) {
      return ExecutionResult(false, SensitiveContentGuard.warning(content));
    }
    final memory = Memory(
      id: _newId(),
      title: result.title?.trim().isNotEmpty == true ? result.title!.trim() : 'Ingatan baru',
      content: content,
      type: _mapMemoryType(result.memoryType),
      category: MemoryCategory.other,
    );
    await _memories.save(memory);
    clearContext();
    return ExecutionResult(true, 'Sudah aku simpan sebagai ingatan.', memoryId: memory.id);
  }

  Future<ExecutionResult> _updateMemory(BilangResult result) async {
    final query = result.targetQuery?.trim();
    if (query == null || query.isEmpty || result.content == null) {
      return const ExecutionResult(false, 'Aku belum tahu ingatan mana yang mau diubah.');
    }
    if (SensitiveContentGuard.isSensitive(result.content!)) {
      return ExecutionResult(false, SensitiveContentGuard.warning(result.content!));
    }
    final memories = await _memories.getMemories();
    final index = _findMemoryIndex(memories, query);
    if (index < 0) return const ExecutionResult(false, 'Aku belum menemukan ingatan yang cocok.');
    final old = memories[index];
    await _memories.save(Memory(id: old.id, title: result.title ?? old.title, content: result.content!, type: old.type, category: old.category));
    clearContext();
    return const ExecutionResult(true, 'Ingatanmu sudah diperbarui.');
  }

  Future<ExecutionResult> _deleteMemory(BilangResult result) async {
    final query = result.targetQuery?.trim();
    if (query == null || query.isEmpty) return const ExecutionResult(false, 'Ingatan mana yang mau dilupakan?');
    final memories = await _memories.getMemories();
    final index = _findMemoryIndex(memories, query);
    if (index < 0) return const ExecutionResult(false, 'Aku belum menemukan ingatan yang cocok.');
    await _memories.delete(memories[index].id);
    clearContext();
    return const ExecutionResult(true, 'Sudah aku lupakan.');
  }

  Future<ExecutionResult> _readMemory(BilangResult result) async {
    final query = result.targetQuery?.trim() ?? result.content?.trim();
    if (query == null || query.isEmpty) return const ExecutionResult(false, 'Ingatan mana yang mau kamu cari?');
    final memories = await _memories.getMemories();
    final index = _findMemoryIndex(memories, query);
    if (index < 0) return const ExecutionResult(false, 'Aku belum punya ingatan tentang itu.');
    final memory = memories[index];
    clearContext();
    return ExecutionResult(true, memory.content, memoryId: memory.id);
  }

  Future<ExecutionResult> _rescheduleReminder(BilangResult result) async {
    final query = result.targetQuery;
    final reminders = await _reminders.getReminders();
    final index = _findReminderIndex(reminders, query);
    if (index < 0) return const ExecutionResult(false, 'Aku belum menemukan titipan yang mau diubah.');
    final old = reminders[index];
    final time = result.time == null ? null : _parseTime(result.time!);
    if (time == null) return const ExecutionResult(false, 'Jam barunya belum jelas.');
    final updatedTime = DateTime(old.scheduledAt.year, old.scheduledAt.month, old.scheduledAt.day, time.hour, time.minute);
    final updated = old.copyWith(scheduledAt: updatedTime, status: ReminderStatus.active);
    await _reminders.save(updated);
    await _notifications.rescheduleReminder(updated);
    clearContext();
    return const ExecutionResult(true, 'Waktu titipannya sudah diubah.');
  }

  Future<ExecutionResult> _completeReminder(BilangResult result) async {
    final reminders = await _reminders.getReminders();
    final index = _findReminderIndex(reminders, result.targetQuery);
    if (index < 0) return const ExecutionResult(false, 'Aku belum menemukan titipan yang dimaksud.');
    await _notifications.completeReminder(reminders[index].id);
    clearContext();
    return const ExecutionResult(true, 'Sudah selesai. 👌');
  }

  Future<ExecutionResult> _deleteReminder(BilangResult result) async {
    final reminders = await _reminders.getReminders();
    final index = _findReminderIndex(reminders, result.targetQuery);
    if (index < 0) return const ExecutionResult(false, 'Aku belum menemukan titipan yang dimaksud.');
    final reminder = reminders[index];
    await _notifications.cancelReminder(reminder.id);
    await _reminders.delete(reminder.id);
    clearContext();
    return const ExecutionResult(true, 'Sudah aku lupakan.');
  }

  int _findReminderIndex(List<Reminder> reminders, String? query) {
    final active = reminders.where((item) => item.status == ReminderStatus.active || item.status == ReminderStatus.snoozed).toList();
    if (active.isEmpty) return -1;
    final normalized = (query ?? '').toLowerCase().trim();
    if (normalized.isEmpty || normalized == 'titipan terakhir yang relevan') return 0;
    final exact = active.indexWhere((item) => item.title.toLowerCase().contains(normalized));
    return exact >= 0 ? exact : 0;
  }

  int _findMemoryIndex(List<Memory> memories, String query) {
    final normalized = query.toLowerCase();
    return memories.indexWhere((memory) => memory.title.toLowerCase().contains(normalized) || memory.content.toLowerCase().contains(normalized));
  }

  DateTime? _parseTime(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour > 23 || minute > 59) return null;
    return DateTime(0, 1, 1, hour, minute);
  }

  ReminderRecurrence _mapRecurrence(BilangRecurrence value) => switch (value) {
        BilangRecurrence.none => ReminderRecurrence.none,
        BilangRecurrence.daily => ReminderRecurrence.daily,
        BilangRecurrence.weekly => ReminderRecurrence.weekly,
        BilangRecurrence.monthly => ReminderRecurrence.monthly,
      };

  MemoryType _mapMemoryType(BilangMemoryType? value) => switch (value) {
        BilangMemoryType.preference => MemoryType.preference,
        BilangMemoryType.context => MemoryType.context,
        BilangMemoryType.fact => MemoryType.fact,
        BilangMemoryType.note || null => MemoryType.note,
      };

  String _newId() => DateTime.now().microsecondsSinceEpoch.toString();
}

class ExecutionResult {
  const ExecutionResult(this.success, this.message, {this.reminderId, this.memoryId});

  final bool success;
  final String message;
  final String? reminderId;
  final String? memoryId;
}
