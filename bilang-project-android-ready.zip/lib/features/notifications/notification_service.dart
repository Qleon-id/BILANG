import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../../core/services/local_settings_service.dart';
import '../../data/models/reminder.dart';
import '../../data/repositories/reminder_repository.dart';

/// BILANG local notification engine.
///
/// This service owns scheduling/cancelling local notifications. It deliberately
/// does not change the reminder's scheduled time because quiet hours are a
/// notification policy, not a reminder-time editor.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  final ReminderRepository _reminders = ReminderRepository();
  final LocalSettingsService _settings = LocalSettingsService();

  bool _initialized = false;

  static const _channelId = 'bilang_reminders';
  static const _channelName = 'BILANG Pengingat';
  static const _channelDescription = 'Pengingat titipan dari BILANG.';

  Future<void> initialize() async {
    if (_initialized) return;

    tz.initializeTimeZones();
    try {
      final timezone = await FlutterTimezone.getLocalTimezone();
      final name = timezone.name;
      if (tz.timeZoneDatabase.locations.containsKey(name)) {
        tz.setLocalLocation(tz.getLocation(name));
      }
    } catch (_) {
      // Keep the package default if the device timezone cannot be resolved.
    }

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings();
    const settings = InitializationSettings(android: android, iOS: ios);

    await _plugin.initialize(
      settings: settings,
      onDidReceiveNotificationResponse: _onNotificationResponse,
      onDidReceiveBackgroundNotificationResponse: notificationBackgroundHandler,
    );

    final androidPlugin = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(
      const AndroidNotificationChannel(
        _channelId,
        _channelName,
        description: _channelDescription,
        importance: Importance.high,
      ),
    );

    _initialized = true;
  }

  Future<bool> requestPermission() async {
    await initialize();
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    final androidGranted = await android?.requestNotificationsPermission();
    final ios = _plugin.resolvePlatformSpecificImplementation<
        IOSFlutterLocalNotificationsPlugin>();
    final iosGranted = await ios?.requestPermissions(
      alert: true,
      badge: true,
      sound: true,
    );
    return androidGranted ?? iosGranted ?? true;
  }

  Future<void> scheduleReminder(Reminder reminder) async {
    await initialize();
    await cancelReminder(reminder.id);

    if (reminder.status != ReminderStatus.active ||
        reminder.scheduledAt.isBefore(DateTime.now())) {
      return;
    }

    final notificationsEnabled = await _settings.getNotificationsEnabled();
    if (!notificationsEnabled) return;

    final quiet = await _settings.getQuietHoursEnabled();
    final important = await _settings.getImportantReminderDuringQuietHours();
    if (quiet && await isInQuietHours(reminder.scheduledAt) && !important) {
      // Keep the reminder intact. It can be reconciled when the user changes
      // quiet-hours settings or opens BILANG again.
      return;
    }

    final preview = await _settings.getNotificationPreview();
    final sound = await _settings.getSoundEnabled();
    final vibration = await _settings.getVibrationEnabled();

    final androidDetails = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDescription,
      importance: Importance.high,
      priority: Priority.high,
      playSound: sound,
      enableVibration: vibration,
      autoCancel: false,
      actions: const <AndroidNotificationAction>[
        AndroidNotificationAction('complete', 'Selesai', showsUserInterface: true),
        AndroidNotificationAction('snooze', 'Nanti aja', showsUserInterface: true),
      ],
    );
    final iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: sound,
    );

    final scheduled = tz.TZDateTime.from(reminder.scheduledAt, tz.local);
    final body = preview ? reminder.title : 'Kamu tadi nitip sesuatu. 👀';
    final components = switch (reminder.recurrence) {
      ReminderRecurrence.none => null,
      ReminderRecurrence.daily => DateTimeComponents.time,
      ReminderRecurrence.weekly => DateTimeComponents.dayOfWeekAndTime,
      ReminderRecurrence.monthly => DateTimeComponents.dayOfMonthAndTime,
    };

    await _plugin.zonedSchedule(
      id: _notificationId(reminder.id),
      title: 'BILANG',
      body: body,
      scheduledDate: scheduled,
      notificationDetails: NotificationDetails(
        android: androidDetails,
        iOS: iosDetails,
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      matchDateTimeComponents: components,
      payload: jsonEncode({'reminderId': reminder.id}),
    );
  }

  Future<void> cancelAllNotifications() async {
    await initialize();
    await _plugin.cancelAll();
  }

  Future<void> cancelReminder(String reminderId) async {
    await initialize();
    await _plugin.cancel(id: _notificationId(reminderId));
  }

  Future<void> rescheduleReminder(Reminder reminder) async {
    await cancelReminder(reminder.id);
    await scheduleReminder(reminder);
  }

  Future<void> rescheduleAll() async {
    await initialize();
    final reminders = await _reminders.getReminders();
    for (final reminder in reminders) {
      if (reminder.status == ReminderStatus.active) {
        await scheduleReminder(reminder);
      } else {
        await cancelReminder(reminder.id);
      }
    }
  }

  Future<void> snoozeReminder(String reminderId, Duration duration) async {
    final reminder = (await _reminders.getReminders())
        .where((item) => item.id == reminderId)
        .firstOrNull;
    if (reminder == null) return;

    await cancelReminder(reminderId);
    final snoozed = reminder.copyWith(
      scheduledAt: DateTime.now().add(duration),
      status: ReminderStatus.snoozed,
    );
    await _reminders.save(snoozed);

    // Snooze is a new one-shot notification. It intentionally does not keep
    // the recurring match rule from the original reminder.
    await _scheduleOneShot(
      snoozed.copyWith(status: ReminderStatus.active),
    );
  }

  Future<void> completeReminder(String reminderId) async {
    await cancelReminder(reminderId);
    final reminder = (await _reminders.getReminders())
        .where((item) => item.id == reminderId)
        .firstOrNull;
    if (reminder == null) return;

    if (reminder.recurrence == ReminderRecurrence.none) {
      await _reminders.save(reminder.copyWith(status: ReminderStatus.completed));
      return;
    }

    // Completing one occurrence keeps the recurring rule alive by moving the
    // reminder to its next occurrence.
    final next = _nextOccurrence(reminder);
    if (next == null) {
      await _reminders.save(reminder.copyWith(status: ReminderStatus.completed));
      return;
    }
    final updated = reminder.copyWith(
      scheduledAt: next,
      status: ReminderStatus.active,
    );
    await _reminders.save(updated);
    await scheduleReminder(updated);
  }

  Future<void> _scheduleOneShot(Reminder reminder) async {
    final preview = await _settings.getNotificationPreview();
    final sound = await _settings.getSoundEnabled();
    final vibration = await _settings.getVibrationEnabled();
    final scheduled = tz.TZDateTime.from(reminder.scheduledAt, tz.local);
    if (scheduled.isBefore(tz.TZDateTime.now(tz.local))) return;

    await _plugin.zonedSchedule(
      id: _notificationId(reminder.id),
      title: 'BILANG',
      body: preview ? reminder.title : 'Kamu tadi nitip sesuatu. 👀',
      scheduledDate: scheduled,
      notificationDetails: NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: _channelDescription,
          importance: Importance.high,
          priority: Priority.high,
          playSound: sound,
          enableVibration: vibration,
          actions: const <AndroidNotificationAction>[
            AndroidNotificationAction('complete', 'Selesai', showsUserInterface: true),
            AndroidNotificationAction('snooze', 'Nanti aja', showsUserInterface: true),
          ],
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentSound: sound,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      payload: jsonEncode({'reminderId': reminder.id}),
    );
  }

  Future<void> _onNotificationResponse(NotificationResponse response) async {
    await _handleAction(response.actionId, response.payload);
  }

  static Future<void> _handleAction(String? actionId, String? payload) async {
    if (payload == null || payload.isEmpty) return;
    try {
      final data = jsonDecode(payload) as Map<String, dynamic>;
      final reminderId = data['reminderId'] as String?;
      if (reminderId == null) return;
      final service = NotificationService.instance;
      if (actionId == 'complete') {
        await service.completeReminder(reminderId);
      } else if (actionId == 'snooze') {
        await service.snoozeReminder(reminderId, const Duration(minutes: 15));
      }
    } catch (error) {
      debugPrint('BILANG notification action failed: $error');
    }
  }

  Future<bool> isInQuietHours(DateTime value) async {
    if (!await _settings.getQuietHoursEnabled()) return false;
    final start = _clockToMinutes(await _settings.getQuietStart());
    final end = _clockToMinutes(await _settings.getQuietEnd());
    final current = value.hour * 60 + value.minute;
    if (start == end) return false;
    return start < end
        ? current >= start && current < end
        : current >= start || current < end;
  }

  int _clockToMinutes(String value) {
    final parts = value.split(':');
    final hour = int.tryParse(parts.first) ?? 0;
    final minute = int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0;
    return hour * 60 + minute;
  }

  DateTime? _nextOccurrence(Reminder reminder) {
    final value = reminder.scheduledAt;
    switch (reminder.recurrence) {
      case ReminderRecurrence.none:
        return null;
      case ReminderRecurrence.daily:
        return value.add(const Duration(days: 1));
      case ReminderRecurrence.weekly:
        return value.add(const Duration(days: 7));
      case ReminderRecurrence.monthly:
        final nextMonth = value.month == 12
            ? DateTime(value.year + 1, 1, 1)
            : DateTime(value.year, value.month + 1, 1);
        final lastDay = DateTime(nextMonth.year, nextMonth.month + 1, 0).day;
        return DateTime(
          nextMonth.year,
          nextMonth.month,
          value.day.clamp(1, lastDay).toInt(),
          value.hour,
          value.minute,
        );
    }
  }

  int _notificationId(String reminderId) {
    var hash = 0;
    for (final unit in reminderId.codeUnits) {
      hash = ((hash * 31) + unit) & 0x7fffffff;
    }
    return hash == 0 ? 1 : hash;
  }
}

@pragma('vm:entry-point')
Future<void> notificationBackgroundHandler(NotificationResponse response) async {
  await NotificationService._handleAction(response.actionId, response.payload);
}
