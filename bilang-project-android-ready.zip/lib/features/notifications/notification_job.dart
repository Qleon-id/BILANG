enum NotificationJobStatus { scheduled, triggered, cancelled, completed }

class NotificationJob {
  const NotificationJob({
    required this.id,
    required this.reminderId,
    required this.scheduledAt,
    this.status = NotificationJobStatus.scheduled,
  });

  final String id;
  final String reminderId;
  final DateTime scheduledAt;
  final NotificationJobStatus status;
}
