import '../models/bilang_result.dart';

/// Short-lived conversational context for follow-up messages.
/// Context expires so BILANG never keeps an ambiguous target forever.
class BilangContext {
  const BilangContext({
    required this.result,
    required this.createdAt,
    required this.expiresAt,
    this.targetId,
  });

  final BilangResult result;
  final DateTime createdAt;
  final DateTime expiresAt;
  final String? targetId;

  bool isExpired(DateTime now) => !now.isBefore(expiresAt);
}
