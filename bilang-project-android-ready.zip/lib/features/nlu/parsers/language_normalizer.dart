class LanguageNormalizer {
  static String normalize(String input) {
    var text = input.toLowerCase().trim();
    const replacements = <String, String>{
      'ingatkan': 'ingetin',
      'ngingetin': 'ingetin',
      'tolong ingetin': 'ingetin',
      'tolong ingatkan': 'ingetin',
      'jangan lupa': 'ingetin',
      'lupain': 'lupakan',
      'hapuskan': 'hapus',
      'hapusin': 'hapus',
      'gue': 'saya',
      'gw': 'saya',
      'gua': 'saya',
      'lu': 'kamu',
      'lo': 'kamu',
      'ntar': 'nanti',
    };
    replacements.forEach((from, to) {
      text = text.replaceAll(RegExp(r'\b' + RegExp.escape(from) + r'\b'), to);
    });
    return text.replaceAll(RegExp(r'\s+'), ' ');
  }
}
