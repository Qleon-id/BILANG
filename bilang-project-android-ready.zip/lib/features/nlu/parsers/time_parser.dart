class TimeParser {
  static String? parse(String text) {
    final clock = RegExp(r'\b(?:jam\s*)?(\d{1,2})(?::|\.)(\d{2})\b').firstMatch(text);
    if (clock != null) {
      final hour = int.tryParse(clock.group(1)!);
      final minute = int.tryParse(clock.group(2)!);
      if (hour != null && minute != null && hour < 24 && minute < 60) {
        return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
      }
    }

    final hourOnly = RegExp(r'\bjam\s+(\d{1,2})\b').firstMatch(text);
    if (hourOnly != null) {
      final hour = int.tryParse(hourOnly.group(1)!);
      if (hour != null && hour < 24) {
        var h = hour;
        if (RegExp(r'\b(malam|pm)\b').hasMatch(text) && h < 12) h += 12;
        if (RegExp(r'\b(pagi|am)\b').hasMatch(text) && h == 12) h = 0;
        return '${h.toString().padLeft(2, '0')}:00';
      }
    }

    if (text.contains('setengah 8')) return '07:30';
    if (text.contains('setengah 9')) return '08:30';
    if (text.contains('setengah 10')) return '09:30';
    if (text.contains('setengah 7')) return '06:30';

    if (text.contains('pagi') || text.contains('siang') || text.contains('sore') || text.contains('malam')) {
      return null;
    }
    return null;
  }
}
