class DateParser {
  static String? parseKeyword(String text) {
    if (text.contains('hari ini')) return 'today';
    if (text.contains('besok')) return 'tomorrow';
    if (text.contains('lusa')) return 'day_after_tomorrow';
    if (text.contains('minggu depan')) return 'next_week';
    if (text.contains('bulan depan')) return 'next_month';
    return null;
  }
}
