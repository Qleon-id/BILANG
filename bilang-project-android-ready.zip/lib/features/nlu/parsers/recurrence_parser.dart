import '../models/bilang_result.dart';

class RecurrenceParser {
  static BilangRecurrence parse(String text) {
    if (text.contains('setiap hari') || text.contains('tiap hari') || text.contains('daily')) {
      return BilangRecurrence.daily;
    }
    if (text.contains('setiap minggu') || text.contains('tiap minggu') || text.contains('weekly')) {
      return BilangRecurrence.weekly;
    }
    if (text.contains('setiap bulan') || text.contains('tiap bulan') || text.contains('monthly')) {
      return BilangRecurrence.monthly;
    }
    return BilangRecurrence.none;
  }
}
