enum BilangIntent {
  createReminder,
  updateReminder,
  completeReminder,
  rescheduleReminder,
  deleteReminder,
  createMemory,
  readMemory,
  updateMemory,
  deleteMemory,
  cancel,
  unknown,
}

enum BilangConfidence { high, medium, low }

enum BilangMemoryType { fact, preference, context, note }

enum BilangRecurrence { none, daily, weekly, monthly }

class BilangResult {
  const BilangResult({
    required this.intent,
    required this.confidence,
    this.content,
    this.title,
    this.date,
    this.time,
    this.recurrence = BilangRecurrence.none,
    this.memoryType,
    this.targetQuery,
    this.clarification,
    this.confirmation,
  });

  final BilangIntent intent;
  final BilangConfidence confidence;
  final String? content;
  final String? title;
  final DateTime? date;
  final String? time;
  final BilangRecurrence recurrence;
  final BilangMemoryType? memoryType;
  final String? targetQuery;
  final String? clarification;
  final String? confirmation;

  bool get needsClarification => clarification != null && clarification!.isNotEmpty;
  bool get isActionable => confidence != BilangConfidence.low && intent != BilangIntent.unknown;
}
