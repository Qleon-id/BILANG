enum SpeechState { idle, listening, processing, error, unavailable }

class SpeechResult {
  const SpeechResult({required this.text, required this.isFinal});
  final String text;
  final bool isFinal;
}
