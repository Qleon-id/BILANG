import 'package:flutter/material.dart';

class ListeningView extends StatelessWidget {
  const ListeningView({
    super.key,
    required this.onStop,
    required this.onCancel,
    this.transcript = '',
  });

  final VoidCallback onStop;
  final VoidCallback onCancel;
  final String transcript;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text('Aku dengarkan...'),
        const SizedBox(height: 12),
        const Icon(Icons.graphic_eq, size: 48),
        const SizedBox(height: 12),
        Text(
          transcript.isEmpty ? 'Bilang aja seperti biasa...' : transcript,
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            OutlinedButton(onPressed: onCancel, child: const Text('Batal')),
            const SizedBox(width: 12),
            FilledButton(onPressed: onStop, child: const Text('Selesai')),
          ],
        ),
      ],
    );
  }
}
