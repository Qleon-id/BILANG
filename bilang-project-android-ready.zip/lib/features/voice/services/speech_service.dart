import 'dart:async';

import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../models/speech_state.dart';

class SpeechService {
  SpeechService({stt.SpeechToText? speech})
      : _speech = speech ?? stt.SpeechToText();

  final stt.SpeechToText _speech;
  final _results = StreamController<SpeechResult>.broadcast();
  SpeechState _state = SpeechState.idle;

  SpeechState get state => _state;
  Stream<SpeechResult> get resultStream => _results.stream;

  Future<bool> isAvailable() async {
    try {
      return await _speech.initialize();
    } catch (_) {
      _state = SpeechState.unavailable;
      return false;
    }
  }

  Future<bool> startListening({
    String localeId = 'id_ID',
    Duration listenFor = const Duration(minutes: 1),
    Duration pauseFor = const Duration(seconds: 3),
  }) async {
    if (!await isAvailable()) {
      _state = SpeechState.unavailable;
      return false;
    }
    _state = SpeechState.listening;
    await _speech.listen(
      localeId: localeId,
      listenFor: listenFor,
      pauseFor: pauseFor,
      onResult: (result) {
        _results.add(SpeechResult(
          text: result.recognizedWords,
          isFinal: result.finalResult,
        ));
        if (result.finalResult) _state = SpeechState.processing;
      },
    );
    return true;
  }

  Future<void> stopListening() async {
    await _speech.stop();
    _state = SpeechState.processing;
  }

  Future<void> cancel() async {
    await _speech.cancel();
    _state = SpeechState.idle;
  }

  Future<void> dispose() async {
    await _speech.cancel();
    await _results.close();
  }
}
