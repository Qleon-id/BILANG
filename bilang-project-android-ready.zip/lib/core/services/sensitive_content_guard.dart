class SensitiveContentGuard {
  const SensitiveContentGuard._();

  static bool isSensitive(String value) {
    final text = value.toLowerCase();
    return RegExp(r'\b(password|kata sandi|passcode|pin|otp|cvv|cvc|security code|kode verifikasi)\b').hasMatch(text) ||
        RegExp(r'\b\d{3,8}\b').hasMatch(text) &&
            RegExp(r'\b(pin|otp|cvv|cvc|kode|code)\b').hasMatch(text);
  }

  static String warning(String value) =>
      'Aku nggak akan menyimpan informasi sensitif seperti PIN, OTP, password, atau CVV sebagai ingatan biasa.';
}
