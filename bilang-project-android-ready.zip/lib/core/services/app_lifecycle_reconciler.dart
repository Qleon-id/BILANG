import 'package:flutter/widgets.dart';

import '../../features/notifications/notification_service.dart';

class AppLifecycleReconciler with WidgetsBindingObserver {
  AppLifecycleReconciler({NotificationService? notifications})
      : _notifications = notifications ?? NotificationService.instance;

  final NotificationService _notifications;
  bool _attached = false;

  void attach() {
    if (_attached) return;
    WidgetsBinding.instance.addObserver(this);
    _attached = true;
  }

  void dispose() {
    if (!_attached) return;
    WidgetsBinding.instance.removeObserver(this);
    _attached = false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _reconcile();
    }
  }

  Future<void> _reconcile() async {
    try {
      await _notifications.initialize();
      await _notifications.rescheduleAll();
    } catch (_) {
      // Reconciliation is best-effort; existing local data remains intact.
    }
  }
}
