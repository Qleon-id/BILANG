import '../../data/models/memory.dart';
import '../../data/models/reminder.dart';

/// Small deterministic checks used by the V1 readiness layer.
/// It never mutates user data.
class DataIntegrityService {
  const DataIntegrityService();

  List<String> validateReminders(List<Reminder> reminders) {
    final issues = <String>[];
    final ids = <String>{};
    for (final reminder in reminders) {
      if (reminder.id.trim().isEmpty) issues.add('Reminder memiliki ID kosong.');
      if (!ids.add(reminder.id)) issues.add('Reminder memiliki ID duplikat: ${reminder.id}.');
      if (reminder.title.trim().isEmpty) issues.add('Reminder memiliki judul kosong: ${reminder.id}.');
    }
    return issues;
  }

  List<String> validateMemories(List<Memory> memories) {
    final issues = <String>[];
    final ids = <String>{};
    for (final memory in memories) {
      if (memory.id.trim().isEmpty) issues.add('Memory memiliki ID kosong.');
      if (!ids.add(memory.id)) issues.add('Memory memiliki ID duplikat: ${memory.id}.');
      if (memory.title.trim().isEmpty) issues.add('Memory memiliki judul kosong: ${memory.id}.');
      if (memory.content.trim().isEmpty) issues.add('Memory memiliki isi kosong: ${memory.id}.');
    }
    return issues;
  }
}
