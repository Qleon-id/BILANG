import 'dart:convert';

enum ReminderStatus { active, triggered, completed, snoozed, dismissed }

enum ReminderRecurrence { none, daily, weekly, monthly }

class Reminder {
  const Reminder({
    required this.id,
    required this.title,
    required this.scheduledAt,
    this.status = ReminderStatus.active,
    this.recurrence = ReminderRecurrence.none,
  });

  final String id;
  final String title;
  final DateTime scheduledAt;
  final ReminderStatus status;
  final ReminderRecurrence recurrence;

  Reminder copyWith({String? title, DateTime? scheduledAt, ReminderStatus? status, ReminderRecurrence? recurrence}) {
    return Reminder(
      id: id,
      title: title ?? this.title,
      scheduledAt: scheduledAt ?? this.scheduledAt,
      status: status ?? this.status,
      recurrence: recurrence ?? this.recurrence,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'scheduledAt': scheduledAt.toIso8601String(),
        'status': status.name,
        'recurrence': recurrence.name,
      };

  factory Reminder.fromMap(Map<String, dynamic> map) => Reminder(
        id: map['id'] as String,
        title: map['title'] as String,
        scheduledAt: DateTime.parse(map['scheduledAt'] as String),
        status: ReminderStatus.values.firstWhere(
          (value) => value.name == map['status'],
          orElse: () => ReminderStatus.active,
        ),
        recurrence: ReminderRecurrence.values.firstWhere(
          (value) => value.name == map['recurrence'],
          orElse: () => ReminderRecurrence.none,
        ),
      );

  String toJson() => jsonEncode(toMap());
  factory Reminder.fromJson(String value) => Reminder.fromMap(jsonDecode(value) as Map<String, dynamic>);
}
