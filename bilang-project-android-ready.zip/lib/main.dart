import 'package:flutter/material.dart';

import 'core/services/local_settings_service.dart';
import 'core/theme/bilang_theme.dart';
import 'core/services/app_lifecycle_reconciler.dart';
import 'features/onboarding/onboarding.dart';
import 'features/notifications/notification_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BilangApp());
}

class BilangApp extends StatefulWidget {
  const BilangApp({super.key});

  @override
  State<BilangApp> createState() => _BilangAppState();
}

class _BilangAppState extends State<BilangApp> {
  String selectedTheme = 'yellow';
  String appThemeMode = 'system';
  final AppLifecycleReconciler _lifecycleReconciler = AppLifecycleReconciler();

  @override
  void initState() {
    super.initState();
    _lifecycleReconciler.attach();
    _loadTheme();
    _loadThemeMode();
    NotificationService.instance.initialize().then((_) => NotificationService.instance.rescheduleAll());
  }


  @override
  void dispose() {
    _lifecycleReconciler.dispose();
    super.dispose();
  }

  Future<void> _loadThemeMode() async {
    final mode = await LocalSettingsService().getAppThemeMode();
    if (mounted) setState(() => appThemeMode = mode);
  }

  Future<void> _loadTheme() async {
    final theme = await LocalSettingsService().getSelectedTheme();
    if (mounted) setState(() => selectedTheme = theme);
  }

  void _setTheme(String id) {
    setState(() => selectedTheme = id);
  }

  Future<void> _setThemeMode(String mode) async {
    await LocalSettingsService().setAppThemeMode(mode);
    if (mounted) setState(() => appThemeMode = mode);
  }

  ThemeMode _themeMode() => switch (appThemeMode) {
    'light' => ThemeMode.light,
    'dark' => ThemeMode.dark,
    _ => ThemeMode.system,
  };

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BILANG',
      debugShowCheckedModeBanner: false,
      theme: buildBilangTheme(selectedTheme, brightness: Brightness.light),
      darkTheme: buildBilangTheme(selectedTheme, brightness: Brightness.dark),
      themeMode: _themeMode(),
      home: BilangOpeningScreen(onThemeChanged: _setTheme, onThemeModeChanged: _setThemeMode),
    );
  }
}
