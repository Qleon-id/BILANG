import 'package:flutter_test/flutter_test.dart';

import '../lib/core/services/data_integrity_service.dart';
import '../lib/data/models/memory.dart';
import '../lib/data/models/reminder.dart';

void main() {
  const service = DataIntegrityService();

  test('reminder integrity detects duplicate IDs and empty titles', () {
    final issues = service.validateReminders([
      Reminder(id: '1', title: 'Bayar listrik', scheduledAt: DateTime(2026, 10, 1, 18)),
      Reminder(id: '1', title: '', scheduledAt: DateTime(2026, 10, 2, 18)),
    ]);
    expect(issues.length, 2);
  });

  test('memory integrity accepts a valid memory', () {
    final issues = service.validateMemories([
      Memory(id: 'm1', title: 'Nomor loker', content: '27', type: MemoryType.fact, category: MemoryCategory.personal),
    ]);
    expect(issues, isEmpty);
  });
}
