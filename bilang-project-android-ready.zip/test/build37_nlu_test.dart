import 'package:flutter_test/flutter_test.dart';
import 'package:bilang/features/nlu/engine/bilang_engine.dart';
import 'package:bilang/features/nlu/models/bilang_result.dart';

void main() {
  const engine = BilangEngine();
  final now = DateTime(2026, 9, 22, 10);

  test('parses casual reminder with date and time', () {
    final result = engine.processInput(
      'Besok jam 7 ingetin gue bawa charger',
      now: now,
    );
    expect(result.intent, BilangIntent.createReminder);
    expect(result.confidence, BilangConfidence.high);
    expect(result.time, '07:00');
    expect(result.date, DateTime(2026, 9, 23));
    expect(result.content, 'bawa charger');
  });

  test('asks for missing time instead of guessing', () {
    final result = engine.processInput('Besok pagi ingetin gue bawa charger', now: now);
    expect(result.intent, BilangIntent.createReminder);
    expect(result.confidence, BilangConfidence.medium);
    expect(result.clarification, 'Jam berapa besok aku ingatkan?');
  });

  test('understands reschedule follow-up', () {
    final result = engine.processInput('Jamnya jadi jam 8', now: now);
    expect(result.intent, BilangIntent.rescheduleReminder);
    expect(result.time, '08:00');
  });

  test('understands reminder deletion', () {
    final result = engine.processInput('Yang charger tadi jangan jadi', now: now);
    expect(result.intent, BilangIntent.deleteReminder);
  });

  test('creates memory from a fact', () {
    final result = engine.processInput('Nomor loker gue 27', now: now);
    expect(result.intent, BilangIntent.createMemory);
    expect(result.title, 'Nomor loker');
    expect(result.content, '27');
  });

  test('reads a memory', () {
    final result = engine.processInput('Nomor loker gue berapa?', now: now);
    expect(result.intent, BilangIntent.readMemory);
    expect(result.targetQuery, 'nomor loker');
  });

  test('updates an existing memory', () {
    final result = engine.processInput('Nomor loker gue sekarang 35', now: now);
    expect(result.intent, BilangIntent.updateMemory);
    expect(result.content, '35');
  });

  test('understands recurring reminders', () {
    final result = engine.processInput('Setiap hari jam 7 ingetin gue minum air', now: now);
    expect(result.intent, BilangIntent.createReminder);
    expect(result.recurrence, BilangRecurrence.daily);
    expect(result.time, '07:00');
  });

  test('does not create an empty reminder', () {
    final result = engine.processInput('Nanti ingetin gue', now: now);
    expect(result.intent, BilangIntent.createReminder);
    expect(result.confidence, BilangConfidence.medium);
    expect(result.needsClarification, isTrue);
  });
}
