import 'package:flutter_test/flutter_test.dart';
import 'package:bilang/features/voice/models/speech_state.dart';

void main() {
  test('speech states include the required V1 flow', () {
    expect(SpeechState.values, contains(SpeechState.listening));
    expect(SpeechState.values, contains(SpeechState.processing));
    expect(SpeechState.values, contains(SpeechState.error));
    expect(SpeechState.values, contains(SpeechState.unavailable));
  });
}
