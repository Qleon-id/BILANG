import 'package:flutter_test/flutter_test.dart';
import 'package:bilang/features/nlu/context/bilang_context.dart';
import 'package:bilang/features/nlu/engine/bilang_engine.dart';
import 'package:bilang/features/nlu/models/bilang_result.dart';

void main() {
  final now = DateTime(2026, 9, 22, 10, 0);
  const engine = BilangEngine();

  test('follow-up context can expire', () {
    final result = engine.processInput('Besok jam 7 ingetin gue bawa charger', now: now);
    final context = BilangContext(
      result: result,
      createdAt: now,
      expiresAt: now.add(const Duration(minutes: 10)),
    );

    expect(context.isExpired(now.add(const Duration(minutes: 5))), isFalse);
    expect(context.isExpired(now.add(const Duration(minutes: 11))), isTrue);
  });

  test('engine keeps missing time as clarification instead of guessing', () {
    final result = engine.processInput('Besok pagi ingetin gue bawa charger', now: now);
    expect(result.intent, BilangIntent.createReminder);
    expect(result.confidence, BilangConfidence.medium);
    expect(result.needsClarification, isTrue);
    expect(result.time, isNull);
  });
}
