# Android Build

This project is flattened so `pubspec.yaml` is at the project root.

GitHub Actions workflow:
`.github/workflows/android-build.yml`

It runs `flutter pub get`, `flutter test`, then `flutter build apk --release` and uploads the APK as the `bilang-android-release` artifact.

Note: this workflow verifies the actual Flutter build in GitHub. It does not extract `bilang-project.zip`; the ZIP remains a snapshot for upload/storage.
