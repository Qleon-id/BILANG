
/// Natural-language intent and entity extraction shared by Text and Voice.
enum BilangIntent {
  createReminder,
  updateReminder,
  completeReminder,
  rescheduleReminder,
  deleteReminder,
  createMemory,
  readMemory,
  updateMemory,
  deleteMemory,
  cancel,
  unknown,
}

enum Confidence { high, medium, low }

class EngineResult {
  final BilangIntent intent;
  final Confidence confidence;
  final Map<String, dynamic> entities;
  final bool requiresClarification;
  final bool requiresConfirmation;
  final String? response;

  const EngineResult({
    required this.intent,
    required this.confidence,
    this.entities = const {},
    this.requiresClarification = false,
    this.requiresConfirmation = false,
    this.response,
  });
}

/// V1.2 text brain.
///
/// This parser deliberately favors asking a question over guessing when a
/// required reminder date/time is missing or ambiguous. Voice will reuse the
/// same engine in V1.3.
class MemoryFields {
  final String title;
  final String content;
  const MemoryFields({required this.title, required this.content});
}

class BilangEngine {
  /// Turns natural memory statements into a compact key/value style.
  /// Examples: "gua parkir di B3" -> Parkir • B3,
  /// "aku taruh kunci di laci" -> Kunci • di laci,
  /// "ukuran sepatu gua 43" -> Ukuran sepatu • 43.
  MemoryFields parseMemory(String input) {
    var text = _normalize(input);
    text = text.replaceFirst(RegExp(
      r'^(?:tolong\s+)?(?:ingat(?:kan)?(?:\s+(?:aku|gua|gue|gw|saya|kamu|lu))?|simpan(?:kan)?(?:\s+ini)?|catat(?:kan)?(?:\s+ini)?|aku mau kamu ingat|gua mau lu inget|gue mau lu inget|tolong inget)\s*',
      caseSensitive: false,
    ), '');
    text = text.replaceFirst(RegExp(r'^(?:bahwa|kalau)\s+'), '');
    text = text.trim();

    // Location/placement statements.
    final placed = RegExp(
      r'^(?:aku|saya|gua|gue|gw|aq)\s+(?:lagi\s+)?(?:taruh|naruh|nyimpen|nyimpan|simpan|letak|meletakkan|menaruh|parkir)\s+(.+?)\s+(di|dalam|ke)\s+(.+)$',
    ).firstMatch(text);
    if (placed != null) {
      final object = _cleanMemoryTitle(placed.group(1)!);
      final location = '${placed.group(2)} ${placed.group(3)}'.trim();
      if (object.isNotEmpty && location.isNotEmpty) {
        return MemoryFields(title: _capitalize(object), content: location);
      }
    }

    // "gua parkir di B3" has no explicit object, so the action becomes the key.
    final parked = RegExp(
      r'^(?:aku|saya|gua|gue|gw|aq)\s+(?:lagi\s+)?parkir\s+(?:di\s+)?(.+)$',
    ).firstMatch(text);
    if (parked != null) {
      final value = parked.group(1)!.trim();
      if (value.isNotEmpty) return MemoryFields(title: 'Parkir', content: value);
    }

    // Attribute/fact statements: "ukuran sepatu gua 43", "nomor kamar saya 12".
    final attribute = RegExp(
      r'^(.*?)\s+(?:aku|saya|gua|gue|gw|punya|adalah)\s*([A-Za-z0-9]+(?:[\s.-][A-Za-z0-9]+)*)$',
    ).firstMatch(text);
    if (attribute != null) {
      final key = _cleanMemoryTitle(attribute.group(1)!);
      final value = attribute.group(2)!.trim();
      if (_looksLikeAttributeKey(key) && value.isNotEmpty) {
        return MemoryFields(title: _capitalize(key), content: value);
      }
    }

    final possessive = RegExp(
      r'^(.*?)\s+(?:aku|saya|gua|gue|gw)\s+(?:adalah|punya)\s+(.+)$',
    ).firstMatch(text);
    if (possessive != null) {
      final key = _cleanMemoryTitle(possessive.group(1)!);
      final value = possessive.group(2)!.trim();
      if (key.isNotEmpty && value.isNotEmpty) {
        return MemoryFields(title: _capitalize(key), content: value);
      }
    }

    // Preference statements: "aku suka kopi susu" / "gua nggak suka pedas".
    final preference = RegExp(
      r'^(?:aku|saya|gua|gue|gw|aq)\s+(suka|senang|favorit|lebih suka|nggak suka|gak suka|tidak suka)\s+(.+)$',
    ).firstMatch(text);
    if (preference != null) {
      final relation = preference.group(1)!.trim();
      final value = preference.group(2)!.trim();
      return MemoryFields(title: _capitalize(relation), content: value);
    }

    // General "X adalah Y" / "X itu Y" facts.
    final general = RegExp(r'^(.*?)\s+(?:adalah|itu|=)\s+(.+)$').firstMatch(text);
    if (general != null) {
      final key = _cleanMemoryTitle(general.group(1)!);
      final value = general.group(2)!.trim();
      if (key.isNotEmpty && value.isNotEmpty) {
        return MemoryFields(title: _capitalize(key), content: value);
      }
    }

    // Fallback: keep the information, but still make the title compact.
    final words = text.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.length >= 2) {
      final split = (words.length / 2).ceil().clamp(1, words.length - 1);
      final title = _cleanMemoryTitle(words.take(split).join(' '));
      final content = words.skip(split).join(' ');
      if (title.isNotEmpty && content.isNotEmpty) {
        return MemoryFields(title: _capitalize(title), content: content);
      }
    }
    return MemoryFields(title: _capitalize(text), content: text);
  }

  bool _looksLikeAttributeKey(String key) {
    return RegExp(r'\b(ukuran|size|nomor|no|alamat|ulang tahun|tanggal|tinggi|berat|golongan|nama|warna|password|pin)\b').hasMatch(key) ||
        key.split(' ').length >= 2;
  }

  String _cleanMemoryTitle(String value) {
    return value
        .replaceAll(RegExp(r'\b(aku|saya|gua|gue|gw|aq|punya|adalah|itu)\b'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  String _capitalize(String value) {
    final clean = value.trim();
    if (clean.isEmpty) return clean;
    return clean[0].toUpperCase() + clean.substring(1);
  }

  Future<EngineResult> processInput(String input) async {
    final original = input.trim();
    if (original.isEmpty) {
      return const EngineResult(
        intent: BilangIntent.unknown,
        confidence: Confidence.low,
        response: 'Aku belum yakin menangkap maksudmu. 👀',
      );
    }

    final text = _normalize(original);
    final intent = _detectIntent(text);

    if (intent == BilangIntent.cancel) {
      return const EngineResult(
        intent: BilangIntent.cancel,
        confidence: Confidence.high,
        response: 'Oke, aku batalkan.',
      );
    }

    if (intent == BilangIntent.createMemory) {
      final content = _extractMemoryContent(text);
      if (content.isEmpty) {
        return const EngineResult(
          intent: BilangIntent.createMemory,
          confidence: Confidence.low,
          requiresClarification: true,
          response: 'Apa yang mau kamu simpan di Ingatan?',
        );
      }
      final fields = parseMemory(content);
      return EngineResult(
        intent: BilangIntent.createMemory,
        confidence: Confidence.high,
        entities: {
          'content': fields.content,
          'title': fields.title,
        },
        requiresConfirmation: true,
        response: 'Aku mau simpan ini di Ingatan...',
      );
    }

    if (intent == BilangIntent.readMemory) {
      final query = _extractMemoryQuery(text);
      return EngineResult(
        intent: BilangIntent.readMemory,
        confidence: query.isEmpty ? Confidence.low : Confidence.high,
        entities: {'query': query},
        response: query.isEmpty
            ? 'Mau cari ingatan tentang apa?'
            : 'Aku cari di Ingatan dulu. 🧠',
      );
    }

    if (intent == BilangIntent.deleteMemory || intent == BilangIntent.updateMemory) {
      final query = _extractMemoryQuery(text);
      return EngineResult(
        intent: intent,
        confidence: query.isEmpty ? Confidence.low : Confidence.medium,
        entities: {'query': query},
        requiresConfirmation: query.isNotEmpty,
        response: query.isEmpty
            ? 'Ingatan yang mana?'
            : intent == BilangIntent.deleteMemory
                ? 'Aku cari ingatan yang mau dilupakan dulu.'
                : 'Aku cari ingatan yang mau diubah dulu.',
      );
    }

    if (intent != BilangIntent.createReminder) {
      return EngineResult(
        intent: intent,
        confidence: intent == BilangIntent.unknown ? Confidence.low : Confidence.medium,
        response: intent == BilangIntent.unknown
            ? 'Aku belum yakin menangkap maksudmu. 👀'
            : 'Aku sudah menangkap maksudmu, tapi tindakan ini belum aktif sepenuhnya.',
      );
    }

    final now = DateTime.now();
    final dateInfo = _extractDate(text);
    final weekdayInfo = _extractWeekday(text);
    final relativeInfo = _extractRelativeDuration(text);
    final timeInfo = relativeInfo == null ? _extractTime(text) : const _TimeInfo(null, null, null);
    final title = _extractTitle(text);

    if (title.isEmpty) {
      return const EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.low,
        requiresClarification: true,
        response: 'Apa yang perlu aku ingatkan?',
      );
    }

    final period = timeInfo.period;
    final resolvedDate = relativeInfo != null
        ? DateTime(now.year, now.month, now.day)
        : weekdayInfo != null
            ? _nextWeekdayDate(now, weekdayInfo.weekday)
            : dateInfo.date ??
                ((period != null || timeInfo.time != null)
                    ? DateTime(now.year, now.month, now.day)
                    : null);

    if (resolvedDate == null) {
      return EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.medium,
        entities: {'title': title},
        requiresClarification: true,
        response: 'Kapan aku harus mengingatkannya?',
      );
    }

    if (relativeInfo == null && timeInfo.time == null && period == null && weekdayInfo == null) {
      return EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.medium,
        entities: {'title': title, 'date': resolvedDate},
        requiresClarification: true,
        response: 'Jam berapa aku harus mengingatkannya?',
      );
    }

    final date = resolvedDate;
    final isWeekly = weekdayInfo != null;
    final effectivePeriod = isWeekly && timeInfo.time == null ? (period ?? 'pagi') : period;
    final time = timeInfo.time ?? _periodStart(effectivePeriod ?? 'pagi');
    final periodEnd = effectivePeriod == null ? null : _periodEnd(effectivePeriod);
    final isWeeklySeries = isWeekly && timeInfo.time == null;
    final isPeriodSeries = relativeInfo == null && effectivePeriod != null && timeInfo.time == null && !isWeekly;
    final scheduledAt = relativeInfo != null
        ? now.add(relativeInfo.duration)
        : DateTime(date.year, date.month, date.day, time.hour, time.minute);

    if (scheduledAt.isBefore(now) && isWeekly) {
      final next = scheduledAt.add(const Duration(days: 7));
      return EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.high,
        entities: {
          'title': title,
          'date': DateTime(next.year, next.month, next.day),
          'time': TimeOfDayParts(next.hour, next.minute),
          'scheduledAt': next,
          'dateLabel': weekdayInfo.label,
          'timeLabel': isWeeklySeries
              ? '${_formatTime(next.hour, next.minute)} - ${_formatTime(periodEnd!.hour, periodEnd.minute)}'
              : _formatTime(next.hour, next.minute),
          'weekday': weekdayInfo.weekday,
          'weekdayLabel': weekdayInfo.label,
          'recurrence': 'weekly',
          if (effectivePeriod != null) 'period': effectivePeriod,
          if (periodEnd != null) 'periodEnd': periodEnd,
          'periodSeries': isWeeklySeries,
          if (isWeeklySeries) 'recurrenceIntervalMinutes': 60,
          if (isWeeklySeries) 'recurrenceEndMinute': periodEnd!.hour * 60 + periodEnd.minute,
          if (isWeeklySeries) 'recurrenceWindow': effectivePeriod,
        },
        requiresConfirmation: true,
        response: 'Aku menangkap ini sebagai titipan setiap ${weekdayInfo.label}.',
      );
    }

    if (scheduledAt.isBefore(now) && !isPeriodSeries) {
      return EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.medium,
        entities: {
          'title': title,
          'date': date,
          'time': time,
          'scheduledAt': scheduledAt,
        },
        requiresClarification: true,
        response: 'Waktu itu sudah lewat. Kamu mau pilih waktu lain?',
      );
    }

    return EngineResult(
      intent: BilangIntent.createReminder,
      confidence: Confidence.high,
      entities: {
        'title': title,
        'date': DateTime(scheduledAt.year, scheduledAt.month, scheduledAt.day),
        'time': TimeOfDayParts(scheduledAt.hour, scheduledAt.minute),
        'scheduledAt': scheduledAt,
        'dateLabel': relativeInfo != null ? 'hari ini' : (weekdayInfo?.label ?? dateInfo.label),
        'timeLabel': relativeInfo != null ? _formatTime(scheduledAt.hour, scheduledAt.minute) : (isWeeklySeries ? '${_formatTime(scheduledAt.hour, scheduledAt.minute)} - ${_formatTime(periodEnd!.hour, periodEnd.minute)}' : timeInfo.label),
        if (relativeInfo != null) 'relativeDuration': relativeInfo.duration,
        if (relativeInfo != null) 'relativeLabel': relativeInfo.label,
        if (period != null) 'period': period,
        if (periodEnd != null) 'periodEnd': periodEnd,
        if (weekdayInfo != null) 'weekday': weekdayInfo.weekday,
        if (weekdayInfo != null) 'weekdayLabel': weekdayInfo.label,
        if (weekdayInfo != null) 'recurrence': 'weekly',
        'periodSeries': isPeriodSeries,
        if (isWeeklySeries) 'recurrenceIntervalMinutes': 60,
        if (isWeeklySeries) 'recurrenceEndMinute': periodEnd!.hour * 60 + periodEnd.minute,
        if (isWeeklySeries) 'recurrenceWindow': effectivePeriod,
      },
      requiresConfirmation: true,
      response: 'Aku menangkap ini...',
    );
  }

  String _normalize(String input) {
    return input
        .toLowerCase()
        .replaceAll(RegExp(r'[!?]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  BilangIntent _detectIntent(String text) {
    if (RegExp(r'^(batal|cancel|nggak jadi|gak jadi|tidak jadi)').hasMatch(text)) {
      return BilangIntent.cancel;
    }
    if (RegExp(r'\b(lupakan|hapus|delete)\b').hasMatch(text)) {
      if (RegExp(r'\b(ingatan|memory|yang aku simpan|catatan)\b').hasMatch(text)) return BilangIntent.deleteMemory;
      return BilangIntent.deleteReminder;
    }
    if (RegExp(r'\b(ubah|ganti|update)\b').hasMatch(text) &&
        RegExp(r'\b(ingatan|memory|catatan)\b').hasMatch(text)) {
      return BilangIntent.updateMemory;
    }
    if (RegExp(r'\b(sudah|selesai|beres|done)\b').hasMatch(text)) {
      return BilangIntent.completeReminder;
    }
    if (RegExp(r'\b(ubah|ganti|update|reschedule|jadwal ulang)\b').hasMatch(text)) {
      return text.contains('jam') || text.contains('jadwal')
          ? BilangIntent.rescheduleReminder
          : BilangIntent.updateReminder;
    }
    if (RegExp(r'\b(ingat bahwa|ingat kalau|simpan sebagai ingatan|simpan ini|catat ini|ingat ini|tolong ingat)\b').hasMatch(text)) {
      return BilangIntent.createMemory;
    }
    if (RegExp(r'\b(apa yang aku ingat|apa yang kamu ingat|cari ingatan|ingatanku tentang|aku suka apa|apa yang aku suka|favoritku|apa yang aku simpan)\b').hasMatch(text)) {
      return BilangIntent.readMemory;
    }
    if (_looksLikeReminder(text)) return BilangIntent.createReminder;
    return BilangIntent.unknown;
  }

  bool _looksLikeReminder(String text) {
    return RegExp(r'\b(ingatkan|ingetin|ingatkan aku|ingetin aku|titipkan|titip|jangan lupa|remind me|remind|ingat aku)\b')
            .hasMatch(text) ||
        _extractRelativeDuration(text) != null ||
        (_extractDate(text).date != null && _extractTime(text).time != null) ||
        _extractWeekday(text) != null;
  }

  _WeekdayInfo? _extractWeekday(String text) {
    const weekdays = <String, int>{
      'senin': DateTime.monday,
      'selasa': DateTime.tuesday,
      'rabu': DateTime.wednesday,
      'kamis': DateTime.thursday,
      'jumat': DateTime.friday,
      'sabtu': DateTime.saturday,
      'minggu': DateTime.sunday,
    };
    final match = RegExp(r"\b(?:setiap\s+)?(senin|selasa|rabu|kamis|jumat|jum'at|sabtu|minggu)\b")
        .firstMatch(text);
    if (match == null) return null;
    final raw = match.group(1)!;
    final normalized = raw == "jum'at" ? 'jumat' : raw;
    return _WeekdayInfo(weekdays[normalized]!, normalized[0].toUpperCase() + normalized.substring(1));
  }

  DateTime _nextWeekdayDate(DateTime now, int weekday) {
    final today = DateTime(now.year, now.month, now.day);
    var delta = (weekday - today.weekday) % 7;
    return today.add(Duration(days: delta));
  }

  _DateInfo _extractDate(String text) {
    final now = DateTime.now();
    if (text.contains('lusa')) return _DateInfo(DateTime(now.year, now.month, now.day + 2), 'lusa');
    if (text.contains('besok')) return _DateInfo(DateTime(now.year, now.month, now.day + 1), 'besok');
    if (text.contains('hari ini')) return _DateInfo(DateTime(now.year, now.month, now.day), 'hari ini');
    if (RegExp(r'\bsehari\s+lagi\b').hasMatch(text)) {
      return _DateInfo(DateTime(now.year, now.month, now.day + 1), '1 hari lagi');
    }
    if (RegExp(r'\bseminggu\s+lagi\b').hasMatch(text)) {
      return _DateInfo(DateTime(now.year, now.month, now.day + 7), '1 minggu lagi');
    }
    if (RegExp(r'\bsebulan\s+lagi\b').hasMatch(text)) {
      return _DateInfo(_addMonthsPreservingDay(now, 1), '1 bulan lagi');
    }
    if (RegExp(r'\bsetahun\s+lagi\b').hasMatch(text)) {
      final date = _safeDate(now.year + 1, now.month, now.day) ?? DateTime(now.year + 1, now.month, now.day);
      return _DateInfo(date, '1 tahun lagi');
    }

    const words = <String, int>{
      'satu': 1, 'dua': 2, 'tiga': 3, 'empat': 4, 'lima': 5, 'enam': 6,
      'tujuh': 7, 'delapan': 8, 'sembilan': 9, 'sepuluh': 10, 'sebelas': 11,
      'dua belas': 12, 'tiga belas': 13, 'empat belas': 14, 'lima belas': 15,
      'enam belas': 16, 'tujuh belas': 17, 'delapan belas': 18, 'sembilan belas': 19,
      'dua puluh': 20, 'dua puluh satu': 21, 'dua puluh dua': 22, 'dua puluh tiga': 23,
      'dua puluh empat': 24, 'dua puluh lima': 25, 'dua puluh enam': 26,
      'dua puluh tujuh': 27, 'dua puluh delapan': 28, 'dua puluh sembilan': 29,
      'tiga puluh': 30, 'tiga puluh satu': 31,
    };

    final dayCount = _extractCountBeforeUnit(text, words, 'hari');
    if (dayCount != null) {
      return _DateInfo(DateTime(now.year, now.month, now.day + dayCount), '$dayCount hari lagi');
    }
    final weekCount = _extractCountBeforeUnit(text, words, 'minggu');
    if (weekCount != null) {
      return _DateInfo(DateTime(now.year, now.month, now.day + weekCount * 7), '$weekCount minggu lagi');
    }

    if (text.contains('bulan depan')) {
      return _DateInfo(_addMonthsPreservingDay(now, 1), 'bulan depan');
    }
    final monthCount = _extractCountBeforeUnit(text, words, 'bulan');
    if (monthCount != null) {
      return _DateInfo(_addMonthsPreservingDay(now, monthCount), '$monthCount bulan lagi');
    }

    if (text.contains('tahun depan')) {
      final date = _safeDate(now.year + 1, now.month, now.day) ?? DateTime(now.year + 1, now.month, now.day);
      return _DateInfo(date, 'tahun depan');
    }
    final yearCount = _extractCountBeforeUnit(text, words, 'tahun');
    if (yearCount != null) {
      final date = _safeDate(now.year + yearCount, now.month, now.day) ?? DateTime(now.year + yearCount, now.month, now.day);
      return _DateInfo(date, '$yearCount tahun lagi');
    }

    if (text.contains('minggu depan')) {
      return _DateInfo(DateTime(now.year, now.month, now.day + 7), 'minggu depan');
    }

    final explicit = RegExp(r'\b(\d{1,2})[\/-](\d{1,2})(?:[\/-](\d{2,4}))?\b').firstMatch(text);
    if (explicit != null) {
      final day = int.parse(explicit.group(1)!);
      final month = int.parse(explicit.group(2)!);
      final year = explicit.group(3) == null ? now.year : int.parse(explicit.group(3)!);
      final fixedYear = year < 100 ? 2000 + year : year;
      final date = _safeDate(fixedYear, month, day);
      if (date != null) return _DateInfo(date, '$day/$month/$fixedYear');
    }

    const months = <String, int>{
      'januari': 1, 'februari': 2, 'maret': 3, 'april': 4, 'mei': 5, 'juni': 6,
      'juli': 7, 'agustus': 8, 'september': 9, 'oktober': 10, 'november': 11, 'desember': 12,
    };
    for (final entry in months.entries) {
      final match = RegExp(r'\b(\d{1,2})\s+' + entry.key + r'(?:\s+(\d{4}))?\b').firstMatch(text);
      if (match != null) {
        final day = int.parse(match.group(1)!);
        final year = match.group(2) == null ? now.year : int.parse(match.group(2)!);
        final date = _safeDate(year, entry.value, day);
        if (date != null) return _DateInfo(date, '$day ${entry.key} $year');
      }
    }
    return const _DateInfo(null, null);
  }

  int? _extractCountBeforeUnit(String text, Map<String, int> words, String unit) {
    final keys = words.keys.toList()..sort((a, b) => b.length.compareTo(a.length));
    final pattern = RegExp(r'\b((?:\d+|' + keys.map(RegExp.escape).join('|') + r'))\s+' + unit + r'\s+lagi\b');
    final match = pattern.firstMatch(text);
    if (match == null) return null;
    return _parseCount(match.group(1)!, words);
  }

  int? _parseCount(String raw, Map<String, int> words) {
    final numeric = int.tryParse(raw);
    return numeric ?? words[raw];
  }

  DateTime _addMonthsPreservingDay(DateTime base, int months) {
    final target = DateTime(base.year, base.month + months, 1);
    final lastDay = DateTime(target.year, target.month + 1, 0).day;
    final day = base.day > lastDay ? lastDay : base.day;
    return DateTime(target.year, target.month, day);
  }

  _RelativeDurationInfo? _extractRelativeDuration(String text) {
    if (!RegExp(r'\blagi\b').hasMatch(text)) return null;

    if (RegExp(r'\bsetengah\s+jam\s+lagi\b').hasMatch(text)) {
      return const _RelativeDurationInfo(Duration(minutes: 30), '30 menit lagi');
    }
    if (RegExp(r'\bseperempat\s+jam\s+lagi\b').hasMatch(text)) {
      return const _RelativeDurationInfo(Duration(minutes: 15), '15 menit lagi');
    }
    if (RegExp(r'\bsejam\s+lagi\b').hasMatch(text)) {
      return const _RelativeDurationInfo(Duration(hours: 1), '1 jam lagi');
    }

    final numeric = RegExp(r'\b(\d+(?:[.,]\d+)?)\s*(menit|jam)\s+lagi\b').firstMatch(text);
    if (numeric != null) {
      final amount = double.tryParse(numeric.group(1)!.replaceAll(',', '.'));
      if (amount == null || amount <= 0) return null;
      final unit = numeric.group(2)!;
      final minutes = unit == 'jam' ? (amount * 60).round() : amount.round();
      if (minutes <= 0) return null;
      return _RelativeDurationInfo(
        Duration(minutes: minutes),
        unit == 'jam' ? '${_compactNumber(amount)} jam lagi' : '${_compactNumber(amount)} menit lagi',
      );
    }

    const words = <String, int>{
      'satu': 1,
      'dua': 2,
      'tiga': 3,
      'empat': 4,
      'lima': 5,
      'enam': 6,
      'tujuh': 7,
      'delapan': 8,
      'sembilan': 9,
      'sepuluh': 10,
      'sebelas': 11,
    };
    final spoken = RegExp(
      r'\b(satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas)\s*(menit|jam)\s+lagi\b',
    ).firstMatch(text);
    if (spoken != null) {
      final amount = words[spoken.group(1)!]!;
      final unit = spoken.group(2)!;
      final minutes = unit == 'jam' ? amount * 60 : amount;
      return _RelativeDurationInfo(
        Duration(minutes: minutes),
        '$amount ${unit == 'jam' ? 'jam' : 'menit'} lagi',
      );
    }

    return null;
  }

  String _compactNumber(double value) {
    return value == value.roundToDouble()
        ? value.toInt().toString()
        : value.toString();
  }

  _TimeInfo _extractTime(String text) {
    final period = _periodIn(text);

    final half = RegExp(r'\bsetengah\s+(\d{1,2})\b').firstMatch(text);
    if (half != null) {
      final hour = int.parse(half.group(1)!);
      final adjusted = hour == 0 ? 0 : hour - 1;
      final h = _applyPeriod(adjusted, period);
      return _TimeInfo(TimeOfDayParts(h, 30), _formatTime(h, 30), period);
    }

    final quarter = RegExp(r'\bjam\s+(\d{1,2})\s+kurang\s+seperempat\b').firstMatch(text);
    if (quarter != null) {
      var hour = int.parse(quarter.group(1)!);
      hour = hour == 0 ? 0 : hour - 1;
      hour = _applyPeriod(hour, period);
      return _TimeInfo(TimeOfDayParts(hour, 45), _formatTime(hour, 45), period);
    }

    const numberWords = <String, int>{
      'nol': 0, 'satu': 1, 'dua': 2, 'tiga': 3, 'empat': 4,
      'lima': 5, 'enam': 6, 'tujuh': 7, 'delapan': 8, 'sembilan': 9,
      'sepuluh': 10, 'sebelas': 11,
    };
    final spokenNumber = RegExp(r'\b(?:jam|pukul)\s+(nol|satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas)\s*(pagi|siang|sore|malam|am|pm)?\b').firstMatch(text);
    if (spokenNumber != null) {
      final hour = _applyPeriod(numberWords[spokenNumber.group(1)!]!, spokenNumber.group(2) ?? period);
      return _TimeInfo(TimeOfDayParts(hour, 0), _formatTime(hour, 0), spokenNumber.group(2) ?? period);
    }

    final standard = RegExp(r'\b(?:jam|pukul)\s*(\d{1,2})(?:\s*[:.]\s*(\d{2}))?\s*(pagi|siang|sore|malam|am|pm)?\b').firstMatch(text);
    final numeric = standard ?? RegExp(r'\b(\d{1,2})\s*[:.]\s*(\d{2})\s*(pagi|siang|sore|malam|am|pm)?\b').firstMatch(text);
    if (numeric != null) {
      final hour = int.parse(numeric.group(1)!);
      final minute = int.tryParse(numeric.group(2) ?? '0') ?? 0;
      final explicitPeriod = numeric.group(3);
      final resolved = _applyPeriod(hour, explicitPeriod ?? period);
      if (resolved >= 0 && resolved <= 23 && minute <= 59) {
        return _TimeInfo(TimeOfDayParts(resolved, minute), _formatTime(resolved, minute), explicitPeriod ?? period);
      }
    }

    final spoken = RegExp(r'\bjam\s+(\d{1,2})\s*(pagi|siang|sore|malam|am|pm)\b').firstMatch(text);
    if (spoken != null) {
      final hour = _applyPeriod(int.parse(spoken.group(1)!), spoken.group(2));
      return _TimeInfo(TimeOfDayParts(hour, 0), _formatTime(hour, 0), spoken.group(2));
    }

    return _TimeInfo(null, null, period);
  }

  TimeOfDayParts _periodStart(String period) => switch (period) {
        'pagi' => const TimeOfDayParts(5, 0),
        'siang' => const TimeOfDayParts(11, 0),
        'sore' => const TimeOfDayParts(15, 0),
        'malam' => const TimeOfDayParts(18, 30),
        _ => const TimeOfDayParts(0, 0),
      };

  TimeOfDayParts _periodEnd(String period) => switch (period) {
        'pagi' => const TimeOfDayParts(10, 0),
        'siang' => const TimeOfDayParts(14, 0),
        'sore' => const TimeOfDayParts(18, 0),
        'malam' => const TimeOfDayParts(23, 30),
        _ => const TimeOfDayParts(0, 0),
      };

  String? _periodIn(String text) {
    for (final value in ['pagi', 'siang', 'sore', 'malam', 'malem']) {
      if (RegExp(r'\b' + value + r'\b').hasMatch(text)) return value == 'malem' ? 'malam' : value;
    }
    return null;
  }

  int _applyPeriod(int hour, String? period) {
    if (period == 'malam') {
      if (hour == 12) return 0;
      if (hour < 12) return hour + 12;
    }
    if (period == 'siang' || period == 'sore' || period == 'pm') {
      if (hour < 12) return hour + 12;
    }
    return hour;
  }

  String _formatTime(int hour, int minute) =>
      '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

  DateTime? _safeDate(int year, int month, int day) {
    try {
      final value = DateTime(year, month, day);
      if (value.year != year || value.month != month || value.day != day) return null;
      return value;
    } catch (_) {
      return null;
    }
  }

  String _extractMemoryContent(String text) {
    var value = text;
    value = value.replaceFirst(RegExp(r'^(tolong\s+)?(ingat bahwa|ingat kalau|simpan sebagai ingatan|simpan ini|catat ini|ingat ini|tolong ingat)\s*'), '');
    value = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    return value;
  }

  String _extractMemoryQuery(String text) {
    var value = text;
    value = value.replaceFirst(RegExp(r'^(tolong\s+)?(cari ingatan|ingatanku tentang|apa yang aku ingat|apa yang kamu ingat|apa yang aku simpan)\s*'), '');
    value = value.replaceAll(RegExp(r'\b(ingatan|memory|favoritku)\b'), ' ');
    value = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    return value;
  }

  String _extractTitle(String text) {
    var value = text;
    value = value.replaceAll(RegExp(r'\b(tolong|please|dong|ya|deh|yaudah|nanti|ntar)\b'), ' ');
    value = value.replaceAll(RegExp(r'\bsetengah\s+jam\s+lagi\b'), ' ');
    value = value.replaceAll(RegExp(r'\bseperempat\s+jam\s+lagi\b'), ' ');
    value = value.replaceAll(RegExp(r'\bsejam\s+lagi\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(?:\d+(?:[.,]\d+)?|satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas)\s*(?:menit|jam)\s+lagi\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(ingatkan|ingetin|ingatkan aku|ingetin aku|titipkan|titip|jangan lupa|remind me|remind|ingat aku)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(saya|aku|gue|gua|gw|kamu|aku|me)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(hari ini|besok|lusa|sehari lagi|seminggu lagi|sebulan lagi|setahun lagi|minggu depan)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(bulan depan|tahun depan)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(?:\d+|satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas|dua belas|tiga belas|empat belas|lima belas|enam belas|tujuh belas|delapan belas|sembilan belas|dua puluh|dua puluh satu|dua puluh dua|dua puluh tiga|dua puluh empat|dua puluh lima|dua puluh enam|dua puluh tujuh|dua puluh delapan|dua puluh sembilan|tiga puluh|tiga puluh satu)\s+(hari|minggu|bulan|tahun)\s+lagi\b'), ' ');
    value = value.replaceAll(RegExp(r"\b(setiap|senin|selasa|rabu|kamis|jumat|jum'at|sabtu|minggu)\b"), ' ');
    value = value.replaceAll(RegExp(r'\b(\d{1,2})[\/-](\d{1,2})(?:[\/-](\d{2,4}))?\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(\d{1,2})\s+(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember)(?:\s+\d{4})?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bjam\s+(?:nol|satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas)\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bpukul\s+(?:nol|satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas)\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bjam\s+\d{1,2}(?:\s*[:.]\s*\d{2})?\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bpukul\s+\d{1,2}(?:\s*[:.]\s*\d{2})?\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\b\d{1,2}\s*[:.]\s*\d{2}\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bsetengah\s+\d{1,2}\b'), ' ');
    value = value.replaceAll(RegExp(r'\bjam\s+\d{1,2}\s+kurang\s+seperempat\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(pagi|siang|sore|malam|malem)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(pada|untuk|di|tanggal|pukul)\b'), ' ');
    value = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (value.isEmpty) return '';
    return value[0].toUpperCase() + value.substring(1);
  }
}

class TimeOfDayParts {
  final int hour;
  final int minute;
  const TimeOfDayParts(this.hour, this.minute);
}

class _RelativeDurationInfo {
  final Duration duration;
  final String label;
  const _RelativeDurationInfo(this.duration, this.label);
}

class _TimeInfo {
  final TimeOfDayParts? time;
  final String? label;
  final String? period;
  const _TimeInfo(this.time, this.label, this.period);
}

class _WeekdayInfo {
  final int weekday;
  final String label;
  const _WeekdayInfo(this.weekday, this.label);
}

class _DateInfo {
  final DateTime? date;
  final String? label;
  const _DateInfo(this.date, this.label);
}
