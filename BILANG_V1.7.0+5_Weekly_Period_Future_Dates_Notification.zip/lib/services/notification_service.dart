import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../models/reminder.dart';
import '../models/user_settings.dart';
import '../repositories/reminder_repository.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  bool? _notificationsGranted;
  bool? _exactAlarmGranted;
  bool _exactPermissionPrompted = false;
  bool _batteryOptimizationPrompted = false;

  static const String _channelId = 'bilang_reminders_v4';

  Future<void> initialize() async {
    if (_initialized) return;

    tz.initializeTimeZones();
    try {
      final timezone = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(timezone.identifier));
    } catch (_) {}

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings: settings);

    final androidPlugin = _androidPlugin;
    await androidPlugin?.createNotificationChannel(
      const AndroidNotificationChannel(
        _channelId,
        'Titipan BILANG',
        description: 'Pengingat untuk Titipan yang kamu simpan di BILANG.',
        importance: Importance.max,
        audioAttributesUsage: AudioAttributesUsage.alarm,
      ),
    );

    _initialized = true;
  }

  AndroidFlutterLocalNotificationsPlugin? get _androidPlugin =>
      _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  Future<bool> requestNotificationPermission() async {
    await initialize();
    final granted =
        await _androidPlugin?.requestNotificationsPermission() ?? true;
    _notificationsGranted = granted;
    return granted;
  }

  Future<bool> notificationsEnabledOnDevice() async {
    await initialize();
    final enabled = await _androidPlugin?.areNotificationsEnabled() ?? true;
    _notificationsGranted = enabled;
    return enabled;
  }

  Future<bool> exactAlarmsEnabledOnDevice() async {
    await initialize();
    final enabled = await _androidPlugin?.canScheduleExactNotifications() ?? true;
    _exactAlarmGranted = enabled;
    return enabled;
  }

  Future<bool> requestExactAlarmPermission() async {
    await initialize();
    if (_exactPermissionPrompted) {
      return exactAlarmsEnabledOnDevice();
    }
    _exactPermissionPrompted = true;
    final granted = await _androidPlugin?.requestExactAlarmsPermission();
    _exactAlarmGranted = granted ?? await exactAlarmsEnabledOnDevice();
    return _exactAlarmGranted ?? false;
  }

  /// BILANG prefers exact alarms for user-requested reminders. If the user
  /// declines the Android special access, we gracefully fall back to inexact
  /// scheduling rather than silently dropping the reminder.
  Future<bool> ensureAndroidPermissions() async {
    final notifications =
        _notificationsGranted ?? await requestNotificationPermission();
    if (!notifications) return false;

    // Some Android OEMs, especially Vivo/Funtouch OS, can aggressively stop
    // background work. Give the user a one-time system prompt to exempt BILANG
    // from battery optimization. If the user declines, scheduling continues
    // normally; this is only a reliability aid, never a hard requirement.
    if (!_batteryOptimizationPrompted) {
      _batteryOptimizationPrompted = true;
      try {
        final status = await Permission.ignoreBatteryOptimizations.status;
        if (!status.isGranted) {
          await Permission.ignoreBatteryOptimizations.request();
        }
      } catch (_) {}
    }
    return true;
  }

  Future<void> scheduleReminder(
    Reminder reminder,
    UserSettings settings,
  ) async {
    await initialize();
    if (!settings.notificationsEnabled) return;
    if (reminder.status != ReminderStatus.active &&
        reminder.status != ReminderStatus.snoozed) {
      return;
    }

    final permissionsGranted = await ensureAndroidPermissions();
    if (!permissionsGranted) return;
    if (!await notificationsEnabledOnDevice()) return;

    var exact = await exactAlarmsEnabledOnDevice();
    if (!exact) {
      exact = await requestExactAlarmPermission();
      await Future<void>.delayed(const Duration(milliseconds: 250));
      exact = await exactAlarmsEnabledOnDevice();
    }

    // One logical Titipan can own several Android alarms (for example,
    // "setiap Senin pagi" = 05:00, 06:00, ... 10:00). Keep those alarms
    // hidden behind the same Reminder/card in the app.
    await _cancelAllIdsForReminder(reminder.id);

    final schedulingReminder = _normalizeRecurringDate(reminder);
    final times = _recurrenceTimes(schedulingReminder);
    final scheduledIds = <int>[];
    for (var index = 0; index < times.length; index++) {
      final scheduled = times[index];
      if (scheduled.isBefore(DateTime.now())) continue;
      if (_isQuietTime(scheduled, settings) &&
          !(reminder.priority == ReminderPriority.important &&
              settings.importantReminderDuringQuietHours)) {
        continue;
      }

      final id = _notificationId(reminder.id, index);
      final body = _body(schedulingReminder, settings);
      final androidDetails = AndroidNotificationDetails(
        _channelId,
        'Titipan BILANG',
        channelDescription: 'Pengingat untuk Titipan yang kamu simpan di BILANG.',
        importance: Importance.max,
        priority: Priority.max,
        category: AndroidNotificationCategory.reminder,
        audioAttributesUsage: AudioAttributesUsage.alarm,
        playSound: settings.soundEnabled,
        enableVibration: settings.vibrationEnabled,
        visibility: settings.notificationPreview
            ? NotificationVisibility.public
            : NotificationVisibility.private,
      );

      final match = switch (schedulingReminder.recurrence) {
        ReminderRecurrence.none => null,
        ReminderRecurrence.daily => DateTimeComponents.time,
        ReminderRecurrence.weekly => DateTimeComponents.dayOfWeekAndTime,
        ReminderRecurrence.monthly => DateTimeComponents.dayOfMonthAndTime,
        ReminderRecurrence.custom => null,
      };

      final scheduledDate = tz.TZDateTime.from(scheduled, tz.local);
      final details = NotificationDetails(android: androidDetails);

      Future<void> scheduleWith(AndroidScheduleMode mode) => _plugin.zonedSchedule(
            id: id,
            title: 'BILANG',
            body: body,
            scheduledDate: scheduledDate,
            notificationDetails: details,
            androidScheduleMode: mode,
            matchDateTimeComponents: match,
            payload: schedulingReminder.id,
          );

      try {
        await scheduleWith(
          exact
              ? AndroidScheduleMode.exactAllowWhileIdle
              : AndroidScheduleMode.inexactAllowWhileIdle,
        );
      } catch (_) {
        await _plugin.cancel(id: id);
        await scheduleWith(AndroidScheduleMode.inexactAllowWhileIdle);
      }
      scheduledIds.add(id);
    }

    // Verify every alarm we expected. If an OEM rejected an exact alarm,
    // retry the missing ones as inexact instead of leaving a silent failure.
    if (scheduledIds.isNotEmpty) {
      final pending = await _plugin.pendingNotificationRequests();
      final pendingIds = pending.map((request) => request.id).toSet();
      for (var index = 0; index < times.length; index++) {
        final scheduled = times[index];
        if (scheduled.isBefore(DateTime.now()) ||
            (_isQuietTime(scheduled, settings) &&
                !(reminder.priority == ReminderPriority.important &&
                    settings.importantReminderDuringQuietHours))) {
          continue;
        }
        final id = _notificationId(reminder.id, index);
        if (!pendingIds.contains(id)) {
          final androidDetails = AndroidNotificationDetails(
            _channelId,
            'Titipan BILANG',
            channelDescription: 'Pengingat untuk Titipan yang kamu simpan di BILANG.',
            importance: Importance.max,
            priority: Priority.max,
            category: AndroidNotificationCategory.reminder,
            audioAttributesUsage: AudioAttributesUsage.alarm,
            playSound: settings.soundEnabled,
            enableVibration: settings.vibrationEnabled,
            visibility: settings.notificationPreview
                ? NotificationVisibility.public
                : NotificationVisibility.private,
          );
          final match = switch (schedulingReminder.recurrence) {
            ReminderRecurrence.none => null,
            ReminderRecurrence.daily => DateTimeComponents.time,
            ReminderRecurrence.weekly => DateTimeComponents.dayOfWeekAndTime,
            ReminderRecurrence.monthly => DateTimeComponents.dayOfMonthAndTime,
            ReminderRecurrence.custom => null,
          };
          await _plugin.zonedSchedule(
            id: id,
            title: 'BILANG',
            body: _body(reminder, settings),
            scheduledDate: tz.TZDateTime.from(scheduled, tz.local),
            notificationDetails: NotificationDetails(android: androidDetails),
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
            matchDateTimeComponents: match,
            payload: schedulingReminder.id,
          );
        }
      }
    }
  }

  Reminder _normalizeRecurringDate(Reminder reminder) {
    if (reminder.recurrence == ReminderRecurrence.none) return reminder;
    final now = DateTime.now();
    var next = reminder.scheduledAt;
    if (reminder.recurrence == ReminderRecurrence.daily) {
      while (!next.isAfter(now)) {
        next = next.add(const Duration(days: 1));
      }
    } else if (reminder.recurrence == ReminderRecurrence.weekly) {
      while (!next.isAfter(now)) {
        next = next.add(const Duration(days: 7));
      }
    } else if (reminder.recurrence == ReminderRecurrence.monthly) {
      while (!next.isAfter(now)) {
        final candidate = DateTime(next.year, next.month + 1, next.day, next.hour, next.minute);
        next = candidate;
      }
    }
    if (next == reminder.scheduledAt) return reminder;
    return reminder.copyWith(scheduledAt: next);
  }

  List<DateTime> _recurrenceTimes(Reminder reminder) {
    if (reminder.recurrence != ReminderRecurrence.weekly ||
        reminder.recurrenceIntervalMinutes == null ||
        reminder.recurrenceEndMinute == null) {
      return [reminder.scheduledAt];
    }

    final interval = reminder.recurrenceIntervalMinutes!;
    if (interval <= 0) return [reminder.scheduledAt];
    final startMinute = reminder.scheduledAt.hour * 60 + reminder.scheduledAt.minute;
    final endMinute = reminder.recurrenceEndMinute!;
    if (endMinute < startMinute) return [reminder.scheduledAt];

    final result = <DateTime>[];
    for (var minute = startMinute; minute <= endMinute; minute += interval) {
      result.add(DateTime(
        reminder.scheduledAt.year,
        reminder.scheduledAt.month,
        reminder.scheduledAt.day,
        minute ~/ 60,
        minute % 60,
      ));
    }
    return result;
  }

  Future<void> cancelReminder(String reminderId) async {
    await initialize();
    await _cancelAllIdsForReminder(reminderId);
  }

  Future<void> _cancelAllIdsForReminder(String reminderId) async {
    // Legacy V1.7.0+2 used hash(id) for its single notification. Cancel it
    // too, so upgrading does not leave an old duplicate alarm behind.
    await _plugin.cancel(id: reminderId.hashCode & 0x7fffffff);
    for (var index = 0; index < 24; index++) {
      await _plugin.cancel(id: _notificationId(reminderId, index));
    }
  }

  Future<void> rescheduleAll(
    ReminderRepository repository,
    UserSettings settings,
  ) async {
    await initialize();
    if (!settings.notificationsEnabled) return;
    final reminders = await repository.getActiveReminders();
    if (reminders.isEmpty) return;

    if (!await ensureAndroidPermissions()) return;
    for (final reminder in reminders) {
      await scheduleReminder(reminder, settings);
    }
  }

  String _body(Reminder reminder, UserSettings settings) {
    if (!settings.notificationPreview) return 'Kamu punya satu titipan.';

    return switch (settings.notificationStyle) {
      NotificationStyle.natural =>
        'Hei, kamu tadi nitip sesuatu. 👀\n${reminder.title}',
      NotificationStyle.short =>
        '${reminder.title} — ${_time(reminder.scheduledAt)}',
      NotificationStyle.casual => 'Eh, jangan lupa ${reminder.title} 👀',
    };
  }

  String _time(DateTime value) =>
      '${value.hour.toString().padLeft(2, '0')}:${value.minute.toString().padLeft(2, '0')}';

  bool _isQuietTime(DateTime value, UserSettings settings) {
    if (!settings.quietHoursEnabled) return false;
    final minute = value.hour * 60 + value.minute;
    final start = _parseMinute(settings.quietStart);
    final end = _parseMinute(settings.quietEnd);
    if (start == null || end == null || start == end) return false;
    if (start < end) return minute >= start && minute < end;
    return minute >= start || minute < end;
  }

  int? _parseMinute(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null || hour > 23 || minute > 59) return null;
    return hour * 60 + minute;
  }

  int _notificationId(String value, [int occurrence = 0]) {
    // Stable across app restarts. String.hashCode is not suitable as a
    // persistent Android notification id because its value is not guaranteed
    // to remain stable between Dart VM processes.
    var hash = 0x811c9dc5;
    final input = '$value#$occurrence';
    for (final codeUnit in input.codeUnits) {
      hash ^= codeUnit;
      hash = (hash * 0x01000193) & 0x7fffffff;
    }
    return hash == 0 ? 1 : hash;
  }
}
