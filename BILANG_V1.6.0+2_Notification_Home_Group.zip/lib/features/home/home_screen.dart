import 'package:flutter/material.dart';
import '../../models/user_settings.dart';
import '../../models/reminder.dart';
import '../../repositories/reminder_repository.dart';
import '../../repositories/shared_preferences_memory_repository.dart';
import '../../models/memory.dart';
import '../../services/memory_service.dart';
import '../../services/bilang_engine.dart';
import '../../services/reminder_service.dart';
import '../../services/speech_service.dart';
import '../../services/permission_service.dart';
import '../../services/notification_service.dart';
import '../aku/aku_screen.dart';
import '../ingatan/ingatan_screen.dart';
import '../onboarding/character_data.dart';
import '../onboarding/character_view.dart';
import '../titipan/titipan_screen.dart';

class HomeScreen extends StatefulWidget {
  final UserSettings settings;
  final Future<void> Function(UserSettings) onSettingsChanged;
  final ReminderRepository reminderRepository;

  const HomeScreen({
    super.key,
    required this.settings,
    required this.onSettingsChanged,
    required this.reminderRepository,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final input = TextEditingController();
  final memoryInput = TextEditingController();
  final BilangEngine engine = BilangEngine();
  final SpeechService speechService = SpeechService();
  final SpeechService memorySpeechService = SpeechService();
  final PermissionService permissionService = PermissionService();
  final SharedPreferencesMemoryRepository memoryRepository =
      SharedPreferencesMemoryRepository();
  late final MemoryService memoryService = MemoryService(memoryRepository);

  late final ReminderService reminderService = ReminderService(
    widget.reminderRepository,
    settings: widget.settings,
    notificationService: NotificationService(),
  );
  List<Reminder> todayReminders = [];
  bool processingInput = false;
  bool listening = false;
  bool memoryListening = false;
  String liveSpeechText = '';
  String memorySpeechText = '';
  MemorySource _inputSource = MemorySource.text;

  @override
  void initState() {
    super.initState();
    _loadToday();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && widget.settings.notificationsEnabled) {
        NotificationService().requestNotificationPermission();
      }
    });
  }

  Future<void> _loadToday() async {
    final all = await widget.reminderRepository.getActiveReminders();
    final now = DateTime.now();
    if (!mounted) return;
    setState(() {
      todayReminders = all
          .where((r) => _sameDay(r.scheduledAt, now))
          .toList()
        ..sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));
    });
  }

  bool _sameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  List<_HomeReminderGroup> get _todayGroups {
    final grouped = <String, _HomeReminderGroup>{};
    final standalone = <Reminder>[];

    for (final reminder in todayReminders) {
      final parent = reminder.parentReminderId;
      if (parent == null || parent.isEmpty) {
        standalone.add(reminder);
        continue;
      }
      final group = grouped.putIfAbsent(
        'parent:$parent',
        () => _HomeReminderGroup(items: <Reminder>[]),
      );
      group.items.add(reminder);
    }

    final result = <_HomeReminderGroup>[...grouped.values];
    result.addAll(_groupLegacyHourlySeries(standalone));
    result.sort((a, b) => a.start.compareTo(b.start));
    return result;
  }

  List<_HomeReminderGroup> _groupLegacyHourlySeries(List<Reminder> input) {
    final sorted = [...input]..sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));
    final groups = <_HomeReminderGroup>[];
    var current = <Reminder>[];

    void flush() {
      if (current.isNotEmpty) {
        groups.add(_HomeReminderGroup(items: [...current]));
        current = [];
      }
    }

    for (final reminder in sorted) {
      if (current.isEmpty) {
        current.add(reminder);
        continue;
      }
      final previous = current.last;
      final hourly =
          reminder.scheduledAt.difference(previous.scheduledAt).inMinutes == 60;
      final sameTitle = reminder.title.trim().toLowerCase() ==
          previous.title.trim().toLowerCase();
      if (hourly && sameTitle && _sameDay(reminder.scheduledAt, previous.scheduledAt)) {
        current.add(reminder);
      } else {
        flush();
        current.add(reminder);
      }
    }
    flush();
    return groups;
  }

  String _homeGroupTime(_HomeReminderGroup group) {
    final start = group.start;
    final end = group.end;
    final date = _sameDay(start, DateTime.now())
        ? 'Hari ini'
        : _naturalDateLabel(start);
    final startTime =
        '${start.hour.toString().padLeft(2, '0')}:${start.minute.toString().padLeft(2, '0')}';
    if (group.items.length == 1 || start == end) return '$date • $startTime';
    final endTime =
        '${end.hour.toString().padLeft(2, '0')}:${end.minute.toString().padLeft(2, '0')}';
    return '$date • $startTime - $endTime';
  }

  @override
  void dispose() {
    speechService.cancel();
    input.dispose();
    memoryInput.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _home(context),
      TitipanScreen(repository: widget.reminderRepository, settings: widget.settings),
      IngatanScreen(repository: memoryRepository),
      AkuScreen(
        settings: widget.settings,
        onSettingsChanged: widget.onSettingsChanged,
      ),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.schedule_outlined),
            selectedIcon: Icon(Icons.schedule),
            label: 'Titipan',
          ),
          NavigationDestination(
            icon: Icon(Icons.psychology_alt_outlined),
            selectedIcon: Icon(Icons.psychology_alt),
            label: 'Ingatan',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Aku',
          ),
        ],
      ),
    );
  }

  Widget _home(BuildContext context) {
    final hour = DateTime.now().hour;
    final greeting = hour < 11
        ? 'Selamat pagi 👋 Ada yang mau kamu titipkan hari ini?'
        : hour < 17
            ? 'Lagi sibuk? 👀 Bilang aja. Aku ingat.'
            : hour < 22
                ? 'Sebelum lanjut... Ada sesuatu yang perlu kamu titipkan?'
                : 'Sebelum tidur... 🌙 Ada yang perlu aku ingat untuk besok?';

    final info = characterInfos.firstWhere(
      (character) => character.type == widget.settings.selectedCharacter,
    );

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'BILANG',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => setState(() => index = 3),
                icon: const Icon(Icons.tune_rounded),
                tooltip: 'Pengaturan',
              ),
            ],
          ),
          const SizedBox(height: 18),
          Center(
            child: Column(
              children: [
                CharacterView(character: info.type, size: 170),
                const SizedBox(height: 10),
                Text(
                  greeting,
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Center(
            child: Container(
              width: 92,
              height: 92,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: listening
                    ? Theme.of(context).colorScheme.primary.withValues(alpha: .82)
                    : Theme.of(context).colorScheme.primary,
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(context)
                        .colorScheme
                        .primary
                        .withValues(alpha: listening ? .38 : .25),
                    blurRadius: listening ? 26 : 20,
                    spreadRadius: listening ? 6 : 3,
                  ),
                ],
              ),
              child: IconButton(
                onPressed: processingInput ? null : (listening ? _stopVoice : _startVoice),
                icon: Icon(
                  listening ? Icons.stop_rounded : Icons.mic_rounded,
                  size: 40,
                  color: Colors.white,
                ),
                tooltip: listening ? 'Selesai mendengarkan' : 'Bilang',
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              listening ? 'Aku dengarkan...' : 'Tekan dan bilang aja',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
          if (listening && liveSpeechText.isNotEmpty) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Theme.of(context).dividerColor),
              ),
              child: Text(
                liveSpeechText,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ],
          const SizedBox(height: 16),
          TextField(
            controller: input,
            enabled: !processingInput,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _processTextInput(),
            decoration: InputDecoration(
              hintText: 'atau ketik aja...',
              suffixIcon: processingInput
                  ? const Padding(
                      padding: EdgeInsets.all(14),
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    )
                  : IconButton(
                      onPressed: _processTextInput,
                      icon: const Icon(Icons.arrow_upward_rounded),
                      tooltip: 'Kirim',
                    ),
            ),
          ),
          const SizedBox(height: 28),
          Row(
            children: [
              Text(
                'Tambahkan ke Ingatan',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'Tulis atau bilang sesuatu yang ingin BILANG ingat untukmu.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 10),
          TextField(
            controller: memoryInput,
            enabled: !processingInput && !memoryListening,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _processMemoryInput(memoryInput.text.trim()),
            decoration: InputDecoration(
              hintText: memoryListening ? 'Aku dengarkan...' : 'Contoh: aku suka kopi susu',
              prefixIcon: const Icon(Icons.psychology_alt_outlined),
              suffixIcon: memoryListening
                  ? IconButton(
                      onPressed: _stopMemoryVoice,
                      icon: const Icon(Icons.stop_circle_outlined),
                      tooltip: 'Selesai',
                    )
                  : Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: processingInput ? null : _startMemoryVoice,
                          icon: const Icon(Icons.mic_none_rounded),
                          tooltip: 'Bilang untuk Ingatan',
                        ),
                        IconButton(
                          onPressed: processingInput ? null : () => _processMemoryInput(memoryInput.text.trim()),
                          icon: const Icon(Icons.arrow_upward_rounded),
                          tooltip: 'Simpan ke Ingatan',
                        ),
                      ],
                    ),
            ),
          ),
          if (memoryListening && memorySpeechText.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(memorySpeechText, style: Theme.of(context).textTheme.bodySmall),
          ],
          const SizedBox(height: 30),
          Row(
            children: [
              Text(
                'Titipan hari ini',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
              const Spacer(),
              TextButton(
                onPressed: () => setState(() => index = 1),
                child: const Text('Lihat semua'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (_todayGroups.isEmpty)
            _preview(context, 'Belum ada titipan hari ini', 'Kalau ada yang takut kamu lupa, bilang aja.')
          else
            ..._todayGroups.take(3).map((group) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: _preview(
                    context,
                    group.title,
                    _homeGroupTime(group),
                    suffix: group.items.length > 1 ? 'Diingatkan setiap jam' : null,
                  ),
                )),
        ],
      ),
    );
  }

  Future<void> _startVoice() async {
    _inputSource = MemorySource.voice;
    if (listening || processingInput) return;

    final microphoneGranted = await permissionService.requestMicrophone();
    if (!microphoneGranted || !mounted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Aku belum mendapat izin mikrofon. 😌')),
        );
      }
      return;
    }

    final available = await speechService.initialize(
      onError: (error) {
        if (!mounted) return;
        setState(() {
          listening = false;
          liveSpeechText = '';
        });
        final message = error.errorMsg.toLowerCase().contains('permission')
            ? 'Aku belum mendapat izin mikrofon. 😌'
            : 'Aku belum bisa mendengar suara kamu. 👀 Coba lagi.';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      },
    );

    if (!available || !mounted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Layanan pengenalan suara belum tersedia di perangkat ini. 👀'),
          ),
        );
      }
      return;
    }

    setState(() {
      listening = true;
      liveSpeechText = '';
      input.clear();
    });

    try {
      await speechService.listen(
        onResult: (result) {
          if (!mounted || !listening) return;
          final words = result.recognizedWords.trim();
          setState(() {
            liveSpeechText = words;
            input.text = words;
          });
          if (result.finalResult) {
            _finishVoice(words);
          }
        },
        onSoundLevelChange: (_) {},
      );
    } catch (_) {
      if (!mounted) return;
      setState(() {
        listening = false;
        liveSpeechText = '';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aku belum bisa mendengar suara kamu. 👀 Coba lagi.')),
      );
    }
  }

  Future<void> _stopVoice() async {
    if (!listening) return;
    await speechService.stop();
    if (!mounted) return;
    final text = input.text.trim();
    setState(() {
      listening = false;
      liveSpeechText = '';
    });
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aku belum dengar apa-apa. 👀 Coba bilang sekali lagi?')),
      );
      return;
    }
    await _processInputText(text);
  }

  Future<void> _finishVoice(String words) async {
    if (!listening) return;
    await speechService.stop();
    if (!mounted) return;
    setState(() {
      listening = false;
      liveSpeechText = '';
    });
    if (words.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aku belum dengar apa-apa. 👀 Coba bilang sekali lagi?')),
      );
      return;
    }
    await _processInputText(words.trim());
  }

  Future<void> _processTextInput() async {
    _inputSource = MemorySource.text;
    await _processInputText(input.text.trim());
  }

  Future<void> _processInputText(String text) async {
    if (text.isEmpty || processingInput) return;

    setState(() => processingInput = true);
    try {
      final result = await engine.processInput(text);
      if (!mounted) return;

      if (result.requiresConfirmation && result.entities['scheduledAt'] is DateTime) {
        final saved = await _showConfirmation(result);
        if (saved && mounted) {
          input.clear();
          await _loadToday();
        }
        return;
      }

      if (result.intent == BilangIntent.createMemory &&
          result.entities['content'] is String) {
        final saved = await _showMemoryConfirmation(
          result.entities['content'] as String,
          source: _inputSource,
        );
        if (saved && mounted) input.clear();
        return;
      }

      if (result.intent == BilangIntent.readMemory) {
        final query = result.entities['query'] as String? ?? '';
        await _showMemorySearchResult(query);
        return;
      }

      if (result.intent == BilangIntent.deleteMemory ||
          result.intent == BilangIntent.updateMemory) {
        final query = result.entities['query'] as String? ?? '';
        await _handleMemoryMutation(result.intent, query);
        return;
      }

      if (result.requiresClarification) {
        final answer = await _showClarification(result.response ?? 'Boleh diperjelas?');
        if (!mounted || answer == null || answer.trim().isEmpty) return;

        final followUp = _buildFollowUp(text, answer.trim(), result.response ?? '');
        input.text = followUp;

        // showDialog completes when Navigator.pop starts closing the route.
        // Wait until the route's reverse animation has fully settled before
        // rebuilding HomeScreen and processing the follow-up.
        await Future<void>.delayed(const Duration(milliseconds: 350));
        if (!mounted) return;

        final followUpResult = await engine.processInput(followUp);
        if (!mounted) return;

        if (followUpResult.requiresConfirmation &&
            followUpResult.entities['scheduledAt'] is DateTime) {
          final saved = await _showConfirmation(followUpResult);
          if (saved && mounted) {
            input.clear();
            await _loadToday();
          }
          return;
        }

        if (followUpResult.response != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(followUpResult.response!)),
          );
        }
        return;
      }

      if (result.response != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result.response!)),
        );
      }
    } finally {
      if (mounted) setState(() => processingInput = false);
    }
  }

  String _buildFollowUp(String original, String answer, String question) {
    final asksTime = question.toLowerCase().contains('jam berapa');
    if (asksTime && RegExp(r'^\d{1,2}([:.]\d{1,2})?$').hasMatch(answer)) {
      return '$original jam $answer';
    }
    return '$original $answer';
  }

  Future<void> _startMemoryVoice() async {
    if (memoryListening || processingInput || listening) return;
    final granted = await permissionService.requestMicrophone();
    if (!granted || !mounted) return;
    final available = await memorySpeechService.initialize(
      onError: (error) {
        if (!mounted) return;
        setState(() {
          memoryListening = false;
          memorySpeechText = '';
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Aku belum bisa mendengar suara kamu. 👀 Coba lagi.')),
        );
      },
    );
    if (!available || !mounted) return;
    setState(() {
      memoryListening = true;
      memorySpeechText = '';
      memoryInput.clear();
    });
    try {
      await memorySpeechService.listen(
        onResult: (result) {
          if (!mounted || !memoryListening) return;
          final words = result.recognizedWords.trim();
          setState(() {
            memorySpeechText = words;
            memoryInput.text = words;
          });
          if (result.finalResult) _finishMemoryVoice(words);
        },
        onSoundLevelChange: (_) {},
      );
    } catch (_) {
      if (!mounted) return;
      setState(() {
        memoryListening = false;
        memorySpeechText = '';
      });
    }
  }

  Future<void> _stopMemoryVoice() async {
    if (!memoryListening) return;
    await memorySpeechService.stop();
    if (!mounted) return;
    final text = memoryInput.text.trim();
    setState(() {
      memoryListening = false;
      memorySpeechText = '';
    });
    if (text.isNotEmpty) await _processMemoryInput(text, source: MemorySource.voice);
  }

  Future<void> _finishMemoryVoice(String words) async {
    if (!memoryListening) return;
    await memorySpeechService.stop();
    if (!mounted) return;
    setState(() {
      memoryListening = false;
      memorySpeechText = '';
    });
    if (words.trim().isNotEmpty) {
      await _processMemoryInput(words.trim(), source: MemorySource.voice);
    }
  }

  Future<void> _processMemoryInput(
    String text, {
    MemorySource source = MemorySource.text,
  }) async {
    if (text.isEmpty || processingInput || memoryListening) return;
    setState(() => processingInput = true);
    try {
      final saved = await _showMemoryConfirmation(text, source: source);
      if (saved && mounted) memoryInput.clear();
    } finally {
      if (mounted) setState(() => processingInput = false);
    }
  }

  Future<bool> _showMemoryConfirmation(
    String content, {
    required MemorySource source,
  }) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Simpan ke Ingatan?'),
        content: Text(content),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );

    await Future<void>.delayed(const Duration(milliseconds: 350));
    if (confirmed != true || !mounted) return false;

    final result = await memoryService.save(content: content, source: source);
    if (!mounted) return false;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result.message ?? 'Ingatan diproses.')),
    );
    return result.saved;
  }

  Future<void> _showMemorySearchResult(String query) async {
    final memories = await memoryService.search(query);
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Ingatan'),
        content: memories.isEmpty
            ? Text(query.isEmpty
                ? 'Belum ada ingatan yang cocok.'
                : 'Aku belum menemukan ingatan tentang "$query".')
            : SizedBox(
                width: double.maxFinite,
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: memories.take(5).length,
                  separatorBuilder: (_, __) => const Divider(height: 18),
                  itemBuilder: (_, index) {
                    final memory = memories[index];
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(memory.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                        const SizedBox(height: 4),
                        Text(memory.content),
                      ],
                    );
                  },
                ),
              ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Tutup')),
        ],
      ),
    );
  }

  Future<void> _handleMemoryMutation(BilangIntent intent, String query) async {
    final matches = await memoryService.search(query);
    if (!mounted) return;
    if (matches.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aku belum menemukan ingatan yang cocok.')),
      );
      return;
    }
    final memory = matches.first;
    if (matches.length > 1) {
      final selected = await showDialog<Memory>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Pilih ingatan'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: matches.length > 5 ? 5 : matches.length,
              itemBuilder: (_, index) => ListTile(
                title: Text(matches[index].title),
                subtitle: Text(matches[index].content),
                onTap: () => Navigator.pop(dialogContext, matches[index]),
              ),
            ),
          ),
        ),
      );
      if (!mounted || selected == null) return;
      await _mutateMemory(intent, selected);
      return;
    }
    await _mutateMemory(intent, memory);
  }

  Future<void> _mutateMemory(BilangIntent intent, Memory memory) async {
    if (intent == BilangIntent.deleteMemory) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Lupakan ingatan ini?'),
          content: Text(memory.content),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Lupakan')),
          ],
        ),
      );
      await Future<void>.delayed(const Duration(milliseconds: 350));
      if (confirmed == true) await memoryService.delete(memory.id);
    } else {
      final controller = TextEditingController(text: memory.content);
      final value = await showDialog<String>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Ubah ingatan'),
          content: TextField(controller: controller, maxLines: 4, autofocus: true),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Batal')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, controller.text), child: const Text('Simpan')),
          ],
        ),
      );
      controller.dispose();
      await Future<void>.delayed(const Duration(milliseconds: 350));
      if (value != null && value.trim().isNotEmpty) {
        await memoryService.update(memory, content: value);
      }
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(intent == BilangIntent.deleteMemory ? 'Ingatan sudah dilupakan.' : 'Ingatan sudah diperbarui.')),
    );
  }

  Future<bool> _showConfirmation(EngineResult result) async {
    final title = result.entities['title'] as String? ?? '';
    final scheduledAt = result.entities['scheduledAt'] as DateTime;
    final date = _naturalDateLabel(scheduledAt);
    final period = result.entities['period'] as String?;
    final periodEnd = result.entities['periodEnd'] as TimeOfDayParts?;
    final isPeriodSeries = result.entities['periodSeries'] == true &&
        period != null &&
        periodEnd != null;
    final time = isPeriodSeries
        ? '${scheduledAt.hour.toString().padLeft(2, '0')}.${scheduledAt.minute.toString().padLeft(2, '0')} - ${periodEnd.hour.toString().padLeft(2, '0')}.${periodEnd.minute.toString().padLeft(2, '0')}'
        : '${scheduledAt.hour.toString().padLeft(2, '0')}.${scheduledAt.minute.toString().padLeft(2, '0')}';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Aku menangkap ini...'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Row(children: [const Icon(Icons.calendar_today_outlined, size: 18), const SizedBox(width: 8), Text(date)]),
            const SizedBox(height: 8),
            Row(children: [const Icon(Icons.schedule_outlined, size: 18), const SizedBox(width: 8), Text(time)]),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Ubah'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Titipkan'),
          ),
        ],
      ),
    );

    if (confirmed != true) return false;

    final occurrences = <DateTime>[];
    if (isPeriodSeries) {
      final end = DateTime(
        scheduledAt.year,
        scheduledAt.month,
        scheduledAt.day,
        periodEnd.hour,
        periodEnd.minute,
      );
      var current = scheduledAt;
      final now = DateTime.now();
      while (!current.isAfter(end)) {
        if (current.isAfter(now)) occurrences.add(current);
        current = current.add(const Duration(hours: 1));
      }
    } else {
      occurrences.add(scheduledAt);
    }

    if (occurrences.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Periode waktu itu sudah lewat untuk hari ini.')),
        );
      }
      return false;
    }

    final groupId = isPeriodSeries
        ? 'period-${DateTime.now().microsecondsSinceEpoch}'
        : null;
    for (var i = 0; i < occurrences.length; i++) {
      await reminderService.create(
        title: title,
        scheduledAt: occurrences[i],
        source: _inputSource == MemorySource.voice
            ? ReminderSource.voice
            : ReminderSource.text,
        parentReminderId: groupId,
        occurrenceId: groupId == null ? null : '${i + 1}',
      );
    }

    if (!mounted) return true;
    final message = isPeriodSeries
        ? 'Titipan kusimpan. Aku akan mengingatkanmu setiap jam selama $period. 👌'
        : 'Titipan sudah kusimpan. 👌';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    return true;
  }

  Future<String?> _showClarification(String message) async {
    final answer = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _ClarificationDialog(message: message),
    );

    // Let Flutter finish removing the dialog route and its focus tree before
    // HomeScreen starts another engine pass.
    await Future<void>.delayed(const Duration(milliseconds: 350));
    return answer;
  }

  String _naturalDateLabel(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final value = DateTime(date.year, date.month, date.day);
    if (value == today) return 'Hari ini';
    if (value == today.add(const Duration(days: 1))) return 'Besok';
    if (value == today.add(const Duration(days: 2))) return 'Lusa';
    return '${date.day}/${date.month}/${date.year}';
  }

  Widget _preview(BuildContext context, String title, String subtitle, {String? suffix}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Theme.of(context)
                  .colorScheme
                  .primary
                  .withValues(alpha: .15),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.schedule_rounded,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
                if (suffix != null) ...[
                  const SizedBox(height: 3),
                  Text(
                    suffix,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}


class _HomeReminderGroup {
  final List<Reminder> items;

  _HomeReminderGroup({required this.items});

  Reminder get first => items.reduce((a, b) =>
      a.scheduledAt.isBefore(b.scheduledAt) ? a : b);

  DateTime get start => first.scheduledAt;

  DateTime get end => items.reduce((a, b) =>
      a.scheduledAt.isAfter(b.scheduledAt) ? a : b).scheduledAt;

  String get title => first.title;
}

class _ClarificationDialog extends StatefulWidget {
  final String message;

  const _ClarificationDialog({required this.message});

  @override
  State<_ClarificationDialog> createState() => _ClarificationDialogState();
}

class _ClarificationDialogState extends State<_ClarificationDialog> {
  late final TextEditingController controller;

  @override
  void initState() {
    super.initState();
    controller = TextEditingController();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void _submit() {
    Navigator.of(context).pop(controller.text.trim());
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Aku perlu tahu sedikit lagi'),
      content: TextField(
        controller: controller,
        autofocus: true,
        textInputAction: TextInputAction.done,
        onSubmitted: (_) => _submit(),
        decoration: InputDecoration(hintText: widget.message),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Batal'),
        ),
        FilledButton(
          onPressed: _submit,
          child: const Text('Lanjut'),
        ),
      ],
    );
  }
}
