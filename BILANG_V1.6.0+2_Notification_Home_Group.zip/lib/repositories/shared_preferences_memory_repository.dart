import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/memory.dart';
import 'memory_repository.dart';

class SharedPreferencesMemoryRepository implements MemoryRepository {
  static const _key = 'bilang.memories.v1';
  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();

  Future<List<Memory>> _read() async {
    final raw = await _prefs.getStringList(_key) ?? const [];
    final memories = <Memory>[];
    for (final item in raw) {
      try {
        memories.add(Memory.fromJson(jsonDecode(item) as Map<String, dynamic>));
      } catch (_) {}
    }
    memories.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    return memories;
  }

  Future<void> _write(List<Memory> memories) async {
    await _prefs.setStringList(_key, memories.map((m) => jsonEncode(m.toJson())).toList());
  }

  @override
  Future<Memory> createMemory(Memory memory) async {
    final list = await _read();
    list.removeWhere((m) => m.id == memory.id);
    list.add(memory);
    await _write(list);
    return memory;
  }

  @override
  Future<List<Memory>> getMemories() async => _read();

  @override
  Future<Memory?> getMemoryById(String id) async {
    for (final memory in await _read()) {
      if (memory.id == id) return memory;
    }
    return null;
  }

  @override
  Future<void> updateMemory(Memory memory) async {
    final list = await _read();
    final index = list.indexWhere((m) => m.id == memory.id);
    if (index < 0) return;
    list[index] = memory;
    await _write(list);
  }

  @override
  Future<void> deleteMemory(String id) async {
    final list = await _read()..removeWhere((m) => m.id == id);
    await _write(list);
  }

  @override
  Future<void> archiveMemory(String id) async {
    final memory = await getMemoryById(id);
    if (memory == null) return;
    await updateMemory(memory.copyWith(isArchived: true, updatedAt: DateTime.now()));
  }

  @override
  Future<void> restoreMemory(String id) async {
    final memory = await getMemoryById(id);
    if (memory == null) return;
    await updateMemory(memory.copyWith(isArchived: false, updatedAt: DateTime.now()));
  }

  @override
  Future<List<Memory>> searchMemories(String query) async {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return getMemories();
    return (await _read()).where((m) =>
      !m.isArchived && (m.title.toLowerCase().contains(q) || m.content.toLowerCase().contains(q))
    ).toList();
  }

  @override
  Future<List<Memory>> findRelatedMemory(String query) async {
    final words = query.toLowerCase().split(RegExp(r'\s+')).where((w) => w.length >= 3).toSet();
    if (words.isEmpty) return const [];
    final memories = await _read();
    return memories.where((m) {
      if (m.isArchived) return false;
      final haystack = '${m.title} ${m.content}'.toLowerCase();
      return words.any(haystack.contains);
    }).toList();
  }

  @override
  Future<List<Memory>> findConflictingMemories(String query) async {
    return findRelatedMemory(query);
  }

  @override
  Future<List<Memory>> getMemoriesByCategory(MemoryCategory category) async =>
      (await _read()).where((m) => !m.isArchived && m.category == category).toList();

  @override
  Future<List<Memory>> getMemoriesByType(MemoryType type) async =>
      (await _read()).where((m) => !m.isArchived && m.type == type).toList();
}
