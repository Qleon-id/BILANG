import '../models/memory.dart';
import '../repositories/memory_repository.dart';

class MemorySaveResult {
  final bool saved;
  final bool sensitive;
  final String? message;
  final Memory? memory;

  const MemorySaveResult({required this.saved, this.sensitive = false, this.message, this.memory});
}

class MemoryService {
  final MemoryRepository repository;
  MemoryService(this.repository);

  static final _sensitivePattern = RegExp(
    r'\b(password|kata sandi|passwd|passcode|pin|otp|kode otp|cvv|cvc|security code|api key|apikey|secret key|private key|recovery code|kode pemulihan|token rahasia|credential|kredensial)\b',
    caseSensitive: false,
  );

  bool isSensitive(String value) => _sensitivePattern.hasMatch(value);

  MemoryCategory inferCategory(String text) {
    final value = text.toLowerCase();
    if (RegExp(r'\b(kuliah|kampus|dosen|kelas|skripsi|semester|ujian|tugas)\b').hasMatch(value)) return MemoryCategory.kuliah;
    if (RegExp(r'\b(kerja|kantor|bos|meeting|klien|proyek)\b').hasMatch(value)) return MemoryCategory.kerja;
    if (RegExp(r'\b(rumah|alamat rumah|kamar|wifi rumah|keluarga)\b').hasMatch(value)) return MemoryCategory.rumah;
    if (RegExp(r'\b(uang|gaji|rekening|bank|biaya|harga|keuangan)\b').hasMatch(value)) return MemoryCategory.keuangan;
    if (RegExp(r'\b(suka|senang|favorit|favorite|lebih suka|tidak suka)\b').hasMatch(value)) return MemoryCategory.personal;
    return MemoryCategory.lainnya;
  }

  MemoryType inferType(String text) {
    final value = text.toLowerCase();
    if (RegExp(r'\b(suka|senang|favorit|favorite|lebih suka|tidak suka|preferensi)\b').hasMatch(value)) return MemoryType.preference;
    if (value.contains('konteks')) return MemoryType.context;
    if (RegExp(r'\b(catatan|note|tambahan)\b').hasMatch(value)) return MemoryType.note;
    return MemoryType.fact;
  }

  Future<MemorySaveResult> save({
    required String content,
    String? title,
    MemoryCategory? category,
    MemoryType? type,
    MemorySource source = MemorySource.text,
  }) async {
    final clean = content.trim();
    if (clean.isEmpty) return const MemorySaveResult(saved: false, message: 'Aku belum menemukan informasi yang bisa disimpan.');
    if (isSensitive(clean)) {
      return const MemorySaveResult(
        saved: false,
        sensitive: true,
        message: 'Aku nggak menyimpan password, PIN, OTP, kode keamanan, atau kredensial pribadi. 🔐',
      );
    }

    final related = await repository.findRelatedMemory(clean);
    if (related.any((m) => m.content.trim().toLowerCase() == clean.toLowerCase())) {
      return MemorySaveResult(saved: false, message: 'Informasi itu sudah ada di Ingatan.');
    }

    final now = DateTime.now();
    final memory = Memory(
      id: now.microsecondsSinceEpoch.toString(),
      title: (title?.trim().isNotEmpty == true ? title!.trim() : _titleFromContent(clean)),
      content: clean,
      category: category ?? inferCategory(clean),
      type: type ?? inferType(clean),
      confidence: MemoryConfidence.high,
      source: source,
      createdAt: now,
      updatedAt: now,
    );
    await repository.createMemory(memory);
    return MemorySaveResult(saved: true, memory: memory, message: 'Aku simpan di Ingatan. 🧠');
  }

  Future<List<Memory>> search(String query) => repository.searchMemories(query);

  Future<void> update(Memory memory, {String? content, String? title}) async {
    final nextContent = content?.trim() ?? memory.content;
    if (isSensitive(nextContent)) return;
    await repository.updateMemory(memory.copyWith(
      content: nextContent,
      title: title?.trim().isNotEmpty == true ? title!.trim() : memory.title,
      updatedAt: DateTime.now(),
    ));
  }

  Future<void> delete(String id) => repository.deleteMemory(id);

  String _titleFromContent(String content) {
    final words = content.replaceAll(RegExp(r'\s+'), ' ').trim().split(' ');
    final title = words.take(7).join(' ');
    return title.length < content.length ? '$title...' : title;
  }
}
