import 'dart:convert';

enum MemoryType { fact, preference, context, note }
enum MemoryCategory { personal, rumah, kuliah, kerja, keuangan, lainnya }
enum MemoryConfidence { high, medium, low }
enum MemorySource { voice, text, manual }

class Memory {
  final String id;
  final String title;
  final String content;
  final MemoryCategory category;
  final MemoryType type;
  final MemoryConfidence confidence;
  final MemorySource source;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isArchived;

  const Memory({
    required this.id,
    required this.title,
    required this.content,
    this.category = MemoryCategory.lainnya,
    this.type = MemoryType.fact,
    this.confidence = MemoryConfidence.high,
    this.source = MemorySource.manual,
    required this.createdAt,
    required this.updatedAt,
    this.isArchived = false,
  });

  Memory copyWith({
    String? title,
    String? content,
    MemoryCategory? category,
    MemoryType? type,
    MemoryConfidence? confidence,
    MemorySource? source,
    DateTime? updatedAt,
    bool? isArchived,
  }) => Memory(
    id: id,
    title: title ?? this.title,
    content: content ?? this.content,
    category: category ?? this.category,
    type: type ?? this.type,
    confidence: confidence ?? this.confidence,
    source: source ?? this.source,
    createdAt: createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    isArchived: isArchived ?? this.isArchived,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'content': content,
    'category': category.name,
    'type': type.name,
    'confidence': confidence.name,
    'source': source.name,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
    'isArchived': isArchived,
  };

  factory Memory.fromJson(Map<String, dynamic> json) => Memory(
    id: json['id'] as String,
    title: json['title'] as String? ?? '',
    content: json['content'] as String? ?? '',
    category: MemoryCategory.values.firstWhere(
      (e) => e.name == json['category'],
      orElse: () => MemoryCategory.lainnya,
    ),
    type: MemoryType.values.firstWhere(
      (e) => e.name == json['type'],
      orElse: () => MemoryType.fact,
    ),
    confidence: MemoryConfidence.values.firstWhere(
      (e) => e.name == json['confidence'],
      orElse: () => MemoryConfidence.high,
    ),
    source: MemorySource.values.firstWhere(
      (e) => e.name == json['source'],
      orElse: () => MemorySource.manual,
    ),
    createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
    updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ?? DateTime.now(),
    isArchived: json['isArchived'] as bool? ?? false,
  );

  String encode() => jsonEncode(toJson());
}
