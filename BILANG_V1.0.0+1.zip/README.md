# BILANG V1.0.0 — Core Foundation

**Tagline:** Kamu bilang. BILANG yang ingat.

This is the first implementation baseline of the BILANG Master Blueprint v1.0.

## Scope
- Opening screen with selected-theme behavior.
- Onboarding with character selection and permission handling.
- 8 original vector-style character assets.
- Home / Titipan / Ingatan / Aku navigation.
- 15 themes and System/Light/Dark mode.
- Persistent user settings using SharedPreferences.
- Core data models and repository interfaces for reminders, memories, and settings.
- Foundation service layer and BILANG Engine contracts.
- Accessible UI foundations and empty states.

## Intentionally not implemented yet
The complex natural-language, voice recognition, reminder scheduling, notification engine, recurrence, memory inference, and contextual-memory behavior are staged for later milestones. V1.0 provides the architecture/contracts without pretending those systems are already functional.

## Android Build
BILANG is Android-only for this development track. Use a current stable Flutter SDK compatible with the Dart constraint in `pubspec.yaml`.

```bash
flutter create --platforms=android .
flutter pub get
flutter analyze
flutter build apk --debug
```

The project is developed as revision ZIPs. Each new revision replaces the previous source, while the same GitHub Actions workflow is used to analyze and build the Android APK.

## Package ID
The initial Android application ID is `com.example.bilang`. Change it before public release if a different owned reverse-domain identifier is desired.
