# Android Bootstrap

BILANG is an Android-only project for this development track.

The working environment used to prepare this source did not include the Flutter SDK, so the Android platform folder is intentionally not hand-faked. Generate the official Android scaffolding with the Flutter SDK from the project root:

```bash
flutter create --platforms=android .
flutter pub get
flutter analyze
flutter build apk --debug
```

The command preserves the `lib/`, `assets/`, and project configuration in this ZIP while generating the official Android platform scaffolding.

## Development workflow

Each revision will be delivered as a new ZIP. Replace the previous source with the new revision, then run the same GitHub Actions workflow. The workflow will generate Android platform files, analyze the project, build the APK, and upload the APK as a GitHub Actions artifact.

Initial Android application ID:

`com.example.bilang`
