enum BilangIntent { createReminder, updateReminder, completeReminder, rescheduleReminder, deleteReminder, createMemory, readMemory, updateMemory, deleteMemory, cancel, unknown }
enum Confidence { high, medium, low }

class EngineResult {
  final BilangIntent intent;
  final Confidence confidence;
  final Map<String, dynamic> entities;
  final bool requiresClarification;
  final bool requiresConfirmation;
  final String? response;

  const EngineResult({required this.intent, required this.confidence, this.entities = const {}, this.requiresClarification = false, this.requiresConfirmation = false, this.response});
}

/// Contract for the shared Text/Voice brain. Complex NLP is intentionally staged after V1.0.
class BilangEngine {
  Future<EngineResult> processInput(String input) async {
    if (input.trim().isEmpty) {
      return const EngineResult(intent: BilangIntent.unknown, confidence: Confidence.low, response: 'Aku belum yakin menangkap maksudmu. 👀');
    }
    return const EngineResult(intent: BilangIntent.unknown, confidence: Confidence.low, response: 'Aku masih belajar menangkap maksudmu. 👀');
  }
}
