/// Scheduling contract for the future notification milestone.
/// V1.0 does not schedule notifications yet, so the app never claims a reminder was scheduled.
class NotificationService {
  Future<void> initialize() async {}
  Future<void> scheduleReminder(String reminderId, DateTime scheduledAt) async {}
  Future<void> cancelReminder(String reminderId) async {}
  Future<void> rescheduleAll() async {}
}
