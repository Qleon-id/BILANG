class MemoryService {
  Future<void> initialize() async {}
}
