class ReminderService {
  Future<void> initialize() async {}
}
