class TimezoneService {
  String get currentTimezone => DateTime.now().timeZoneName;
}
