import '../models/conversation_context.dart';

class ContextService {
  ConversationContext? _context;

  void setContext(ConversationContext context) => _context = context;
  ConversationContext? get activeContext => (_context != null && !_context!.isExpired) ? _context : null;
  void clear() => _context = null;
}
