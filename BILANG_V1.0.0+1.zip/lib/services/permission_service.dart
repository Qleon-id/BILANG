import 'package:permission_handler/permission_handler.dart';

class PermissionService {
  Future<bool> requestMicrophone() async => (await Permission.microphone.request()).isGranted;
  Future<bool> requestNotifications() async {
    final status = await Permission.notification.request();
    return status.isGranted;
  }
}
