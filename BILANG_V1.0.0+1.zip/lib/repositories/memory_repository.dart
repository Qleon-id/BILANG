import '../models/memory.dart';

abstract interface class MemoryRepository {
  Future<Memory> createMemory(Memory memory);
  Future<List<Memory>> getMemories();
  Future<Memory?> getMemoryById(String id);
  Future<void> updateMemory(Memory memory);
  Future<void> deleteMemory(String id);
  Future<void> archiveMemory(String id);
  Future<void> restoreMemory(String id);
  Future<List<Memory>> searchMemories(String query);
  Future<List<Memory>> findRelatedMemory(String query);
  Future<List<Memory>> findConflictingMemories(String query);
  Future<List<Memory>> getMemoriesByCategory(MemoryCategory category);
  Future<List<Memory>> getMemoriesByType(MemoryType type);
}
