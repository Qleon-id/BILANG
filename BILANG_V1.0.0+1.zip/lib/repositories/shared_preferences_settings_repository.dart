import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_settings.dart';
import 'settings_repository.dart';

class SharedPreferencesSettingsRepository implements SettingsRepository {
  static const _key = 'bilang_user_settings_v1';
  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();

  @override
  Future<UserSettings> getSettings() async {
    final raw = await _prefs.getString(_key);
    if (raw == null) return const UserSettings();
    try {
      return UserSettings.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return const UserSettings();
    }
  }

  @override
  Future<void> updateSettings(UserSettings settings) async {
    await _prefs.setString(_key, jsonEncode(settings.toJson()));
  }

  @override
  Future<void> resetSettings() async => _prefs.remove(_key);
}
