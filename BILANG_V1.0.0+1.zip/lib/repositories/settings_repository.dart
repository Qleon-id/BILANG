import '../models/user_settings.dart';

abstract interface class SettingsRepository {
  Future<UserSettings> getSettings();
  Future<void> updateSettings(UserSettings settings);
  Future<void> resetSettings();
}
