import '../models/reminder.dart';

abstract interface class ReminderRepository {
  Future<Reminder> createReminder(Reminder reminder);
  Future<List<Reminder>> getReminders();
  Future<Reminder?> getReminderById(String id);
  Future<void> updateReminder(Reminder reminder);
  Future<void> completeReminder(String id);
  Future<void> deleteReminder(String id);
  Future<List<Reminder>> searchReminders(String query);
  Future<List<Reminder>> getActiveReminders();
  Future<List<Reminder>> getUpcomingReminders();
  Future<List<Reminder>> getOverdueReminders();
  Future<void> snoozeReminder(String id, DateTime until);
  Future<void> dismissReminder(String id);
}
