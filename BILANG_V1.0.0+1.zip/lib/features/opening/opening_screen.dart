import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/theme/bilang_theme.dart';

class OpeningScreen extends StatefulWidget {
  final VoidCallback onFinished;
  const OpeningScreen({super.key, required this.onFinished});
  @override State<OpeningScreen> createState() => _OpeningScreenState();
}

class _OpeningScreenState extends State<OpeningScreen> with SingleTickerProviderStateMixin {
  late final AnimationController controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 850))..forward();
  @override void initState() { super.initState(); Timer(const Duration(milliseconds: 1100), widget.onFinished); }
  @override void dispose() { controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Scaffold(backgroundColor: primary, body: FadeTransition(opacity: CurvedAnimation(parent: controller, curve: Curves.easeOut), child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 92, height: 92, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28)), child: const Center(child: Text('B', style: TextStyle(fontSize: 52, fontWeight: FontWeight.w800, color: BilangTheme.darkBackground)))),
      const SizedBox(height: 24),
      const Text('Kamu bilang.\nBILANG yang ingat.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 20, height: 1.35, fontWeight: FontWeight.w700)),
    ]))));
  }
}
