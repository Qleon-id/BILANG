import '../../models/user_settings.dart';

class CharacterInfo {
  final CharacterType type;
  final String name;
  final String personality;
  const CharacterInfo(this.type, this.name, this.personality);
}

const characterInfos = [
  CharacterInfo(CharacterType.bear, 'Bear', 'Calm & Warm'),
  CharacterInfo(CharacterType.cat, 'Cat', 'Relaxed & Playful'),
  CharacterInfo(CharacterType.rabbit, 'Rabbit', 'Cheerful & Energetic'),
  CharacterInfo(CharacterType.dog, 'Dog', 'Loyal & Supportive'),
  CharacterInfo(CharacterType.fox, 'Fox', 'Clever & Observant'),
  CharacterInfo(CharacterType.panda, 'Panda', 'Chill & Gentle'),
  CharacterInfo(CharacterType.koala, 'Koala', 'Soft & Comforting'),
  CharacterInfo(CharacterType.penguin, 'Penguin', 'Organized & Reliable'),
];
