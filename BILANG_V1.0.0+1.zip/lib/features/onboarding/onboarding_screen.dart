import 'package:flutter/material.dart';
import '../../models/user_settings.dart';
import '../../repositories/shared_preferences_settings_repository.dart';
import '../../services/permission_service.dart';
import 'character_data.dart';
import 'character_view.dart';

class OnboardingScreen extends StatefulWidget {
  final UserSettings settings;
  final Future<void> Function(UserSettings) onComplete;

  const OnboardingScreen({
    super.key,
    required this.settings,
    required this.onComplete,
  });

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  late UserSettings settings = widget.settings;
  final repo = SharedPreferencesSettingsRepository();
  final permissions = PermissionService();
  int step = 0;

  Future<void> save(UserSettings value) async {
    settings = value;
    await repo.updateSettings(value);
    if (mounted) {
      setState(() {});
    }
  }

  Future<void> next() async {
    if (step == 2) {
      await permissions.requestMicrophone();
    }
    if (step == 3) {
      await permissions.requestNotifications();
    }

    if (step < 4) {
      final nextStep = step + 1;
      await save(settings.copyWith(onboardingStep: nextStep));
      if (mounted) {
        setState(() => step = nextStep);
      }
    } else {
      await widget.onComplete(settings);
    }
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    final info = characterInfos.firstWhere(
      (character) => character.type == settings.selectedCharacter,
    );

    final Widget content = switch (step) {
      0 => _intro(context),
      1 => _characterPicker(context, primary),
      2 => _permission(
          context,
          Icons.mic_none_rounded,
          'Bilang aja, aku dengarkan.',
          'Kamu bisa bicara secara natural. Kalau mikrofon tidak diizinkan, kamu tetap bisa mengetik.',
        ),
      3 => _permission(
          context,
          Icons.notifications_none_rounded,
          'Biar aku bisa mengingatkanmu.',
          'Notifikasi membantu BILANG mengingatkan Titipan. Kalau ditolak, Titipan tetap tersimpan.',
        ),
      _ => _summary(context, info),
    };

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 24),
          child: Column(
            children: [
              Row(
                children: [
                  const Text(
                    'BILANG',
                    style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20),
                  ),
                  const Spacer(),
                  Text(
                    '${step + 1}/5',
                    style: Theme.of(context).textTheme.labelLarge,
                  ),
                ],
              ),
              const SizedBox(height: 28),
              Expanded(child: content),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: next,
                  child: Text(step == 4 ? 'Mulai' : 'Lanjut'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _intro(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CharacterView(character: settings.selectedCharacter, size: 170),
          const SizedBox(height: 24),
          Text(
            'Hai! Aku temanmu.',
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          Text(
            'Mulai sekarang, kalau ada sesuatu yang takut kamu lupa, bilang aja.',
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }

  Widget _characterPicker(BuildContext context, Color primary) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Pilih temanmu',
          style: Theme.of(context)
              .textTheme
              .headlineSmall
              ?.copyWith(fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 8),
        Text(
          'Teman yang akan menemanimu mengingat.',
          style: Theme.of(context).textTheme.bodyMedium,
        ),
        const SizedBox(height: 18),
        Expanded(
          child: GridView.builder(
            itemCount: characterInfos.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.05,
            ),
            itemBuilder: (_, index) {
              final character = characterInfos[index];
              final selected = character.type == settings.selectedCharacter;

              return InkWell(
                borderRadius: BorderRadius.circular(24),
                onTap: () => save(
                  settings.copyWith(selectedCharacter: character.type),
                ),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  decoration: BoxDecoration(
                    color: selected
                        ? primary.withValues(alpha: .15)
                        : Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: selected
                          ? primary
                          : Theme.of(context).dividerColor,
                      width: selected ? 2 : 1,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CharacterView(character: character.type, size: 82),
                      Text(
                        character.name,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      Text(
                        character.personality,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _permission(
    BuildContext context,
    IconData icon,
    String title,
    String body,
  ) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 72, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 24),
          Text(
            title,
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          Text(
            body,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }

  Widget _summary(BuildContext context, CharacterInfo info) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CharacterView(character: info.type, size: 150),
          const SizedBox(height: 20),
          Text(
            'Siap. 👋',
            style: Theme.of(context)
                .textTheme
                .headlineSmall
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          Text(
            '${info.name} akan menemanimu mengingat.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
