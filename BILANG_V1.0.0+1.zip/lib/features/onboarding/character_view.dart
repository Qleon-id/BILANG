import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../../models/user_settings.dart';

class CharacterView extends StatelessWidget {
  final CharacterType character;
  final double size;
  const CharacterView({super.key, required this.character, this.size = 150});

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset('assets/characters/${character.name}.svg', width: size, height: size, fit: BoxFit.contain);
  }
}
