import 'package:flutter/material.dart';
import '../../models/user_settings.dart';
import '../aku/aku_screen.dart';
import '../ingatan/ingatan_screen.dart';
import '../onboarding/character_data.dart';
import '../onboarding/character_view.dart';
import '../titipan/titipan_screen.dart';

class HomeScreen extends StatefulWidget {
  final UserSettings settings;
  final Future<void> Function(UserSettings) onSettingsChanged;

  const HomeScreen({
    super.key,
    required this.settings,
    required this.onSettingsChanged,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final input = TextEditingController();

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _home(context),
      const TitipanScreen(),
      const IngatanScreen(),
      AkuScreen(
        settings: widget.settings,
        onSettingsChanged: widget.onSettingsChanged,
      ),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.schedule_outlined),
            selectedIcon: Icon(Icons.schedule),
            label: 'Titipan',
          ),
          NavigationDestination(
            icon: Icon(Icons.psychology_alt_outlined),
            selectedIcon: Icon(Icons.psychology_alt),
            label: 'Ingatan',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Aku',
          ),
        ],
      ),
    );
  }

  Widget _home(BuildContext context) {
    final hour = DateTime.now().hour;
    final greeting = hour < 11
        ? 'Selamat pagi 👋 Ada yang mau kamu titipkan hari ini?'
        : hour < 17
            ? 'Lagi sibuk? 👀 Bilang aja. Aku ingat.'
            : hour < 22
                ? 'Sebelum lanjut... Ada sesuatu yang perlu kamu titipkan?'
                : 'Sebelum tidur... 🌙 Ada yang perlu aku ingat untuk besok?';

    final info = characterInfos.firstWhere(
      (character) => character.type == widget.settings.selectedCharacter,
    );

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'BILANG',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => setState(() => index = 3),
                icon: const Icon(Icons.tune_rounded),
                tooltip: 'Pengaturan',
              ),
            ],
          ),
          const SizedBox(height: 18),
          Center(
            child: Column(
              children: [
                CharacterView(character: info.type, size: 170),
                const SizedBox(height: 10),
                Text(
                  greeting,
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Center(
            child: Container(
              width: 92,
              height: 92,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Theme.of(context).colorScheme.primary,
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(context)
                        .colorScheme
                        .primary
                        .withValues(alpha: .25),
                    blurRadius: 20,
                    spreadRadius: 3,
                  ),
                ],
              ),
              child: IconButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Voice akan diaktifkan pada milestone Voice.',
                      ),
                    ),
                  );
                },
                icon: const Icon(
                  Icons.mic_rounded,
                  size: 40,
                  color: Colors.white,
                ),
                tooltip: 'Bilang',
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              'Tekan dan bilang aja',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: input,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                    'Natural Language Engine akan diaktifkan pada milestone berikutnya.',
                  ),
                ),
              );
            },
            decoration: const InputDecoration(
              hintText: 'atau ketik aja...',
            ),
          ),
          const SizedBox(height: 30),
          Row(
            children: [
              Text(
                'Titipan hari ini',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
              const Spacer(),
              TextButton(
                onPressed: () => setState(() => index = 1),
                child: const Text('Lihat semua'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _preview(
            context,
            'Belum ada titipan hari ini',
            'Kalau ada yang takut kamu lupa, bilang aja.',
          ),
        ],
      ),
    );
  }

  Widget _preview(BuildContext context, String title, String subtitle) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Theme.of(context)
                  .colorScheme
                  .primary
                  .withValues(alpha: .15),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.schedule_rounded,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
