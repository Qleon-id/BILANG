import 'package:flutter/material.dart';
import '../../models/user_settings.dart';
import '../onboarding/character_view.dart';
import '../onboarding/character_data.dart';

class AkuScreen extends StatelessWidget {
  final UserSettings settings;
  final Future<void> Function(UserSettings) onSettingsChanged;
  const AkuScreen({super.key, required this.settings, required this.onSettingsChanged});
  @override Widget build(BuildContext c){final info=characterInfos.firstWhere((x)=>x.type==settings.selectedCharacter);return ListView(padding:const EdgeInsets.fromLTRB(22,22,22,28),children:[Text('Aku',style:Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:20),Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:Theme.of(c).colorScheme.surface,borderRadius:BorderRadius.circular(24),border:Border.all(color:Theme.of(c).dividerColor)),child:Row(children:[CharacterView(character:info.type,size:92),const SizedBox(width:16),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(info.name,style:Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w800)),const SizedBox(height:5),const Text('Teman yang menemani kamu mengingat.'),const SizedBox(height:12),OutlinedButton(onPressed:(){},child:const Text('Ganti teman'))]))])),const SizedBox(height:18),_section(c,'🎨 Tema',Icons.palette_outlined),_section(c,'🔔 Pengingat',Icons.notifications_none),_section(c,'🔊 Suara & getar',Icons.volume_up_outlined),_section(c,'🌙 Waktu tenang',Icons.nights_stay_outlined),_section(c,'🧠 Ingatan',Icons.psychology_alt_outlined),_section(c,'🗣️ Bahasa & cara bicara',Icons.chat_bubble_outline),_section(c,'🔐 Privasi',Icons.lock_outline),_section(c,'ℹ️ Tentang BILANG',Icons.info_outline) ]);}
  Widget _section(BuildContext c,String title,IconData icon)=>Card(elevation:0,margin:const EdgeInsets.only(bottom:10),child:ListTile(leading:Icon(icon),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w700)),trailing:const Icon(Icons.chevron_right),onTap:(){ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text('$title akan dikembangkan pada milestone berikutnya.')));}));
}
