class ConversationContext {
  final String id;
  final String? intent;
  final Map<String, dynamic> partialEntities;
  final DateTime createdAt;
  final DateTime expiresAt;
  final String source;
  final String confidence;

  const ConversationContext({required this.id, this.intent, this.partialEntities = const {}, required this.createdAt, required this.expiresAt, this.source = 'text', this.confidence = 'low'});

  bool get isExpired => DateTime.now().isAfter(expiresAt);
}
