enum MemoryType { fact, preference, context, note }
enum MemoryCategory { personal, rumah, kuliah, kerja, keuangan, lainnya }
enum MemoryConfidence { high, medium, low }
enum MemorySource { voice, text, manual }

class Memory {
  final String id;
  final String title;
  final String content;
  final MemoryCategory category;
  final MemoryType type;
  final MemoryConfidence confidence;
  final MemorySource source;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isArchived;

  const Memory({required this.id, required this.title, required this.content, this.category = MemoryCategory.lainnya, this.type = MemoryType.fact, this.confidence = MemoryConfidence.high, this.source = MemorySource.manual, required this.createdAt, required this.updatedAt, this.isArchived = false});
}
