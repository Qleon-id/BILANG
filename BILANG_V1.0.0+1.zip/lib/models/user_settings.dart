enum AppThemeMode { system, light, dark }
enum NotificationStyle { natural, short, casual }
enum ResponseStyle { santai, netral, singkat }

enum CharacterType { bear, cat, rabbit, dog, fox, panda, koala, penguin }
enum ThemeName { yellow, red, orange, blue, lightBlue, darkGreen, lightGreen, sage, navy, purple, pink, brown, milkBrown, gray, charcoal }

class UserSettings {
  final CharacterType selectedCharacter;
  final ThemeName selectedTheme;
  final AppThemeMode appThemeMode;
  final bool notificationsEnabled;
  final NotificationStyle notificationStyle;
  final bool notificationPreview;
  final bool soundEnabled;
  final bool vibrationEnabled;
  final bool quietHoursEnabled;
  final String quietStart;
  final String quietEnd;
  final bool importantReminderDuringQuietHours;
  final bool contextualMemoryEnabled;
  final String language;
  final ResponseStyle responseStyle;
  final bool onboardingCompleted;
  final int onboardingStep;

  const UserSettings({
    this.selectedCharacter = CharacterType.bear,
    this.selectedTheme = ThemeName.yellow,
    this.appThemeMode = AppThemeMode.system,
    this.notificationsEnabled = true,
    this.notificationStyle = NotificationStyle.natural,
    this.notificationPreview = true,
    this.soundEnabled = true,
    this.vibrationEnabled = true,
    this.quietHoursEnabled = true,
    this.quietStart = '22:00',
    this.quietEnd = '06:00',
    this.importantReminderDuringQuietHours = true,
    this.contextualMemoryEnabled = true,
    this.language = 'Bahasa Indonesia',
    this.responseStyle = ResponseStyle.santai,
    this.onboardingCompleted = false,
    this.onboardingStep = 0,
  });

  UserSettings copyWith({
    CharacterType? selectedCharacter,
    ThemeName? selectedTheme,
    AppThemeMode? appThemeMode,
    bool? notificationsEnabled,
    NotificationStyle? notificationStyle,
    bool? notificationPreview,
    bool? soundEnabled,
    bool? vibrationEnabled,
    bool? quietHoursEnabled,
    String? quietStart,
    String? quietEnd,
    bool? importantReminderDuringQuietHours,
    bool? contextualMemoryEnabled,
    String? language,
    ResponseStyle? responseStyle,
    bool? onboardingCompleted,
    int? onboardingStep,
  }) => UserSettings(
    selectedCharacter: selectedCharacter ?? this.selectedCharacter,
    selectedTheme: selectedTheme ?? this.selectedTheme,
    appThemeMode: appThemeMode ?? this.appThemeMode,
    notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
    notificationStyle: notificationStyle ?? this.notificationStyle,
    notificationPreview: notificationPreview ?? this.notificationPreview,
    soundEnabled: soundEnabled ?? this.soundEnabled,
    vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
    quietHoursEnabled: quietHoursEnabled ?? this.quietHoursEnabled,
    quietStart: quietStart ?? this.quietStart,
    quietEnd: quietEnd ?? this.quietEnd,
    importantReminderDuringQuietHours: importantReminderDuringQuietHours ?? this.importantReminderDuringQuietHours,
    contextualMemoryEnabled: contextualMemoryEnabled ?? this.contextualMemoryEnabled,
    language: language ?? this.language,
    responseStyle: responseStyle ?? this.responseStyle,
    onboardingCompleted: onboardingCompleted ?? this.onboardingCompleted,
    onboardingStep: onboardingStep ?? this.onboardingStep,
  );

  Map<String, dynamic> toJson() => {
    'selectedCharacter': selectedCharacter.name,
    'selectedTheme': selectedTheme.name,
    'appThemeMode': appThemeMode.name,
    'notificationsEnabled': notificationsEnabled,
    'notificationStyle': notificationStyle.name,
    'notificationPreview': notificationPreview,
    'soundEnabled': soundEnabled,
    'vibrationEnabled': vibrationEnabled,
    'quietHoursEnabled': quietHoursEnabled,
    'quietStart': quietStart,
    'quietEnd': quietEnd,
    'importantReminderDuringQuietHours': importantReminderDuringQuietHours,
    'contextualMemoryEnabled': contextualMemoryEnabled,
    'language': language,
    'responseStyle': responseStyle.name,
    'onboardingCompleted': onboardingCompleted,
    'onboardingStep': onboardingStep,
  };

  factory UserSettings.fromJson(Map<String, dynamic> json) => UserSettings(
    selectedCharacter: CharacterType.values.firstWhere((e) => e.name == json['selectedCharacter'], orElse: () => CharacterType.bear),
    selectedTheme: ThemeName.values.firstWhere((e) => e.name == json['selectedTheme'], orElse: () => ThemeName.yellow),
    appThemeMode: AppThemeMode.values.firstWhere((e) => e.name == json['appThemeMode'], orElse: () => AppThemeMode.system),
    notificationsEnabled: json['notificationsEnabled'] ?? true,
    notificationStyle: NotificationStyle.values.firstWhere((e) => e.name == json['notificationStyle'], orElse: () => NotificationStyle.natural),
    notificationPreview: json['notificationPreview'] ?? true,
    soundEnabled: json['soundEnabled'] ?? true,
    vibrationEnabled: json['vibrationEnabled'] ?? true,
    quietHoursEnabled: json['quietHoursEnabled'] ?? true,
    quietStart: json['quietStart'] ?? '22:00',
    quietEnd: json['quietEnd'] ?? '06:00',
    importantReminderDuringQuietHours: json['importantReminderDuringQuietHours'] ?? true,
    contextualMemoryEnabled: json['contextualMemoryEnabled'] ?? true,
    language: json['language'] ?? 'Bahasa Indonesia',
    responseStyle: ResponseStyle.values.firstWhere((e) => e.name == json['responseStyle'], orElse: () => ResponseStyle.santai),
    onboardingCompleted: json['onboardingCompleted'] ?? false,
    onboardingStep: json['onboardingStep'] ?? 0,
  );
}
