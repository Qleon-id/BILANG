enum ReminderStatus { active, triggered, completed, snoozed, dismissed }
enum ReminderRecurrence { none, daily, weekly, monthly, custom }
enum ReminderSource { voice, text, manual }

enum ReminderPriority { normal, important }

class Reminder {
  final String id;
  final String title;
  final DateTime scheduledAt;
  final String timezone;
  final DateTime createdAt;
  final DateTime updatedAt;
  final ReminderStatus status;
  final ReminderRecurrence recurrence;
  final ReminderPriority priority;
  final Duration? reminderLeadTime;
  final ReminderSource source;
  final String? parentReminderId;
  final String? occurrenceId;

  const Reminder({required this.id, required this.title, required this.scheduledAt, required this.timezone, required this.createdAt, required this.updatedAt, this.status = ReminderStatus.active, this.recurrence = ReminderRecurrence.none, this.priority = ReminderPriority.normal, this.reminderLeadTime, this.source = ReminderSource.manual, this.parentReminderId, this.occurrenceId});
}
