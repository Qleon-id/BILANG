import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/user_settings.dart';

class BilangTheme {
  static const lightBackground = Color(0xFFFFFDF7);
  static const darkBackground = Color(0xFF171717);
  static const darkSurface = Color(0xFF222222);

  static const Map<ThemeName, Color> colors = {
    ThemeName.yellow: Color(0xFFF5C542), ThemeName.red: Color(0xFFE05252), ThemeName.orange: Color(0xFFF08A3C),
    ThemeName.blue: Color(0xFF4D7CFE), ThemeName.lightBlue: Color(0xFF65B7E8), ThemeName.darkGreen: Color(0xFF367A57),
    ThemeName.lightGreen: Color(0xFF72B86A), ThemeName.sage: Color(0xFF8AA58B), ThemeName.navy: Color(0xFF334B73),
    ThemeName.purple: Color(0xFF8A62C9), ThemeName.pink: Color(0xFFD96C9D), ThemeName.brown: Color(0xFF9A6A4A),
    ThemeName.milkBrown: Color(0xFFC6A77B), ThemeName.gray: Color(0xFF7A7A7A), ThemeName.charcoal: Color(0xFF3E4146),
  };

  static ThemeData light(ThemeName name) => _build(name, Brightness.light);
  static ThemeData dark(ThemeName name) => _build(name, Brightness.dark);

  static ThemeData _build(ThemeName name, Brightness brightness) {
    final primary = colors[name] ?? colors[ThemeName.yellow]!;
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(seedColor: primary, brightness: brightness).copyWith(
      primary: primary,
      surface: dark ? darkSurface : Colors.white,
    );
    final base = ThemeData(colorScheme: scheme, brightness: brightness, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: dark ? darkBackground : lightBackground,
      textTheme: GoogleFonts.plusJakartaSansTextTheme(base.textTheme),
      appBarTheme: AppBarTheme(backgroundColor: dark ? darkBackground : lightBackground, foregroundColor: dark ? Colors.white : const Color(0xFF171717), elevation: 0),
      navigationBarTheme: NavigationBarThemeData(backgroundColor: dark ? darkSurface : Colors.white, indicatorColor: primary.withValues(alpha: .18)),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? darkSurface : Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: dark ? const Color(0xFF363636) : const Color(0xFFEAE6DC))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: primary, width: 1.5)),
      ),
    );
  }
}
