import '../models/reminder.dart';
import '../models/user_settings.dart';
import '../repositories/reminder_repository.dart';
import 'notification_service.dart';

class ReminderService {
  final ReminderRepository repository;
  final NotificationService notificationService;
  final UserSettings settings;

  ReminderService(
    this.repository, {
    required this.settings,
    NotificationService? notificationService,
  }) : notificationService = notificationService ?? NotificationService();

  Future<Reminder> create({
    required String title,
    required DateTime scheduledAt,
    ReminderRecurrence recurrence = ReminderRecurrence.none,
    ReminderPriority priority = ReminderPriority.normal,
    ReminderSource source = ReminderSource.manual,
  }) async {
    final now = DateTime.now();
    final reminder = Reminder(
      id: now.microsecondsSinceEpoch.toString(),
      title: title.trim(),
      scheduledAt: scheduledAt,
      timezone: DateTime.now().timeZoneName,
      createdAt: now,
      updatedAt: now,
      recurrence: recurrence,
      priority: priority,
      source: source,
    );
    final saved = await repository.createReminder(reminder);
    await notificationService.scheduleReminder(saved, settings);
    return saved;
  }

  Future<void> complete(String id) async {
    await notificationService.cancelReminder(id);
    await repository.completeReminder(id);
  }

  Future<void> delete(String id) async {
    await notificationService.cancelReminder(id);
    await repository.deleteReminder(id);
  }

  Future<void> snooze(String id, DateTime until) async {
    await notificationService.cancelReminder(id);
    await repository.snoozeReminder(id, until);
    final updated = await repository.getReminderById(id);
    if (updated != null) {
      await notificationService.scheduleReminder(updated, settings);
    }
  }

  Future<void> dismiss(String id) async {
    await notificationService.cancelReminder(id);
    await repository.dismissReminder(id);
  }
}
