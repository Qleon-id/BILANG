
/// Natural-language intent and entity extraction shared by Text and Voice.
enum BilangIntent {
  createReminder,
  updateReminder,
  completeReminder,
  rescheduleReminder,
  deleteReminder,
  createMemory,
  readMemory,
  updateMemory,
  deleteMemory,
  cancel,
  unknown,
}

enum Confidence { high, medium, low }

class EngineResult {
  final BilangIntent intent;
  final Confidence confidence;
  final Map<String, dynamic> entities;
  final bool requiresClarification;
  final bool requiresConfirmation;
  final String? response;

  const EngineResult({
    required this.intent,
    required this.confidence,
    this.entities = const {},
    this.requiresClarification = false,
    this.requiresConfirmation = false,
    this.response,
  });
}

/// V1.2 text brain.
///
/// This parser deliberately favors asking a question over guessing when a
/// required reminder date/time is missing or ambiguous. Voice will reuse the
/// same engine in V1.3.
class BilangEngine {
  Future<EngineResult> processInput(String input) async {
    final original = input.trim();
    if (original.isEmpty) {
      return const EngineResult(
        intent: BilangIntent.unknown,
        confidence: Confidence.low,
        response: 'Aku belum yakin menangkap maksudmu. 👀',
      );
    }

    final text = _normalize(original);
    final intent = _detectIntent(text);

    if (intent == BilangIntent.cancel) {
      return const EngineResult(
        intent: BilangIntent.cancel,
        confidence: Confidence.high,
        response: 'Oke, aku batalkan.',
      );
    }

    if (intent != BilangIntent.createReminder) {
      return EngineResult(
        intent: intent,
        confidence: intent == BilangIntent.unknown
            ? Confidence.low
            : Confidence.medium,
        response: intent == BilangIntent.unknown
            ? 'Aku belum yakin menangkap maksudmu. 👀'
            : 'Aku sudah menangkap maksudmu, tapi tindakan ini akan kita aktifkan di tahap berikutnya.',
      );
    }

    final dateInfo = _extractDate(text);
    final timeInfo = _extractTime(text);
    final title = _extractTitle(text);

    if (title.isEmpty) {
      return const EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.low,
        requiresClarification: true,
        response: 'Apa yang perlu aku ingatkan?',
      );
    }

    if (dateInfo.date == null && timeInfo.time == null) {
      return EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.medium,
        entities: {'title': title},
        requiresClarification: true,
        response: 'Kapan aku harus mengingatkannya?',
      );
    }

    if (timeInfo.time == null) {
      return EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.medium,
        entities: {
          'title': title,
          if (dateInfo.date != null) 'date': dateInfo.date,
          if (dateInfo.label != null) 'dateLabel': dateInfo.label,
          if (timeInfo.period != null) 'period': timeInfo.period,
        },
        requiresClarification: true,
        response: timeInfo.period != null
            ? 'Jam berapa ${dateInfo.label ?? 'hari itu'}?'
            : 'Jam berapa aku harus mengingatkannya?',
      );
    }

    if (dateInfo.date == null) {
      return EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.medium,
        entities: {
          'title': title,
          'time': timeInfo.time,
          'timeLabel': timeInfo.label,
        },
        requiresClarification: true,
        response: 'Tanggal berapa aku harus mengingatkannya?',
      );
    }

    final date = dateInfo.date!;
    final time = timeInfo.time!;
    final scheduledAt = DateTime(
      date.year,
      date.month,
      date.day,
      time.hour,
      time.minute,
    );

    if (scheduledAt.isBefore(DateTime.now())) {
      return EngineResult(
        intent: BilangIntent.createReminder,
        confidence: Confidence.medium,
        entities: {
          'title': title,
          'date': date,
          'time': time,
          'scheduledAt': scheduledAt,
        },
        requiresClarification: true,
        response: 'Waktu itu sudah lewat. Kamu mau pilih waktu lain?',
      );
    }

    return EngineResult(
      intent: BilangIntent.createReminder,
      confidence: Confidence.high,
      entities: {
        'title': title,
        'date': date,
        'time': time,
        'scheduledAt': scheduledAt,
        'dateLabel': dateInfo.label,
        'timeLabel': timeInfo.label,
      },
      requiresConfirmation: true,
      response: 'Aku menangkap ini...',
    );
  }

  String _normalize(String input) {
    return input
        .toLowerCase()
        .replaceAll(RegExp(r'[!?]+'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  BilangIntent _detectIntent(String text) {
    if (RegExp(r'^(batal|cancel|nggak jadi|gak jadi|tidak jadi)').hasMatch(text)) {
      return BilangIntent.cancel;
    }
    if (RegExp(r'\b(lupakan|hapus|delete)\b').hasMatch(text)) {
      return text.contains('ingat') ? BilangIntent.deleteMemory : BilangIntent.deleteReminder;
    }
    if (RegExp(r'\b(sudah|selesai|beres|done)\b').hasMatch(text)) {
      return BilangIntent.completeReminder;
    }
    if (RegExp(r'\b(ubah|ganti|update|reschedule|jadwal ulang)\b').hasMatch(text)) {
      return text.contains('jam') || text.contains('jadwal')
          ? BilangIntent.rescheduleReminder
          : BilangIntent.updateReminder;
    }
    if (RegExp(r'\b(ingat bahwa|ingat kalau|simpan sebagai ingatan|ingat ini)\b').hasMatch(text)) {
      return BilangIntent.createMemory;
    }
    if (RegExp(r'\b(apa yang aku titip|ingatkan aku apa|titipan aku)\b').hasMatch(text)) {
      return BilangIntent.readMemory;
    }
    if (_looksLikeReminder(text)) return BilangIntent.createReminder;
    return BilangIntent.unknown;
  }

  bool _looksLikeReminder(String text) {
    return RegExp(r'\b(ingatkan|ingetin|ingatkan aku|ingetin aku|titipkan|titip|jangan lupa|remind me|remind|ingat aku)\b')
            .hasMatch(text) ||
        (_extractDate(text).date != null && _extractTime(text).time != null);
  }

  _DateInfo _extractDate(String text) {
    final now = DateTime.now();
    if (text.contains('lusa')) {
      return _DateInfo(DateTime(now.year, now.month, now.day + 2), 'lusa');
    }
    if (text.contains('besok')) {
      return _DateInfo(DateTime(now.year, now.month, now.day + 1), 'besok');
    }
    if (text.contains('hari ini')) {
      return _DateInfo(DateTime(now.year, now.month, now.day), 'hari ini');
    }
    if (text.contains('minggu depan')) {
      return _DateInfo(DateTime(now.year, now.month, now.day + 7), 'minggu depan');
    }

    final explicit = RegExp(r'\b(\d{1,2})[\/-](\d{1,2})(?:[\/-](\d{2,4}))?\b').firstMatch(text);
    if (explicit != null) {
      final day = int.parse(explicit.group(1)!);
      final month = int.parse(explicit.group(2)!);
      final year = explicit.group(3) == null
          ? now.year
          : int.parse(explicit.group(3)!);
      final fixedYear = year < 100 ? 2000 + year : year;
      final date = _safeDate(fixedYear, month, day);
      if (date != null) return _DateInfo(date, '$day/$month/$fixedYear');
    }

    const months = <String, int>{
      'januari': 1, 'februari': 2, 'maret': 3, 'april': 4, 'mei': 5,
      'juni': 6, 'juli': 7, 'agustus': 8, 'september': 9, 'oktober': 10,
      'november': 11, 'desember': 12,
    };
    for (final entry in months.entries) {
      final match = RegExp(r'\b(\d{1,2})\s+' + entry.key + r'(?:\s+(\d{4}))?\b').firstMatch(text);
      if (match != null) {
        final day = int.parse(match.group(1)!);
        final year = match.group(2) == null ? now.year : int.parse(match.group(2)!);
        final date = _safeDate(year, entry.value, day);
        if (date != null) return _DateInfo(date, '$day ${entry.key} $year');
      }
    }
    return const _DateInfo(null, null);
  }

  _TimeInfo _extractTime(String text) {
    final period = _periodIn(text);

    final half = RegExp(r'\bsetengah\s+(\d{1,2})\b').firstMatch(text);
    if (half != null) {
      final hour = int.parse(half.group(1)!);
      final adjusted = hour == 0 ? 0 : hour - 1;
      final h = _applyPeriod(adjusted, period);
      return _TimeInfo(TimeOfDayParts(h, 30), _formatTime(h, 30), period);
    }

    final quarter = RegExp(r'\bjam\s+(\d{1,2})\s+kurang\s+seperempat\b').firstMatch(text);
    if (quarter != null) {
      var hour = int.parse(quarter.group(1)!);
      hour = hour == 0 ? 0 : hour - 1;
      hour = _applyPeriod(hour, period);
      return _TimeInfo(TimeOfDayParts(hour, 45), _formatTime(hour, 45), period);
    }

    const numberWords = <String, int>{
      'nol': 0, 'satu': 1, 'dua': 2, 'tiga': 3, 'empat': 4,
      'lima': 5, 'enam': 6, 'tujuh': 7, 'delapan': 8, 'sembilan': 9,
      'sepuluh': 10, 'sebelas': 11,
    };
    final spokenNumber = RegExp(r'\b(?:jam|pukul)\s+(nol|satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas)\s*(pagi|siang|sore|malam|am|pm)?\b').firstMatch(text);
    if (spokenNumber != null) {
      final hour = _applyPeriod(numberWords[spokenNumber.group(1)!]!, spokenNumber.group(2) ?? period);
      return _TimeInfo(TimeOfDayParts(hour, 0), _formatTime(hour, 0), spokenNumber.group(2) ?? period);
    }

    final standard = RegExp(r'\b(?:jam|pukul)\s*(\d{1,2})(?:\s*[:.]\s*(\d{2}))?\s*(pagi|siang|sore|malam|am|pm)?\b').firstMatch(text);
    final numeric = standard ?? RegExp(r'\b(\d{1,2})\s*[:.]\s*(\d{2})\s*(pagi|siang|sore|malam|am|pm)?\b').firstMatch(text);
    if (numeric != null) {
      final hour = int.parse(numeric.group(1)!);
      final minute = int.tryParse(numeric.group(2) ?? '0') ?? 0;
      final explicitPeriod = numeric.group(3);
      final resolved = _applyPeriod(hour, explicitPeriod ?? period);
      if (resolved >= 0 && resolved <= 23 && minute <= 59) {
        return _TimeInfo(TimeOfDayParts(resolved, minute), _formatTime(resolved, minute), explicitPeriod ?? period);
      }
    }

    final spoken = RegExp(r'\bjam\s+(\d{1,2})\s*(pagi|siang|sore|malam|am|pm)\b').firstMatch(text);
    if (spoken != null) {
      final hour = _applyPeriod(int.parse(spoken.group(1)!), spoken.group(2));
      return _TimeInfo(TimeOfDayParts(hour, 0), _formatTime(hour, 0), spoken.group(2));
    }

    return _TimeInfo(null, null, period);
  }

  String? _periodIn(String text) {
    for (final value in ['pagi', 'siang', 'sore', 'malam']) {
      if (RegExp(r'\b' + value + r'\b').hasMatch(text)) return value;
    }
    return null;
  }

  int _applyPeriod(int hour, String? period) {
    if (period == 'malam') {
      if (hour == 12) return 0;
      if (hour < 12) return hour + 12;
    }
    if (period == 'siang' || period == 'sore' || period == 'pm') {
      if (hour < 12) return hour + 12;
    }
    return hour;
  }

  String _formatTime(int hour, int minute) =>
      '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';

  DateTime? _safeDate(int year, int month, int day) {
    try {
      final value = DateTime(year, month, day);
      if (value.year != year || value.month != month || value.day != day) return null;
      return value;
    } catch (_) {
      return null;
    }
  }

  String _extractTitle(String text) {
    var value = text;
    value = value.replaceAll(RegExp(r'\b(tolong|please|dong|ya|deh|yaudah)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(ingatkan|ingetin|ingatkan aku|ingetin aku|titipkan|titip|jangan lupa|remind me|remind|ingat aku)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(saya|aku|gue|gua|gw|kamu|aku|me)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(hari ini|besok|lusa|minggu depan)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(\d{1,2})[\/-](\d{1,2})(?:[\/-](\d{2,4}))?\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(\d{1,2})\s+(januari|februari|maret|april|mei|juni|juli|agustus|september|oktober|november|desember)(?:\s+\d{4})?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bjam\s+(?:nol|satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas)\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bpukul\s+(?:nol|satu|dua|tiga|empat|lima|enam|tujuh|delapan|sembilan|sepuluh|sebelas)\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bjam\s+\d{1,2}(?:\s*[:.]\s*\d{2})?\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bpukul\s+\d{1,2}(?:\s*[:.]\s*\d{2})?\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\b\d{1,2}\s*[:.]\s*\d{2}\s*(?:pagi|siang|sore|malam|am|pm)?\b'), ' ');
    value = value.replaceAll(RegExp(r'\bsetengah\s+\d{1,2}\b'), ' ');
    value = value.replaceAll(RegExp(r'\bjam\s+\d{1,2}\s+kurang\s+seperempat\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(pagi|siang|sore|malam)\b'), ' ');
    value = value.replaceAll(RegExp(r'\b(pada|untuk|di|tanggal|pukul)\b'), ' ');
    value = value.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (value.isEmpty) return '';
    return value[0].toUpperCase() + value.substring(1);
  }
}

class TimeOfDayParts {
  final int hour;
  final int minute;
  const TimeOfDayParts(this.hour, this.minute);
}

class _TimeInfo {
  final TimeOfDayParts? time;
  final String? label;
  final String? period;
  const _TimeInfo(this.time, this.label, this.period);
}

class _DateInfo {
  final DateTime? date;
  final String? label;
  const _DateInfo(this.date, this.label);
}
