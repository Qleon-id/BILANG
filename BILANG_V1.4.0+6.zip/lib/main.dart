import 'package:flutter/material.dart';
import 'core/theme/bilang_theme.dart';
import 'models/user_settings.dart';
import 'repositories/shared_preferences_settings_repository.dart';
import 'repositories/shared_preferences_reminder_repository.dart';
import 'features/opening/opening_screen.dart';
import 'features/onboarding/onboarding_screen.dart';
import 'features/home/home_screen.dart';
import 'services/notification_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final repository = SharedPreferencesSettingsRepository();
  final settings = await repository.getSettings();
  final reminderRepository = SharedPreferencesReminderRepository();
  final notificationService = NotificationService();
  await notificationService.initialize();
  await notificationService.rescheduleAll(reminderRepository, settings);
  runApp(BilangApp(repository: repository, reminderRepository: reminderRepository, initialSettings: settings));
}

class BilangApp extends StatefulWidget {
  final SharedPreferencesSettingsRepository repository;
  final SharedPreferencesReminderRepository reminderRepository;
  final UserSettings initialSettings;
  const BilangApp({super.key, required this.repository, required this.reminderRepository, required this.initialSettings});

  @override State<BilangApp> createState() => _BilangAppState();
}

class _BilangAppState extends State<BilangApp> {
  late UserSettings settings = widget.initialSettings;
  bool openingDone = false;

  ThemeMode get themeMode => switch (settings.appThemeMode) {
    AppThemeMode.light => ThemeMode.light,
    AppThemeMode.dark => ThemeMode.dark,
    AppThemeMode.system => ThemeMode.system,
  };

  Future<void> updateSettings(UserSettings value) async {
    await widget.repository.updateSettings(value);
    if (mounted) setState(() => settings = value);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BILANG',
      theme: BilangTheme.light(settings.selectedTheme),
      darkTheme: BilangTheme.dark(settings.selectedTheme),
      themeMode: themeMode,
      home: !openingDone
          ? OpeningScreen(onFinished: () => setState(() => openingDone = true))
          : settings.onboardingCompleted
              ? HomeScreen(settings: settings, onSettingsChanged: updateSettings, reminderRepository: widget.reminderRepository)
              : OnboardingScreen(settings: settings, onComplete: (s) async => updateSettings(s.copyWith(onboardingCompleted: true, onboardingStep: 0))),
    );
  }
}
