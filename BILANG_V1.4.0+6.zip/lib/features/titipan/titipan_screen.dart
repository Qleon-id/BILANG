import 'package:flutter/material.dart';

import '../../models/reminder.dart';
import '../../repositories/reminder_repository.dart';
import '../../services/reminder_service.dart';
import '../../services/notification_service.dart';
import '../../models/user_settings.dart';

class TitipanScreen extends StatefulWidget {
  final ReminderRepository repository;
  final UserSettings settings;

  const TitipanScreen({super.key, required this.repository, required this.settings});

  @override
  State<TitipanScreen> createState() => _TitipanScreenState();
}

class _TitipanScreenState extends State<TitipanScreen> {
  late final ReminderService service = ReminderService(
    widget.repository,
    settings: widget.settings,
    notificationService: NotificationService(),
  );
  List<Reminder> reminders = [];
  int filter = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await widget.repository.getReminders();
    if (!mounted) return;
    setState(() => reminders = data);
  }

  List<Reminder> get visible {
    final now = DateTime.now();
    final list = reminders
        .where(
          (r) =>
              r.status != ReminderStatus.dismissed &&
              r.status != ReminderStatus.completed,
        )
        .toList();

    if (filter == 1) {
      return list
          .where(
            (r) =>
                r.scheduledAt.year == now.year &&
                r.scheduledAt.month == now.month &&
                r.scheduledAt.day == now.day,
          )
          .toList();
    }

    if (filter == 2) {
      final tomorrow = DateTime(now.year, now.month, now.day + 1);
      return list.where((r) => !r.scheduledAt.isBefore(tomorrow)).toList();
    }

    return list;
  }

  Future<void> _add() async {
    final title = TextEditingController();
    DateTime date = DateTime.now();
    TimeOfDay time = TimeOfDay.now();
    ReminderRecurrence recurrence = ReminderRecurrence.none;

    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialog) {
            return AlertDialog(
              title: const Text('Titip sesuatu'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: title,
                      autofocus: true,
                      decoration: const InputDecoration(
                        labelText: 'Apa yang perlu diingat?',
                      ),
                    ),
                    const SizedBox(height: 14),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Tanggal'),
                      subtitle: Text('${date.day}/${date.month}/${date.year}'),
                      trailing: const Icon(Icons.calendar_today_outlined),
                      onTap: () async {
                        final selected = await showDatePicker(
                          context: context,
                          firstDate: DateTime.now(),
                          lastDate: DateTime.now().add(
                            const Duration(days: 3650),
                          ),
                          initialDate: date,
                        );
                        if (selected != null) {
                          setDialog(() => date = selected);
                        }
                      },
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Jam'),
                      subtitle: Text(time.format(context)),
                      trailing: const Icon(Icons.schedule_outlined),
                      onTap: () async {
                        final selected = await showTimePicker(
                          context: context,
                          initialTime: time,
                        );
                        if (selected != null) {
                          setDialog(() => time = selected);
                        }
                      },
                    ),
                    DropdownButtonFormField<ReminderRecurrence>(
                      initialValue: recurrence,
                      decoration: const InputDecoration(labelText: 'Ulangi'),
                      items: ReminderRecurrence.values
                          .map(
                            (r) => DropdownMenuItem<ReminderRecurrence>(
                              value: r,
                              child: Text(_recurrenceLabel(r)),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        setDialog(
                          () => recurrence = value ?? ReminderRecurrence.none,
                        );
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('Batal'),
                ),
                FilledButton(
                  onPressed: () {
                    Navigator.pop(context, title.text.trim().isNotEmpty);
                  },
                  child: const Text('Titipkan'),
                ),
              ],
            );
          },
        );
      },
    );

    if (result == true) {
      final scheduled = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
      await service.create(
        title: title.text,
        scheduledAt: scheduled,
        recurrence: recurrence,
      );
      await _load();
    }

    title.dispose();
  }

  static String _recurrenceLabel(ReminderRecurrence recurrence) {
    return switch (recurrence) {
      ReminderRecurrence.none => 'Tidak diulang',
      ReminderRecurrence.daily => 'Setiap hari',
      ReminderRecurrence.weekly => 'Setiap minggu',
      ReminderRecurrence.monthly => 'Setiap bulan',
      ReminderRecurrence.custom => 'Custom',
    };
  }

  String _date(Reminder reminder) {
    final now = DateTime.now();
    final time =
        '${reminder.scheduledAt.hour.toString().padLeft(2, '0')}:${reminder.scheduledAt.minute.toString().padLeft(2, '0')}';

    if (reminder.scheduledAt.year == now.year &&
        reminder.scheduledAt.month == now.month &&
        reminder.scheduledAt.day == now.day) {
      return 'Hari ini • $time';
    }

    return '${reminder.scheduledAt.day}/${reminder.scheduledAt.month}/${reminder.scheduledAt.year} • $time';
  }

  @override
  Widget build(BuildContext context) {
    final currentVisible = visible;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Titipan',
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Yang sedang aku ingat untukmu.',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: _add,
                    icon: const Icon(Icons.add_rounded),
                    tooltip: 'Titipkan',
                  ),
                ],
              ),
              const SizedBox(height: 18),
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('Semua')),
                  ButtonSegment(value: 1, label: Text('Hari ini')),
                  ButtonSegment(value: 2, label: Text('Mendatang')),
                ],
                selected: {filter},
                onSelectionChanged: (selection) {
                  setState(() => filter = selection.first);
                },
              ),
              const SizedBox(height: 18),
              Expanded(
                child: currentVisible.isEmpty
                    ? _empty(context)
                    : ListView.separated(
                        itemCount: currentVisible.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 10),
                        itemBuilder: (context, index) =>
                            _card(context, currentVisible[index]),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _empty(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.schedule_outlined,
            size: 56,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 14),
          Text(
            'Belum ada titipan.',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          const Text(
            'Kalau ada yang takut kamu lupa, bilang aja.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _add,
            icon: const Icon(Icons.add),
            label: const Text('Titipkan sekarang'),
          ),
        ],
      ),
    );
  }

  Widget _card(BuildContext context, Reminder reminder) {
    final overdue =
        reminder.scheduledAt.isBefore(DateTime.now()) &&
        reminder.status == ReminderStatus.active;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withValues(alpha: .15),
              shape: BoxShape.circle,
            ),
            child: Icon(
              overdue ? Icons.warning_amber_rounded : Icons.schedule_rounded,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  reminder.title,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  _date(reminder),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                if (overdue) ...[
                  const SizedBox(height: 4),
                  const Text(
                    'Hmm... 👀 Ini tadi mau kamu kerjakan.',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ],
            ),
          ),
          PopupMenuButton<String>(
            onSelected: (value) async {
              if (value == 'done') {
                await service.complete(reminder.id);
              } else if (value == 'snooze') {
                await service.snooze(
                  reminder.id,
                  DateTime.now().add(const Duration(minutes: 15)),
                );
              } else if (value == 'delete') {
                await service.delete(reminder.id);
              }
              await _load();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'done', child: Text('Selesai')),
              PopupMenuItem(
                value: 'snooze',
                child: Text('Nanti aja • 15 menit'),
              ),
              PopupMenuItem(value: 'delete', child: Text('Lupakan')),
            ],
          ),
        ],
      ),
    );
  }
}
