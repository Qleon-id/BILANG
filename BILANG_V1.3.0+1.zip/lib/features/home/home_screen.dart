import 'package:flutter/material.dart';
import '../../models/user_settings.dart';
import '../../models/reminder.dart';
import '../../repositories/reminder_repository.dart';
import '../../services/bilang_engine.dart';
import '../../services/reminder_service.dart';
import '../../services/speech_service.dart';
import '../aku/aku_screen.dart';
import '../ingatan/ingatan_screen.dart';
import '../onboarding/character_data.dart';
import '../onboarding/character_view.dart';
import '../titipan/titipan_screen.dart';

class HomeScreen extends StatefulWidget {
  final UserSettings settings;
  final Future<void> Function(UserSettings) onSettingsChanged;
  final ReminderRepository reminderRepository;

  const HomeScreen({
    super.key,
    required this.settings,
    required this.onSettingsChanged,
    required this.reminderRepository,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final input = TextEditingController();
  final BilangEngine engine = BilangEngine();
  final SpeechService speechService = SpeechService();
  late final ReminderService reminderService = ReminderService(widget.reminderRepository);
  List<Reminder> todayReminders = [];
  bool processingInput = false;
  bool listening = false;
  String liveSpeechText = '';

  @override
  void initState() {
    super.initState();
    _loadToday();
  }

  Future<void> _loadToday() async {
    final all = await widget.reminderRepository.getActiveReminders();
    final now = DateTime.now();
    if (mounted) setState(() { todayReminders = all.where((r) => r.scheduledAt.year == now.year && r.scheduledAt.month == now.month && r.scheduledAt.day == now.day).toList(); });
  }

  @override
  void dispose() {
    speechService.cancel();
    input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      _home(context),
      TitipanScreen(repository: widget.reminderRepository),
      const IngatanScreen(),
      AkuScreen(
        settings: widget.settings,
        onSettingsChanged: widget.onSettingsChanged,
      ),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.schedule_outlined),
            selectedIcon: Icon(Icons.schedule),
            label: 'Titipan',
          ),
          NavigationDestination(
            icon: Icon(Icons.psychology_alt_outlined),
            selectedIcon: Icon(Icons.psychology_alt),
            label: 'Ingatan',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Aku',
          ),
        ],
      ),
    );
  }

  Widget _home(BuildContext context) {
    final hour = DateTime.now().hour;
    final greeting = hour < 11
        ? 'Selamat pagi 👋 Ada yang mau kamu titipkan hari ini?'
        : hour < 17
            ? 'Lagi sibuk? 👀 Bilang aja. Aku ingat.'
            : hour < 22
                ? 'Sebelum lanjut... Ada sesuatu yang perlu kamu titipkan?'
                : 'Sebelum tidur... 🌙 Ada yang perlu aku ingat untuk besok?';

    final info = characterInfos.firstWhere(
      (character) => character.type == widget.settings.selectedCharacter,
    );

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'BILANG',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const Spacer(),
              IconButton(
                onPressed: () => setState(() => index = 3),
                icon: const Icon(Icons.tune_rounded),
                tooltip: 'Pengaturan',
              ),
            ],
          ),
          const SizedBox(height: 18),
          Center(
            child: Column(
              children: [
                CharacterView(character: info.type, size: 170),
                const SizedBox(height: 10),
                Text(
                  greeting,
                  textAlign: TextAlign.center,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Center(
            child: Container(
              width: 92,
              height: 92,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: listening
                    ? Theme.of(context).colorScheme.primary.withValues(alpha: .82)
                    : Theme.of(context).colorScheme.primary,
                boxShadow: [
                  BoxShadow(
                    color: Theme.of(context)
                        .colorScheme
                        .primary
                        .withValues(alpha: listening ? .38 : .25),
                    blurRadius: listening ? 26 : 20,
                    spreadRadius: listening ? 6 : 3,
                  ),
                ],
              ),
              child: IconButton(
                onPressed: processingInput ? null : (listening ? _stopVoice : _startVoice),
                icon: Icon(
                  listening ? Icons.stop_rounded : Icons.mic_rounded,
                  size: 40,
                  color: Colors.white,
                ),
                tooltip: listening ? 'Selesai mendengarkan' : 'Bilang',
              ),
            ),
          ),
          const SizedBox(height: 10),
          Center(
            child: Text(
              listening ? 'Aku dengarkan...' : 'Tekan dan bilang aja',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ),
          if (listening && liveSpeechText.isNotEmpty) ...[
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Theme.of(context).dividerColor),
              ),
              child: Text(
                liveSpeechText,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ],
          const SizedBox(height: 16),
          TextField(
            controller: input,
            enabled: !processingInput,
            textInputAction: TextInputAction.done,
            onSubmitted: (_) => _processTextInput(),
            decoration: InputDecoration(
              hintText: 'atau ketik aja...',
              suffixIcon: processingInput
                  ? const Padding(
                      padding: EdgeInsets.all(14),
                      child: SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    )
                  : IconButton(
                      onPressed: _processTextInput,
                      icon: const Icon(Icons.arrow_upward_rounded),
                      tooltip: 'Kirim',
                    ),
            ),
          ),
          const SizedBox(height: 30),
          Row(
            children: [
              Text(
                'Titipan hari ini',
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
              const Spacer(),
              TextButton(
                onPressed: () => setState(() => index = 1),
                child: const Text('Lihat semua'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (todayReminders.isEmpty)
            _preview(context, 'Belum ada titipan hari ini', 'Kalau ada yang takut kamu lupa, bilang aja.')
          else
            ...todayReminders.take(3).map((r) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _preview(context, r.title, '${r.scheduledAt.hour.toString().padLeft(2, '0')}:${r.scheduledAt.minute.toString().padLeft(2, '0')}'))),
        ],
      ),
    );
  }

  Future<void> _startVoice() async {
    if (listening || processingInput) return;

    final available = await speechService.initialize(
      onError: (error) {
        if (!mounted) return;
        setState(() => listening = false);
        final message = error.errorMsg.toLowerCase().contains('permission')
            ? 'Aku belum mendapat izin mikrofon. 😌'
            : 'Aku belum bisa mendengar suara kamu. 👀 Coba lagi.';
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      },
    );

    if (!available || !mounted) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Aku belum bisa menggunakan mikrofon di perangkat ini. 👀')),
        );
      }
      return;
    }

    setState(() {
      listening = true;
      liveSpeechText = '';
      input.clear();
    });

    await speechService.listen(
      onResult: (result) {
        if (!mounted) return;
        final words = result.recognizedWords.trim();
        setState(() {
          liveSpeechText = words;
          input.text = words;
        });
        if (result.finalResult) {
          _finishVoice(words);
        }
      },
      onSoundLevelChange: (_) {},
    );
  }

  Future<void> _stopVoice() async {
    if (!listening) return;
    await speechService.stop();
    if (!mounted) return;
    final text = input.text.trim();
    setState(() => listening = false);
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aku belum dengar apa-apa. 👀 Coba bilang sekali lagi?')),
      );
      return;
    }
    await _processTextInput();
  }

  Future<void> _finishVoice(String words) async {
    if (!listening) return;
    await speechService.stop();
    if (!mounted) return;
    setState(() => listening = false);
    if (words.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Aku belum dengar apa-apa. 👀 Coba bilang sekali lagi?')),
      );
      return;
    }
    await _processTextInput();
  }

  Future<void> _processTextInput() async {
    final text = input.text.trim();
    if (text.isEmpty || processingInput) return;

    setState(() => processingInput = true);
    try {
      final result = await engine.processInput(text);
      if (!mounted) return;

      if (result.requiresConfirmation && result.entities['scheduledAt'] is DateTime) {
        final saved = await _showConfirmation(result);
        if (saved) {
          input.clear();
          await _loadToday();
        }
        return;
      }

      if (result.requiresClarification) {
        final answer = await _showClarification(result.response ?? 'Boleh diperjelas?');
        if (answer != null && answer.trim().isNotEmpty && mounted) {
          final followUp = _buildFollowUp(text, answer.trim(), result.response ?? '');
          setState(() => processingInput = false);
          input.text = followUp;
          await _processTextInput();
        }
        return;
      }

      if (result.response != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(result.response!)),
        );
      }
    } finally {
      if (mounted) setState(() => processingInput = false);
    }
  }

  String _buildFollowUp(String original, String answer, String question) {
    final asksTime = question.toLowerCase().contains('jam berapa');
    if (asksTime && RegExp(r'^\d{1,2}([:.]\d{1,2})?$').hasMatch(answer)) {
      return '$original jam $answer';
    }
    return '$original $answer';
  }

  Future<bool> _showConfirmation(EngineResult result) async {
    final title = result.entities['title'] as String? ?? '';
    final scheduledAt = result.entities['scheduledAt'] as DateTime;
    final date = _naturalDateLabel(scheduledAt);
    final time = '${scheduledAt.hour.toString().padLeft(2, '0')}:${scheduledAt.minute.toString().padLeft(2, '0')}';

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Aku menangkap ini...'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Row(children: [const Icon(Icons.calendar_today_outlined, size: 18), const SizedBox(width: 8), Text(date)]),
            const SizedBox(height: 8),
            Row(children: [const Icon(Icons.schedule_outlined, size: 18), const SizedBox(width: 8), Text(time)]),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Ubah'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Titipkan'),
          ),
        ],
      ),
    );

    if (confirmed != true) return false;

    await reminderService.create(
      title: title,
      scheduledAt: scheduledAt,
      source: ReminderSource.text,
    );

    if (!mounted) return true;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Titipan sudah kusimpan. 👌')),
    );
    return true;
  }

  Future<String?> _showClarification(String message) async {
    final controller = TextEditingController();
    final answer = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Aku perlu tahu sedikit lagi'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textInputAction: TextInputAction.done,
          onSubmitted: (value) => Navigator.pop(dialogContext, value),
          decoration: InputDecoration(hintText: message),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, controller.text),
            child: const Text('Lanjut'),
          ),
        ],
      ),
    );
    controller.dispose();
    return answer;
  }

  String _naturalDateLabel(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final value = DateTime(date.year, date.month, date.day);
    if (value == today) return 'Hari ini';
    if (value == today.add(const Duration(days: 1))) return 'Besok';
    if (value == today.add(const Duration(days: 2))) return 'Lusa';
    return '${date.day}/${date.month}/${date.year}';
  }

  Widget _preview(BuildContext context, String title, String subtitle) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Theme.of(context)
                  .colorScheme
                  .primary
                  .withValues(alpha: .15),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.schedule_rounded,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
