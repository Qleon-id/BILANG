# BILANG V1.2.0 — Natural Language Engine

**Tagline:** Kamu bilang. BILANG yang ingat.

V1.2 adds the first usable text-based Natural Language Engine on top of the V1.1 reminder foundation.

## Scope
- Natural Indonesian text input for creating reminders.
- Understands common reminder phrases such as "ingatkan", "ingetin", "titip", "jangan lupa", and "remind me".
- Understands relative dates: hari ini, besok, lusa, minggu depan.
- Understands numeric dates and Indonesian month names.
- Understands times such as 07.00, 7:30, jam 7, jam 7 pagi/malam, setengah 8, and jam 9 kurang seperempat.
- Missing or ambiguous required information triggers clarification instead of guessing.
- High-confidence reminder requests show a confirmation step before saving.
- Confirmed text reminders are stored with source `TEXT`.
- Existing manual Titipan flow remains unchanged.
- Engine is shared in a service layer so V1.3 Voice can reuse it.

## Deliberately not in V1.2
- Voice recognition (V1.3).
- OS notification scheduling (V1.4).
- Full memory CRUD through natural language (later V1.5 integration).
- Android launcher icon replacement remains deferred.

## Android Build
BILANG is Android-only for this development track. The existing GitHub Actions workflow remains the build path.


## V1.3 Voice
Voice input uses the same BilangEngine as text input. Speech recognition is Android-focused and uses Indonesian locale when available.


## V1.4 Notification Engine
- Android local reminder notifications.
- Notification styles follow BILANG settings.
- Quiet hours are respected without changing the stored reminder time.
- Active reminders are rescheduled when the app starts.
- Recurring daily, weekly, and monthly reminders use calendar-aware schedules.


## V1.4.0+9

Notification engine build compatibility revision. Uses flutter_local_notifications 7.0.0 with timezone ^0.7.0 to avoid the mandatory core-library-desugaring requirement introduced in later plugin versions. Scheduling remains timezone-aware with zonedSchedule and Android allow-while-idle behavior.


V1.4.0+9: Align timezone dependency with flutter_local_notifications 7.0.0 with timezone ^0.7.0 so dependency resolution succeeds.
